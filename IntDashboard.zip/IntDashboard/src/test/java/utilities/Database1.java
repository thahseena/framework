package utilities;

import java.io.*;
import java.sql.*;
import java.text.*;
import java.util.Date;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.*;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.mysql.cj.api.mysqla.result.Resultset;
import base.CustomListeners;
import base.TestBase;

public class Database1 extends TestBase {
	
	//public static String testdata = (System.getProperty("user.dir")+ "\\src\\test\\resource\\Excel\\Interactive_Tracking_ID_" + CustomListeners.time + ".xlsx");
	
	public static String testdata = (System.getProperty("user.dir") + "\\src\\test\\resource\\excel\\TestData.xlsx");
	public static String source = "";
	public static String desti = "";
	 
 /*
    public static void main(String[] args) {
    	Database exporter = new Database();
        exporter.export("Review");
        exporter.export("Product");
    }
 */
  public void createtestdata(String driver,String query, String url,String username,String password) throws IOException, Exception {
		
		//ResultSet result = null;
		
		//String filename = CustomListeners.ReportFolder + "\\Excel_TestReport_" + CustomListeners.time + ".xlsx";
		
		
		System.out.println(query);
		System.out.println(username);
		
		try {
			Connection con = DriverManager.getConnection(url,username,password);
			
		//	try {
		//		Class.forName(driver);
		//	} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
		//		e.printStackTrace();
		//	} 
			
			Statement Statement = con.createStatement();
			
			ResultSet result = Statement.executeQuery(query);
			
		/*	Different method
			int record = 0;
			if (result.next()) {
				
				record++;
				LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();

                System.out.println(result.getString(1) );
            }
			
		*/			
			
			//ExcelReportName = CustomListeners.ReportFolder + "\\Excel_TestReport_" + CustomListeners.time + ".xlsx";
			//testdata = CustomListeners.ReportFolder + "\\src\\test\\resource\\Excel\\Interactive_Tracking_ID_" + CustomListeners.time + ".xlsx";
			//String ttes = System.getProperty("user.dir") + "/reports"  + "/" + "report"	+ "_" + CustomListeners.time ;
			
			System.out.println(testdata);
			File outputFile = new File(testdata);
			//if (!outputFile.exists()) {
			FileInputStream fis2=new FileInputStream(outputFile);
				XSSFWorkbook workbook = new XSSFWorkbook(fis2);
				XSSFSheet sheet = workbook.getSheet("HFTrackingID"); //can add more sheet if needed
			//	writeHeaderLine(result, sheet);
				//System.out.println("header done");
				writeDataLines(result, workbook, sheet);
				
				
				fis2.close();
			//}
			
	         FileOutputStream fileOut = new FileOutputStream(outputFile);
				workbook.write(fileOut);
				workbook.close();
				Statement.close();
				
				System.out.println("data done");
				//utilities.Copytestdata copy = new  Copytestdata();
				//copy.Coptestdata();
								
		}catch (FileNotFoundException e) {
					e.printStackTrace();
				
					
		} catch (SQLException e) {
            System.out.println("Datababse error:");
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("File IO error:");
            e.printStackTrace();
        }
		
		
    }   
 
    private void writeHeaderLine(ResultSet result, XSSFSheet sheet) throws SQLException {
    	
    	System.out.println("inside header");
        // write header line containing column names
        ResultSetMetaData metaData = result.getMetaData();
      // int numberOfColumns = metaData.getColumnCount();
 
       // Row headerRow = sheet.createRow(0);
        Row headerRow = sheet.getRow(0);
 
        // exclude the first column which is the ID field
      //  for (int i = 1; i <= numberOfColumns; i++) {
            String columnName = metaData.getColumnName(1);
            Cell headerCell = headerRow.createCell(0);
            headerCell.setCellValue(columnName);
            
        }
        
    
 
    private void writeDataLines(ResultSet result, XSSFWorkbook workbook, XSSFSheet sheet)
            throws SQLException {
    	System.out.println("inside writerdata");
    	
        ResultSetMetaData metaData = result.getMetaData();
        int numberOfColumns = metaData.getColumnCount();
        
        System.out.println("Number of columns " + numberOfColumns);
        
       
        int rowCount = 1; 
        while (result.next()) {
        	
            //Row row = sheet.createRow(rowCount++);
        	Row row = sheet.getRow(rowCount++);
  
            //for (int i = 1; i <= numberOfColumns; i++) { - refer this [https://www.codejava.net/coding/java-code-example-to-export-data-from-database-to-excel-file] when remaining columns to be added
            
                //Object valueObject = result.getObject(i);
            	//String valueObject = result.getString(i);
            	String valueObject = result.getString("tracking_id");
 
                Cell cell = row.createCell(0);
                cell.setCellValue( valueObject);
                formatDateCell(workbook, cell);
                
                System.out.println(valueObject);
               
                
            }  
 
            }
 
        
   // hve to include copytestdata here once resolving archive
    
    
    
    
      
    
 
    private void formatDateCell(XSSFWorkbook workbook, Cell cell) {    //include when date is added to the result
        CellStyle cellStyle = workbook.createCellStyle();
        CreationHelper creationHelper = workbook.getCreationHelper();
        cellStyle.setDataFormat(creationHelper.createDataFormat().getFormat("yyyy-MM-dd HH:mm:ss"));
        cell.setCellStyle(cellStyle);
    }
}

