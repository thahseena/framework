package utilities;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import com.relevantcodes.extentreports.DisplayOrder;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class ExtentManager {
	
	private static ExtentReports extent;
	public static ExtentTest test; 
	static Map extentTestMap = new HashMap();
	static String desfol =  ExcelReader1.ReportFolder;
	//private static ExtentReports extent = ExtentReporter.getReporter();
	
	
	public static ExtentReports getInstance(){
		
		if(extent==null){
			extent = new ExtentReports(System.getProperty("user.dir")+"\\target\\surefire-reports\\html\\extent.html",true,DisplayOrder.OLDEST_FIRST);
			//extent = new ExtentReports(desfol+"\\extent.html",true,DisplayOrder.OLDEST_FIRST);
			
			extent.loadConfig(new File(System.getProperty("user.dir")+"\\src\\test\\resource\\extentconfig\\ReportsConfig.xml"));	
		}
		
		return extent;	
	}
	

 
   // public static synchronized ExtentTest getTest() {
  //      return (ExtentTest) extentTestMap.get((int) (long) (Thread.currentThread().getId()));
 //   }
	
	
	public  synchronized static ExtentTest startTest(String testName, String desc) {
        ExtentTest test = extent.startTest(testName, desc);
       // extentTestMap.put((int) (long) (Thread.currentThread().getId()), test);
        return test;
    }
	
	
		
	
	
 

}
