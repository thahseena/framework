
package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFName;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.relevantcodes.extentreports.LogStatus;
import base.CustomListeners;
import base.TestBase;


public class ExcelReader1 extends TestBase{
	

	public static String ExcelReportName = "";
	
	public static ArrayList<String> ID_List = new ArrayList<String>();
	public static String ReportName = "";
	public static String time = CustomListeners.getDate();
	public static String ReportFolder =  System.getProperty("user.dir") + "\\reports\\Latest"  + "\\" + "report"+  "_" + time ; 

	@SuppressWarnings({ "resource" })
	public static ArrayList<String> readFromExcel(String inputFile, String sheetName, String ColName) throws Exception {
		
		System.out.println("*************\nReading the Excel Data...\n*************");

		InputStream ExcelFileToRead = new FileInputStream(inputFile);
		XSSFWorkbook workBook = new XSSFWorkbook(ExcelFileToRead);
		XSSFSheet sheet = workBook.getSheet(sheetName);

		int TotalRows = sheet.getLastRowNum();
		
		XSSFRow header = sheet.getRow(0);

		for (int row = 2; row <= TotalRows; row++) {

			try {
				
				String cellvalue = getCellValue(sheet.getRow(row).getCell(getColumnNumber(header, ColName))).trim();
						
				if (!cellvalue.isEmpty()) {

					ID_List.add(cellvalue);
				}

			} catch (NullPointerException ex) {
				
				System.out.println(ex.toString());
			}
		}

		System.out.println("Correspondind ID data taken --> " + ID_List.toString());

		return ID_List;
	}

	public static Integer getColumnNumber(XSSFRow row, String colName) throws Exception {

		int patchColumn = -1;
		for (int cn = 0; cn < row.getLastCellNum(); cn++) {

			XSSFCell c = row.getCell(cn);
			try {
				String text = c.getStringCellValue();

				if (colName.equals(text)) {
					patchColumn = cn;
					break;
				}
			} catch (Exception e) {

			}
		}
		if (patchColumn == -1) {
			throw new Exception("None of the cells in the header row contain '" + colName + "'");
		}
		return patchColumn;

	}

	public static void createExcelReport() {

		try {
			LinkedHashMap<String,Object[]> map = new LinkedHashMap<String,Object[]>();
			
	 ReportFolder = System.getProperty("user.dir") + "\\reports\\Latest"  + "\\" + "report"+  "_" + time ; 
			System.out.println("RF = " + ReportFolder);
			
			File directory = new File(ReportFolder);
			System.out.println("chk the folder in the path: " +directory);
			if(!directory.exists()) {
				directory.mkdir();
				System.out.println("Created new folder: " +directory);
			}
			
			System.out.println("folder already existed: " +directory);
			
			ExcelReportName = directory + "\\Excel_TestReport_" + CustomListeners.time + ".xlsx";
			System.out.println("pick the file: " +ExcelReportName);
			
			//ExcelReportName = ExtentReporter.ReportFolder + "\\Excel_TestReport_" + ExtentReporter.time + ".xlsx";			
			//ExcelReportName = System.getProperty("user.dir") + "\\reports\\Output Result Report\\"  + "Excel_TestReport_" + ExtentReporter.time + ".xlsx";
			File outputFile = new File(ExcelReportName);
           //FileInputStream inputStream = new FileInputStream(outputFile);

			XSSFWorkbook workbook = null;

			if (!outputFile.exists()) {

				workbook = new XSSFWorkbook();

				workbook.createSheet("Test_data_status");
				workbook.createSheet("Inspire_DB_Data");
				workbook.createSheet("CID_DB_ActivityStatus_Log");
				workbook.createSheet("CID_DB_Event_Data");
				workbook.createSheet("CID_DB_Outbound_Data");
				workbook.createSheet("CID_DB_BatchDetail_Data");
				workbook.createSheet("CID_DB_xref_Data");
				
				
				System.out.println("created:  " + outputFile);
				
				System.out.println("Open:  " + outputFile);	
				FileOutputStream fileOut = new FileOutputStream(outputFile);
				workbook.write(fileOut);
				workbook.close();
				System.out.println("Data saved into " + fileOut);
				
				
				
				XSSFSheet sheet = workbook.getSheet("Test_data_status");
				
				String nme = sheet.getSheetName();
				
				if (nme.equalsIgnoreCase( "Test_data_status"))
					
				 {
					System.out.println("adding the header");
					map.put("1", new Object[] {"Tracking_ID","Flow", "Status"});
					ExcelReader1.resultup("Test_data_status", " ", map);
					
					System.out.println("header of the status printed" );
				}

			}
			
			
			
			//System.out.println("Open:  " + outputFile);	
			//FileOutputStream fileOut = new FileOutputStream(outputFile);
			//workbook.write(fileOut);
		//	workbook.close();
			//System.out.println("Data saved into " + fileOut);
				
			
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	public static void storeIntoExcel(String sheetNAME, String LineItem, LinkedHashMap<String, String> map) {

		try {
			InputStream ExcelFileToRead = new FileInputStream(ExcelReportName);
			XSSFWorkbook workBook = new XSSFWorkbook(ExcelFileToRead);
			XSSFSheet sheet = workBook.getSheet(sheetNAME);
			

			int LastRow = sheet.getLastRowNum();

			if (LastRow < 1) {

				XSSFRow header = sheet.createRow(0);

				header.createCell(0).setCellValue("LineItem");

				XSSFRow row1 = sheet.createRow(1);

				row1.createCell(0).setCellValue(LineItem);

				int counter = 0;
				for (Entry<String, String> keys : map.entrySet()) {

					counter++;

					header.createCell(counter).setCellValue(keys.getKey().trim());

					row1.createCell(counter).setCellValue(keys.getValue().trim());

					sheet.autoSizeColumn(counter);
				}
			} else {

				XSSFRow row = sheet.createRow(LastRow + 1);

				row.createCell(0).setCellValue(LineItem);

				int counter = 0;
				for (Entry<String, String> keys : map.entrySet()) {

					counter++;

					row.createCell(counter).setCellValue(keys.getValue());

					sheet.autoSizeColumn(counter);
				}
			}

			FileOutputStream fileOut = new FileOutputStream(ExcelReportName);

			System.out.println("values written" + ExcelReportName);
			//test.log(LogStatus.PASS, "Inspire DB record exported successfully");
			workBook.write(fileOut);
			workBook.close();
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}
	
	
	
	public static void resultup(String sheetNAME, String LineItem, LinkedHashMap<String, Object[]> map) {
		
		try {
			InputStream ExcelFileToRead = new FileInputStream(ExcelReportName);
			XSSFWorkbook workBook = new XSSFWorkbook(ExcelFileToRead);
			XSSFSheet sheet = workBook.getSheet(sheetNAME);
			

			int LastRow = sheet.getLastRowNum();

			if (LastRow < 1) {
				
				System.out.println("no header");
				XSSFRow header = sheet.createRow(LastRow);
				XSSFRow row1 = sheet.createRow(LastRow+1);
				int counter = 0;
				for (Entry<String, Object[]> keys : map.entrySet()) {
					
					String Key = keys.getKey();
					Object [] obj1 = keys.getValue();
					
			
								
					
					for (Object obj : obj1) {
					
			            Cell cell = row1.createCell(counter++);
			           		           
			            if(obj instanceof Date) 
			                cell.setCellValue((Date)obj);
			            else if(obj instanceof Boolean)
			                cell.setCellValue((Boolean)obj);
			            else if(obj instanceof String)
			                cell.setCellValue((String)obj);
			            else if(obj instanceof Double)
			                cell.setCellValue((Double)obj); 

					sheet.autoSizeColumn(counter);
				}
			} }
			else {
				
				System.out.println("with  header");

				XSSFRow row1 = sheet.createRow(LastRow +1 );
				int counter = 0;
					for (Entry<String, Object[]> keys : map.entrySet()) {
					
					String Key = keys.getKey();
					Object [] obj1 = keys.getValue();
					for (Object obj : obj1) {
					
			            Cell cell = row1.createCell(counter++);
			           		           
			            if(obj instanceof Date) 
			                cell.setCellValue((Date)obj);
			            else if(obj instanceof Boolean)
			                cell.setCellValue((Boolean)obj);
			            else if(obj instanceof String)
			                cell.setCellValue((String)obj);
			            else if(obj instanceof Double)
			                cell.setCellValue((Double)obj); 

					sheet.autoSizeColumn(counter);
				}
			}
			}
			FileOutputStream fileOut = new FileOutputStream(ExcelReportName);

			System.out.println("values written" + ExcelReportName);
			//test.log(LogStatus.PASS, "Inspire DB record exported successfully");
			workBook.write(fileOut);
			workBook.close();
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

		

	}
	
	private static String getCellValue(XSSFCell cell) {
		
		String value="";
		
		switch (cell.getCellType()) {

		/*case Cell.CELL_TYPE_STRING:*/
		case Cell.CELL_TYPE_STRING:
			
			System.out.println(cell.getRichStringCellValue().getString());
			value = cell.getRichStringCellValue().getString();
			break;

		case Cell.CELL_TYPE_NUMERIC:

			if (DateUtil.isCellDateFormatted(cell)) {

				System.out.println(cell.getDateCellValue());
				value = cell.getDateCellValue().toString();
						
			} else {

				System.out.println((int)cell.getNumericCellValue());
				value = String.valueOf((int)cell.getNumericCellValue());
			}
			break;

		case Cell.CELL_TYPE_BOOLEAN:

			System.out.println(cell.getBooleanCellValue());
			value = String.valueOf(cell.getBooleanCellValue());
			break;

		case Cell.CELL_TYPE_FORMULA:

			value = String.valueOf(cell.getCellFormula());
			System.out.println(cell.getCellFormula());
			break;

		default:

			System.out.println();
		}

	    System.out.print("\t");
		return value;
	}

}
