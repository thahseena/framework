package utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Properties;

//import tests.E2EValidation.MainClass;

public class PropertiesFileHandler {
	
	public static String readProperty(String strProp)
	{
		String strReturnValaue = "";
		try {
			Properties prop= new Properties();
			InputStream input = null;
			try 
			{   //input = new FileInputStream(MainClass.configFile);
				input = new FileInputStream(System.getProperty("user.dir") + "\\src\\test\\resource\\properties\\Config.properties");
			} catch(FileNotFoundException e) 
			{
				e.printStackTrace();
			}
			prop.load(input);
			strReturnValaue = prop.getProperty(strProp);
			
		} catch (Exception exp) {
			System.out.println(exp.getMessage());
			exp.printStackTrace();
		}
		return strReturnValaue;
	}
}
