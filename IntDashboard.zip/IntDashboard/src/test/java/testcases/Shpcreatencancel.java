package testcases;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.LinkedHashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import base.TestBase;
import utilities.ExcelReader1;
import utilities.TestUtil;

public class Shpcreatencancel extends TestBase {
	
	LinkedHashMap<String,Object[]> map = new LinkedHashMap<String,Object[]>();
	String LineItem ;
	public String CIDs = "";
	public boolean success;
	
	
public Shpcreatencancel(WebDriver webDriver) {
		// TODO Auto-generated constructor stub
	}


@Test
	public String CreateTicketCancel(Hashtable<String,String> data) throws InterruptedException, IOException {
	
	String val = (data.get("memberid"));
		
		TestUtil.captureScreenshot();
		test.log(LogStatus.INFO,"SHP - Create and Cancel " + val +test.addScreenCapture(TestUtil.screenshotName));
		
		System.out.println("SHP - Create and Cancel for member id: " +val);
		
		log.debug("SHP - Create and Cancel");
				
	
		driver.findElement(By.xpath("//*[@id=\"login-info-content\"]/span[2]")).click();
		
		
		driver.findElement(By.xpath("//div[@class='role'][contains(text(),'EB SHP Reviewer')]")).click();
		Thread.sleep(5000);

		driver.findElement(By.xpath("//span[contains(text(),'New Ticket')]")).click();
		
		TestUtil.captureScreenshot();
		test.log(LogStatus.PASS,"Clicked on 'New Ticket successfully" +test.addScreenCapture(TestUtil.screenshotName));

		Thread.sleep(3000);
		// EB_SHPFormLetter
		driver.findElement(By.xpath(
				"//*[@id=\"tab_FORM_0\"]/div[1]/div[1]/div/div/div/div[2]/div/div[2]/div/div/div/div/div[1]/div/span/span/span"))
				.click();
		Thread.sleep(4000);
		
		switchToWindow(1);
		Thread.sleep(3000);
		// Enter the Template Name
		driver.findElement(By.xpath("//*[@id=\"form\"]/div[5]/div[4]/table/tbody/tr[1]/td[2]/select"))
				.sendKeys(data.get("templatename"));
		Thread.sleep(2000);
		// Enter the Member ID
		driver.findElement(By.xpath("//*[@id=\"form\"]/div[5]/div[4]/table/tbody/tr[2]/td[2]/input"))
				.sendKeys(data.get("memberid"));
		Thread.sleep(4000);
		//Maximize the window
		//driver.manage().window().maximize();
		Thread.sleep(4000);
		// Select a Disenrollment Date
		
		// String date = (data.get("date"));
       //  DateFormat dateFormat = new SimpleDateFormat("yyyy/m/d");  
       //  String strDate = dateFormat.format(date);  
       //  System.out.println("Converted String: " + strDate);  
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div[5]/div[4]/table/tbody/tr[3]/td[2]/input")).sendKeys((data.get("date")));
		Thread.sleep(2000);
		// Select a Disenrollment Reason
		driver.findElement(By.xpath("//*[@id=\"form\"]/div[5]/div[4]/table/tbody/tr[4]/td[2]/select")).sendKeys(data.get("reason"));
		Thread.sleep(2000);
		// Enter the Customer Master ID
		driver.findElement(By.xpath("//*[@id=\"form\"]/div[5]/div[4]/table/tbody/tr[7]/td[2]/input"))
				.sendKeys(data.get("customerid"));
		
		TestUtil.captureScreenshot();
		test.log(LogStatus.PASS,"All details entered and submited sucessfully: " +test.addScreenCapture(TestUtil.screenshotName));
		Thread.sleep(3000);
		// CLick on Approve icon on the top right corner
		driver.findElement(By.xpath("//*[@id=\"documentInfoPanel\"]/div[1]/div/div/div[2]/div[3]/div[2]/div/div"))
				.click();
		Thread.sleep(3000);
		// CLick on OK (to create a ticket)
		driver.findElement(By.xpath("//*[@id=\"approveButton\"]/span")).click();
		Thread.sleep(3000);
		
		// Navigate to a different page
		switchToWindow(0);
		// Navigate back to the Dashboard
		driver.findElement(By.xpath("//*[@id=\"workarea\"]/div[1]/div/div/div[2]/ul/li[1]/a/span")).click();
		// Click on the All Tickets Awaiting Review
		driver.findElement(By.xpath("//*[@id=\"header-tabs-tabs\"]/ul/li[2]/a/span[1]")).click();
		Thread.sleep(50000);
		
		//WebElement Element = driver.findElement(By.xpath("//*[@id=\"tab_1\"]/div[1]/div[1]/div/div/div/div[2]/div/div[1]/div[8]/span[2]"));
		WebElement Element = driver.findElement(By.xpath("(//div//span[text()='Created'])[2]"));
		//
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();",Element );
		
		
		System.out.println("clicked  asc order");
		// Click on the Created column to get ascending order
		Element.click();
		Thread.sleep(50000);
		
		// Click on the newly created Ticket to open up by selecting recipient id
				
		String recipientId = (data.get("memberid"));
		
		System.out.println("recipientId " + recipientId);
		
		//driver.findElement(By.xpath("//*[@id=\"tab_1\"]/div[1]/div[1]/div/div/div/div[2]/div/div[2]/div[1]/div[1]/div[10]/div")).getText();
		
		//String recipientIds  = driver.findElement(By.xpath("//div[text()='"+ recipientId +"'])[1])")).getText();
		
		String recipientIds= driver.findElement(By.xpath("(//div[@class='cell col4 col_contractId hasFilterPicker'])[1]")).getText();	
		Thread.sleep(2000);
		
		// Print the Newly Recipient ID then click on the Ticket to opens up
		System.out.println("recipientIds " + recipientIds);
		
		if (!recipientIds.equals(recipientId)) {
			
			
			test.log(LogStatus.FAIL,"Created Creation Failed, Created Ticket not found in Dashboard: " +test.addScreenCapture(TestUtil.screenshotName));
			
			
		}
		else {
			
			
			
			  CIDs = driver.findElement(By.xpath("(//div[@class='cell col3 col_dataVariable hasFilterPicker'])[1]")).getText();
			
			System.out.println("CIDs "+CIDs);
			
			Thread.sleep(8000);
									
			//driver.findElement(By.xpath("//div[text()='"+ recipientId +"'])[1])")).click();
			driver.findElement(By.xpath("(//div[@class='cell col4 col_contractId hasFilterPicker'])[1]")).click();
			Thread.sleep(5000);
			
		//get tracking id
			//driver.getTitle();
			
			// Navigate to a different page
			switchToWindow(1);
			
			Thread.sleep(6000);
			// Click on the Accept Work icon
			
			//driver.findElement(By.xpath("//*[@id=\"documentInfoPanel\"]/div[1]/div/div/div[2]/div[4]/div[2]/div")).click();
			//Thread.sleep(2000);
			
			System.out.println("ac : 176");
			
			driver.findElement(By.xpath("//*[@id='approveButton']/span")).click();
			Thread.sleep(8000);
			
			
			
			
			System.out.println("ac : 184");
			
			Thread.sleep(8000);

			driver.findElement(By.xpath("//*[@id=\"documentInfoPanel\"]/div[1]/div/div/div[2]/div[4]/div[4]/div/div")).click();
			
			
			TestUtil.captureScreenshot();
			test.log(LogStatus.PASS,"Cancelled Button is clicked successfully: " +test.addScreenCapture(TestUtil.screenshotName));
			
			Thread.sleep(3000);
			driver.findElement(By.xpath("//*[@id='approveButton']")).click();
			
					
			

			try {
				// takeSnapShot(driver,"\\sv-hfi-014\\common\\Enterprise\\Correspondence\\Communication Platform\\SystemTesting\\CP1\\Monowar\\01.09.2021\\InspireInteractiveAutomation");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			switchToWindow(0);
			Element.click();
			System.out.println("clicked again asc order");
		}
		System.out.println("SHP letter has been created and Cancelled successfully");
		test.setDescription("SHP letter has been created and Cancelled successfully");
		
		
		test.log(LogStatus.INFO,"SHP letter has been created and Cancelled successfully" );
		
		success = true;
		// driver.quit();
		System.out.println("CIDs ebefore return "+CIDs);
		return CIDs;

	}

	
	
	
}
