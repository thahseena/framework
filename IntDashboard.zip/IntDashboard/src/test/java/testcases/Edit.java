package testcases;

import java.io.IOException;
import java.util.Hashtable;
import java.util.LinkedHashMap;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import base.TestBase;
import utilities.TestUtil;

public class Edit extends TestBase {
	
	
	/*
	 * search the trcking id
	 * accept it
	 * click on edit button
	 * select the date picker
	 * select the date
	 * approve the letter
	 * 
	 * 	
	
	 * 
	 * 
	 */
		
			public boolean success;

			public Edit(WebDriver webDriver) {
				// TODO Auto-generated constructor stub
			}

			@Test
			public void Edittest(Hashtable<String,String> data) throws InterruptedException, IOException{
				
				//test.setDescription("FLow for Tracking_ID: " + data.get("tracking_id"));
				
				Thread.sleep(5000);
				driver.navigate().refresh();
				System.out.println("Refresh");
				
				clearText("serchfield");
						
				Thread.sleep(2000);
				click("profile_sl");
				log.debug("Clicked on User Profile " );
				//TestUtil.captureScreenshot();
				//test.log(LogStatus.PASS, "Clicked on User Profile"+test.addScreenCapture(TestUtil.screenshotName));
				test.log(LogStatus.PASS, "Clicked on User Profile");

				
				click("Hficreview_sel");
				log.debug("HFIC is selected from the Profile List");
				TestUtil.captureScreenshot();
				test.log(LogStatus.PASS, "HFIC is selected from the Profile List"+test.addScreenCapture(TestUtil.screenshotName));
				
				driver.navigate().refresh();
				System.out.println("Refresh");
				
				click("allticktrev_tab");
				log.debug("All Ticket Review tab is selected");
				test.log(LogStatus.PASS, "Clicked on All Ticket Review tab");
				
				
				Thread.sleep(2000);
				clearText("serchfield");
				setText("serchfield", data.get("tracking_id")); 
				test.log(LogStatus.PASS, "Entered the Tracking ID in the Search Field "  + data.get("tracking_id"));
				log.debug("searching HFIC Tracking ID " + data.get("tracking_id") );
				
				By verifyresult1 = (By.xpath("//div[contains(text(),'"+(data.get("tracking_id"))+"')]"));   //  (By.xpath("//div[contains(text(), '"+eventName+"')]")); - format
				boolean turn1 = isElementPresent(verifyresult1);
				
				if (turn1 == false){
					
					log.debug(" Tracking ID not Found in " + OR.getProperty("Allticket"));
					//test.log(LogStatus.FAIL, "Tracking ID not Found in " + OR.getProperty("Allticket"));
					//Assert.assertFalse(turn1,"Tracking ID is not available in " + OR.getProperty("Allticket"));
					  //TestNGResults.put("3", new Object[] {"After Cancel, Tracking ID: " +(data.get("tracking_id")) , "is not found in All Ticket", "Pass"});
					
					//test.log(LogStatus.FAIL, "Tracking id not found in the Dashboard");
					
					
					
				} else { 
				
				Thread.sleep(8000);
				clickwithid("trackingidresult",data.get("tracking_id"));
				log.debug("Clicked on Tracking ID from displayed result");
				test.log(LogStatus.PASS, "Clicked on Tracking ID from displayed result");
				Thread.sleep(8000);
				
				//Date 
				System.out.println("Edit: 102");
								
				ECalendar("appconfm_bt", "Datenumber");
				log.info("Ticket is Approved & WinTab is closed");
			  	test.log(LogStatus.PASS, "Ticket is Approved & WinTab is closed");	
			  	Thread.sleep(3000);
				log.info("Navigated back to Main Window");
			  	test.log(LogStatus.PASS, "Navigated back to Main Window");
			  	
			  	System.out.println("refresh");
			  	driver.navigate().refresh();
			  	
			  	clearText("serchfield");
				Thread.sleep(6000);
				
				setText("serchfield", data.get("tracking_id")); 
				Thread.sleep(6000);
				
				
						
				click("allticktrev_tab");
				log.debug("Clicked on All Review Awaiting Tab");
				test.log(LogStatus.PASS, "Clicked on All Review Awaiting Tab");
				
				
				
				
				
				//wait.until(ExpectedConditions.presenceOfElementLocated((By.xpath(OR.getProperty("trackingidresult")))));
				
				By verifyresult2 = (By.xpath("//div[contains(text(),'"+(data.get("tracking_id"))+"')]"));   //  (By.xpath("//div[contains(text(), '"+eventName+"')]")); - format
				boolean turn2 = isElementPresents(verifyresult2);
				
				
				   
				if (turn2 == true){
					
					log.debug(" Tracking ID not Found in " + OR.getProperty("Allticket"));
					test.log(LogStatus.PASS, "Tracking ID not Found in " + OR.getProperty("Allticket"));
					//Assert.assertFalse(turn2,"Tracking ID is not available in " + OR.getProperty("Allticket"));
					 // TestNGResults.put("3", new Object[] {"After Approval, Tracking ID: " +(data.get("tracking_id")) , "is not found in All Ticket", "Pass"});
					
					test.log(LogStatus.PASS, "Approval Flow completed Successfully");
					success = true;
					
				}
				
				else {
				
				//wait.until(ExpectedConditions.presenceOfElementLocated((By.xpath(OR.getProperty("trackingidresult")))));
				
					log.debug("Found Tracking ID in " + OR.getProperty("Allticket"));
					
					test.log(LogStatus.FAIL, "Tracking ID Found in " + OR.getProperty("Allticket"));
					//Assert.assertTrue(turn2,"Tracking ID is available in " + OR.getProperty("Allticket"));
					// TestNGResults.put("3", new Object[] {"After Approval, Tracking ID: " +(data.get("tracking_id")) , "is  found in All Ticket", "Fail"});
					test.log(LogStatus.FAIL, "Approval Flow Failed");
				//Assert.fail("Login not successful");
				
				}		
			
			}
		
							
			}
	

}
