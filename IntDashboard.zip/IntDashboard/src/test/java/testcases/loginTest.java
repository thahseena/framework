package testcases;

import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.ExtentReports;
import base.TestBase;
import utilities.ExtentManager;
import utilities.TestUtil;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class loginTest extends TestBase {
	
	//public static ExtentReports rep = ExtentManager.getInstance();
	
	//ExtentTest test = rep.startTest("");
	
	utilities.TestUtil cs = new TestUtil();

	
	public loginTest(WebDriver webDriver) {
		// TODO Auto-generated constructor stub
	}


	
	public void loginsTest() throws InterruptedException, IOException{
		
		log.debug("Inside Login Test");
		
		
		
		
		click("userid");
		setText("userid",(config.getProperty("username")));  
		//test.log(LogStatus.PASS, "Entered User id");
		log.debug("User ID Entered");
		
		click("password");
		setText("password", (config.getProperty("passwordvalue")));
		log.debug("Password Entered");
		TestUtil.captureScreenshot();
		//test.addScreenCapture(TestUtil.screenshotName);
		//test.log(LogStatus.PASS, "Entered password");
		test.log(LogStatus.PASS, "Entered Credential" 
				+test.addScreenCapture(TestUtil.screenshotName));
		Thread.sleep(1000);
		
		click("logginbt");
		test.log(LogStatus.PASS, "Clicked Login Button");
		
		
		
		boolean chnkng = isElementPresent(By.xpath(OR.getProperty("profile_sl")));
		
		//boolean chnkng = isElementPresent("profile_sl");
		Thread.sleep(4000);
				
		if (chnkng == true){
			
			TestUtil.captureScreenshot();
			test.log(LogStatus.PASS, "Displayed Interactive Dashboard on successful Login" +test.addScreenCapture(TestUtil.screenshotName));
			log.debug("Login  success. Interactive Dashboard is loaded");
			Assert.assertTrue(chnkng,"Login  success. Interactive Dashboard is loaded");
		}
		
		//wait.until(ExpectedConditions.presenceOfElementLocated((By.xpath(OR.getProperty("trackingidresult")))));
		
		else {
			
		TestUtil.captureScreenshot();
		test.log(LogStatus.FAIL, " Log in Failed" +test.addScreenCapture(TestUtil.screenshotName));
		log.debug(" Log in Failed");
		Assert.assertTrue(chnkng,"Log In Fialed");	
		}
		
		
	
	}
	}


