package testcases;

import java.util.Hashtable;
import java.util.Objects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.LogStatus;
import base.TestBase;
import pages.CIDDbase;
import pages.InspireDbase;
import pages.InspireScaler;
import pages.Tovendor;
import pages.splunk;
import utilities.ExcelReader1;

//changes are made to accomodate the null value if db returns null in the 	
//@Listeners(base.CustomListeners.class)
public class Apprflow extends TestBase {
	
	WebDriver webDriver = null;

		
	 public static String strtrackingID ="";
		

	public Apprflow(WebDriver webDriver) {
		
		// TODO Auto-generated constructor stub
	}

	public void prepareTest(Hashtable<String,String> data,String CIDs, String flownames) throws Exception {	
		
		
		System.out.println("flowname frm excel :" + flownames );
		
		if (flownames.equals("shp")) {
			
		 strtrackingID = CIDs ;	
		 
		 System.out.println("tracking frm shpform :" + strtrackingID );
		
		}else {
			
			 
			
		 strtrackingID = data.get("tracking_id");
		 
		 System.out.println("tracking frm excel :" + strtrackingID );
		
		}
		
		
				
		System.out.println("tracking id for downstrm:  "+strtrackingID);
		
		//ExcelReader1.createExcelReport();
				
	//	webDriver = TestBase.inspireurl();
	//	webDriver = TestBase.splunkurl();
		
		if(!strtrackingID.isEmpty()) {
			
			
		//PDF To Vendor 
		System.out.println("Checking in staging folder");
			Tovendor find = new Tovendor();
			find.isFileFound(strtrackingID);
		 
			 
		//Inspire Validation database
			InspireDbase inspireDB = new InspireDbase(webDriver);
			String [] jobID = inspireDB.execute_Inspire_Query(strtrackingID);
			
			
			InspireScaler scaler = new InspireScaler(webDriver);
			
		
			//System.out.println("Inspire scaler is launched");
			
			  if (Objects.isNull(jobID[0]) ){
				  
				  test.log(LogStatus.FAIL,
							"Inspire database returns no record for the " +strtrackingID);
					
					System.out.println("Inspire database returns no record for the " +strtrackingID);
					
					TestBase.switchToWindow(1);
					driver.close();	
					//TestBase.switchToWindow(2);
										
				} 
			
			  else if(!jobID[0].isEmpty()) {
				  
			webDriver = TestBase.inspireurl();
				
				
			TestBase.switchToWindow(1);
			scaler.login();
			Thread.sleep(5000);
			
			
			if (scaler.inspireLoginFlag == true) {
			
			System.out.println(" job id going into inspire app:"+ jobID[0]);
					
				scaler.searchTheJobDetails(strtrackingID, jobID[0]);
				
				}else {
					
					test.log(LogStatus.FAIL,
							"Inspire Application can't be accessed since login failed");
					System.out.println("Inspire Application can't be accessed since login failed"); 				
				
				}
				
			} else {
				
				scaler.closejobscaler(strtrackingID, jobID[0]);
				
				test.log(LogStatus.FAIL,
						"Inspire Application can't be accessed since Inspire DB returned empty JobID");
				
				System.out.println("Inspire Application can't be accessed since Inspire DB returned empty JobID");
				
			}
			  
			 webDriver = TestBase.splunkurl();
			TestBase.switchToWindow(2);
			splunk.login();
			Thread.sleep(5000);	
		
		if (splunk.splunkLoginFlag == true) {
			
			splunk.searchTheJobDetails(strtrackingID, jobID[0], flownames);
			
			
/*
			if(!jobID[0].isEmpty()) {
			splunk.searchTheJobDetails(strtrackingID, jobID[0], flowname);
			
			}else {
				
				splunk.closejobscaler(strtrackingID, jobID[0]);
				
				test.log(LogStatus.FAIL,
						"Splunk Application can't be accessed since Inspire DB returned empty JobID");
				
				System.out.println("Splunk Application can't be accessed since Inspire DB returned empty JobID");
			}
			
			*/
			
		} else {
			test.log(LogStatus.FAIL,
					"Splunk Application can't be accessed since login failed");
			System.out.println("Splunk Application can't be accessed since login failed");
			
			driver.close();
			switchToWindow(0);
		}
		
		
		
			System.out.println("cid = 138");
			
			//test.setDescription("Database validation started");
			CIDDbase cidDB = new CIDDbase(webDriver);
			cidDB.execute_CID_Query("ActivityStatus_Log", strtrackingID);
			cidDB.execute_CID_Query("Event_Data", strtrackingID);
			cidDB.execute_CID_Query("Outbound_Data", strtrackingID);
			//cidDB.execute_CID_Query("BatchDetail_Data", strtrackingID);
			cidDB.execute_CID_Query("xref_Data", "ENB-HFC-DLQ");
			//test.log(LogStatus.PASS,"Database validation done");
			
		}
		
      else {
    	   test.log(LogStatus.FAIL,
					"No Tracking IDs found in the Input Sheet");
			System.out.println("No Tracking IDs found in the Input Sheet");
		}
	
	}

	
}
