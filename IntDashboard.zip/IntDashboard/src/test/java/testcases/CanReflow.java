package testcases;

import java.util.Hashtable;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.LogStatus;
import base.TestBase;
import pages.CIDDbase;
import pages.InspireDbase;
import pages.InspireScaler;
import pages.Tovendor;
import utilities.ExcelReader1;


//@Listeners(base.CustomListeners.class)
public class CanReflow extends TestBase {
	
	WebDriver webDriver = null;
		

	public CanReflow(WebDriver webDriver) {
		
		// TODO Auto-generated constructor stub
	}

	public void prepareTest(Hashtable<String,String> data,String Flowname) throws Exception {
		
			
		
		webDriver = TestBase.inspireurl();
		System.out.println("Inspire scaler is launched");

		String strtrackingID = data.get("tracking_id");
		System.out.println(strtrackingID);
		
		
		if(!strtrackingID.isEmpty()) {
						
	//	base.switchToWindow(0);
			
		InspireScaler scaler = new InspireScaler(webDriver);
		scaler.login();

//		ExcelReader1.createExcelReport();
				 
			 
		//Inspire Validation
		System.out.println("started with insire validation - DB ");
			InspireDbase inspireDB = new InspireDbase(webDriver);
			String[] jobID = inspireDB.execute_Inspire_Query(strtrackingID);

			if (scaler.inspireLoginFlag == true) {

				if(!jobID[0].isEmpty()) {
				scaler.searchTheJobDetails(strtrackingID, jobID[0]);
				
				}else {
					
					scaler.closejobscaler(strtrackingID, jobID[0]);
					
					test.log(LogStatus.FAIL,
							"No Sattus of Inspire Application  since Inspire DB returned empty JobID");
					
					System.out.println("No Sattus of Inspire Application  since Inspire DB returned empty JobID");
				}
				
			} else {
				test.log(LogStatus.FAIL,
						"Inspire Application can't be accessed since login failed");
				System.out.println("Inspire Application can't be accessed since login failed");
			}
		
			System.out.println("cid = 138");
			
			//test.setDescription("Database validation started");
			CIDDbase cidDB = new CIDDbase(webDriver);
			cidDB.execute_CID_Query("ActivityStatus_Log", strtrackingID);
			cidDB.execute_CID_Query("Event_Data", strtrackingID);
			cidDB.execute_CID_Query("Outbound_Data", strtrackingID);
			cidDB.execute_CID_Query("BatchDetail_Data", strtrackingID);
			cidDB.execute_CID_Query("xref_Data", "ENB-HFC-DLQ");
			//test.log(LogStatus.PASS,"Database validation done");
			
		}
		
      else {
    	   test.log(LogStatus.FAIL,
					"No Tracking IDs found in the Input Sheet");
			System.out.println("No Tracking IDs found in the Input Sheet");
		}
	
	}

	
}
