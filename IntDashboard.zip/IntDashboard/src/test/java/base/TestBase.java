package base;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeSuite;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import utilities.TestUtil;

import utilities.ExcelReader;
import utilities.ExcelReader1;
import utilities.ExtentManager;




public class TestBase  {
	
	public static WebDriver driver;
	public static Properties config = new Properties();
	public static Properties OR = new Properties();
	public static FileInputStream fis;
	public static String browser;
	public static Logger log = Logger.getLogger("Thahseena");
	public static ExtentReports rep = ExtentManager.getInstance();
	public static ExtentTest test;
	public static WebDriverWait wait; 
	//public static ExcelReader excel = new ExcelReader(System.getProperty("user.dir") + "\\src\\test\\resource\\excel\\Testvitto.xlsx");
	public static ExcelReader excel = new ExcelReader(System.getProperty("user.dir") + "\\src\\main\\resources\\excel\\TestData.xlsx");
	//public static ExcelReader excel = new ExcelReader(System.getProperty("user.dir") + ExcelReader1.ReportFolder +"\\TestData.xlsx");
	
	public static WebElement we;
	public String workingDir;
	
	
	protected static int defaultWaitTime = 60;
	protected final String LEFT = "left";
	protected final String RIGHT = "right";
	protected final String UP = "up";
	protected final String DOWN = "down";
	//private static SecretKeySpec secretKey;
	//private static byte[] key;
	
		  
	
	
	@BeforeSuite

	public void setUp() throws IOException, Exception {
		
		

		if (driver == null) {

			try {
				fis = new FileInputStream(
						System.getProperty("user.dir") + "\\src\\main\\resources\\properties\\Config.properties");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				config.load(fis);
				log.debug("Config file loaded !!!");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				fis = new FileInputStream(
						System.getProperty("user.dir") + "\\src\\main\\resources\\properties\\OR.properties");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				OR.load(fis);
				log.debug("OR file loaded !!!");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//Create Excel
			ExcelReader1.createExcelReport();
			
			
			
/*			
			
			System.out.println("DB invoke - TB");
			utilities.Database db = new Database();	
			
			if (config.getProperty("ENV").equalsIgnoreCase("RT")) {
			
			String url_db = (config.getProperty("cid_Url_RT") );
			String username_db = (config.getProperty("cid_User_RT"));
			String password_db = (config.getProperty("cid_Pswd_RT"));
			String query = (config.getProperty("Query"));
			String postdriver = (config.getProperty("driver"));
			
			System.out.println("connecting DB RT");
			db.createtestdata(postdriver,query, url_db, username_db, password_db);
			log.debug("Connected : " + "RT CID Database : Tracking ID");
			System.out.println("out of db java class");
			}
			else
			{
				System.out.println("connecting DB ST");
				String url_db = (config.getProperty("cid_Url_ST") );
				String username_db = (config.getProperty("cid_User_ST"));
				String password_db = (config.getProperty("cid_Pswd_ST"));
				String query = (config.getProperty("Query"));
				String postdriver = (config.getProperty("driver"));
				
				db.createtestdata(postdriver, query, url_db, username_db, password_db);
				log.debug("Connected : " + "ST CID Database : Tracking ID");
				System.out.println("getting answer for ST");
				
			}
			
	*/		
			
			System.out.println("testbase : 173");
			
			String driverPath = System.getProperty("user.dir")+"\\src\\main\\resources\\Driver\\";
			System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");
			
			
						
			
			System.out.println("testbase : 186");
			
			ChromeOptions options = new ChromeOptions();
			//System.out.println("cross chrome option instance");
			//options.addArguments("--window-size=1325,744");
			//options.addArguments("headless");
			//System.out.println("cross chrome option headless");
			//options.addArguments("window-size=600*1200");
			//options.addArguments("--window-size=1325,744");
			System.out.println("testbase : 194");
			 driver = new ChromeDriver(options);
			 //test.log(LogStatus.INFO, "Chrome Launched" );
			 System.out.println("testbase : 197");
			log.debug("Chrome Launched !!!");
			System.out.println("cross chrome option headless - launched");
		
			System.out.println("testbase : 199");		
				
			if (config.getProperty("ENV").equalsIgnoreCase("ST")) {
				
				
			
				//if(config.getProperty("URL_1").equalsIgnoreCase("SHP")) {
					
					//System.out.println(config.getProperty("Interactive_SHP_RT"));
					String url = config.getProperty("Interactive_ST");
					driver.get(url);
					
					 //testresultdata.put("2", new String[] {"Test Step Id", "Action", "Expected Result","Actual Result"});
					log.debug("Navigated to : " + config.getProperty("Interactive_ST"));
					System.out.println("ST");
					//test.log(LogStatus.PASS, "Interactive Dashboard- QA url has launched." );
								}
				
				else if (config.getProperty("ENV").equalsIgnoreCase("RT")){
					
				
				driver.get(config.getProperty("Interactive_RT"));
				System.out.println("RT");
				log.debug("Navigated to : " + config.getProperty("Interactive_RT"));
				//test.log(LogStatus.PASS, "Interactive Dashboard- RT url has launched. " );
					}
			
				else {
					System.out.println("The Environment is not defined....!!");
					log.debug("The Environment is not defined....!");
							}
			
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Integer.parseInt(config.getProperty("implicit.wait")),
					TimeUnit.SECONDS);
			 wait = new WebDriverWait(driver, 5);
			 
}
	}
	
	
	public static  WebDriver inspireurl() throws InterruptedException {
		
		
		
		if (config.getProperty("ENV").equalsIgnoreCase("ST")) {
			
			((JavascriptExecutor)driver).executeScript("window.open()");
			switchToWindow(1); 		   	
				driver.get(config.getProperty("inspireURL_ST"));
				
				
				
				log.debug("Navigated to : " + config.getProperty("inspireURL_ST"));
				test.log(LogStatus.PASS, "Interactive Dashboard- QA url has launched." );
							}
			
			else if (config.getProperty("ENV").equalsIgnoreCase("RT")){
				
				((JavascriptExecutor)driver).executeScript("window.open()");
			switchToWindow(1); 
						
			driver.get(config.getProperty("inspireURL_RT"));
			log.debug("Navigated to : " + config.getProperty("inspireURL_RT"));
			test.log(LogStatus.PASS, "Interactive Dashboard- RT url has launched. " );
				}
		
			else {
				System.out.println("The Environment is not defined for inspire....!!");
				log.debug("The Environment is not defined for inspire....!");
						}
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Integer.parseInt(config.getProperty("implicit.wait")),
				TimeUnit.SECONDS);
		 wait = new WebDriverWait(driver, 15);
		return driver;
		
		
	}
	
public static  WebDriver splunkurl() throws InterruptedException {
		
		
		
					
		((JavascriptExecutor)driver).executeScript("window.open()");
		
		switchToWindow(2); 		   	
		
		driver.get(config.getProperty("splunkurl"));
				
				
				
				log.debug("Navigated to : " + config.getProperty("splunkurl"));
				test.log(LogStatus.PASS, "Splunk  has launched." );
							
			
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Integer.parseInt(config.getProperty("implicit.wait")),
				TimeUnit.SECONDS);
		 wait = new WebDriverWait(driver, 15);
		return driver;
		
		
	}
	

		
		
		public static void click(String locator) throws InterruptedException {
			
			Thread.sleep(2000);
			By element = By.xpath(OR.getProperty(locator));  
			//wait = new WebDriverWait(driver, 40);
			//wait.until(ExpectedConditions.presenceOfElementLocated(element));
			
			driver.findElement(element).click();
			
			//test.log(LogStatus.INFO, "Clicking on : " + locator);
		}
		
		
public static void clickwithid(String locator, String tracking_id) throws InterruptedException {
	
			String tr = OR.getProperty(locator);
			//div[contains(text(),(//div[contains(text(),'7160835')])[1]
			
			By element = By.xpath(tr + "'" + tracking_id + "')])[1]"); 
			Thread.sleep(6000);
			wait.until(ExpectedConditions.presenceOfElementLocated(element));
			driver.findElement(element).click();
			//test.log(LogStatus.INFO, "Clicking on : " + locator);
		}
		
		
		public static   void setText(String locator, String id) {
			
			By element = By.xpath(OR.getProperty(locator));
			wait.until(ExpectedConditions.presenceOfElementLocated(element));
			driver.findElement(By.xpath(OR.getProperty(locator))).sendKeys(id);
			
				
		}
		
		public static   void setTextq(String locator, String id) {
			
			//String quer = " \"(index=\"mulesoft_ec_inspire\" correspondenceTrackingId=\ + id +\")\";
					String quer = "index=\"mulesoft_ec_inspire\" correspondenceTrackingId=\""+id+"\"";
			
			System.out.println(quer);
			
			By element = By.xpath(OR.getProperty(locator));
			wait.until(ExpectedConditions.presenceOfElementLocated(element));
			driver.findElement(By.xpath(OR.getProperty(locator))).sendKeys(quer);
			
				
		}
		
		public static void waitForElements(String string) {
			
			By element = By.xpath(OR.getProperty(string));

			WebDriverWait wait = new WebDriverWait(driver, 40);
			wait.until(ExpectedConditions.visibilityOfElementLocated(element));
		}
		
		public static   void waitForElement(String locator) {
			
			By element = By.xpath(OR.getProperty(locator));

			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfElementLocated(element));
		}
		
		public static  void clearText(String locator) {
			
			By element = By.xpath(OR.getProperty(locator));
			WebDriverWait wait = new WebDriverWait(driver, 5);
			wait.until(ExpectedConditions.presenceOfElementLocated(element));
			
			driver.findElement(By.xpath(OR.getProperty(locator))).clear();
			
		}
		
		public boolean isElementPresent(By element) throws InterruptedException {
			
			
			//By ele = By.xpath("//div[contains(text(),+ '(data.get("Tracking_ID"))']";
			//By element = By.xpath(OR.getProperty(locator));
			//Thread.sleep(13000);
					
			
			try {
				 WebDriverWait wait = new WebDriverWait(driver, 45);
				wait.until(ExpectedConditions.visibilityOfElementLocated(element));
				
				return true;

			} catch (Exception e) {
				e.printStackTrace();
				return false;
				
				
				
			}

		}
		
public boolean isElementPresents(By element) throws InterruptedException {
			
			
			//By ele = By.xpath("//div[contains(text(),+ '(data.get("Tracking_ID"))']";
			//By element = By.xpath(OR.getProperty(locator));
			//Thread.sleep(13000);
					
			By ele = By.xpath("(//div[text()='no results found.'])[2]");
			try {
				 WebDriverWait wait = new WebDriverWait(driver, 40);
				wait.until(ExpectedConditions.visibilityOfElementLocated(ele));
				
				return true;

			} catch (Exception e) {
				e.printStackTrace();
				return false;
				
				
				
			}

		}
		
		public static void selcalendar(String locator) throws IOException, InterruptedException {
			
			try {
				
				By element = By.xpath(OR.getProperty(locator));
				driver.findElement(element).click();
				log.info("Calender is selected & displayed");
				TestUtil.captureScreenshot();
	  	    	test.log(LogStatus.PASS, "Calender is selected & displayed"+test.addScreenCapture(TestUtil.screenshotName));
				Thread.sleep(3000);
				
				
				
			} catch (NoSuchElementException e) {
					System.out.println("TestBase 279 and OR : 21" );	
				} 
				
			
		}
			
		
		public static void editcalender(String locator, String Datenumber) throws IOException, InterruptedException {
			
			String seld = "(//table[@class='ui-datepicker-calendar']//tbody)//following::a[text()=";
			
			String dn = (OR.getProperty(Datenumber));
			By element = By.xpath(seld +"'"+dn+"']");
			
			System.out.println(element);
			//div[contains(text(),(//div[contains(text(),'7160835')])[1]
			
			//By element = By.xpath(tr + "'" + tracking_id + "')])[1]"); 
			
			System.out.println(dn + " in edit method");
			//OR.getProperty(locator)
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@class='today']")).click();
			log.debug("In Calender selected 'Today' hyperlink");
			TestUtil.captureScreenshot();
			test.log(LogStatus.PASS, "In Calender selected 'Today' hyperlink"+test.addScreenCapture(TestUtil.screenshotName));
			Thread.sleep(4000);
			
			//By element = By.xpath("(//table[@class='ui-datepicker-calendar']//tbody)//following::a[text()='1']");
			driver.findElement(element).click();
			log.debug("Modified date to 1st of Current Month");
			//TestUtil.captureScreenshot();
			//test.log(LogStatus.PASS, "Modified date to 1st of Current Month"+test.addScreenCapture(TestUtil.screenshotName));
			//Thread.sleep(4000);
			
			driver.findElement(By.xpath("//*[@id='moe-paragraph-6']//div[2]/span[3]/span[2]")).click();
			log.debug("bring it up to take screenshot, having date 1 selected in the calender view");
			TestUtil.captureScreenshot();
			test.log(LogStatus.PASS, "Modified date to 1st of Current Month"+test.addScreenCapture(TestUtil.screenshotName));
			Thread.sleep(9000);
			
			
			
		}
		
		
		
		// to select the flow	
			
			public static boolean chosedata(String tcname, ExcelReader excel){

				String sheetName="HFTrackingID";
				int rows = excel.getRowCount(sheetName);
				for(int rNum=2; rNum<=rows;rNum++){
				String testcase = excel.getCellData(sheetName, "test_case",  rNum);
				if(testcase.equalsIgnoreCase(tcname)){
				String runmode = excel.getCellData(sheetName, "run_mode", rNum);
				if (runmode.equalsIgnoreCase("Y")) {
				return true; 
				}
				else  
					return false;
					
				}
				else
				return false;
				}
				return true;
				 
			}
				
				
			
			
		
		
public static void ECalendar(String locator, String Datenumber) throws InterruptedException, IOException {
			
	System.out.println(Datenumber + " in Ecalendar method 1");
			
			By element = By.xpath(OR.getProperty(locator));
			 
	  	  	String parent = driver.getWindowHandle();
	  	  	Set<String>ids=driver.getWindowHandles();
	  	    java.util.Iterator<String> it= ids.iterator();
	  	   
	  	  	while(it.hasNext())
	  	  	{
	  	    String child_window=it.next();
	  	     if(!parent.equals(child_window)){
	  		   driver.switchTo().window(child_window);
	  		   log.info("Navigated to New Tab post clicking the Tracking ID ");
	  		   test.log(LogStatus.PASS, "Navigated to New Tab post clicking the Tracking ID");
	  		  // wait.until(ExpectedConditions.elementToBeClickable(element));
	  		   //JavascriptExecutor vb= (JavascriptExecutor)driver;
	  		 //  vb.executeAsyncScript("window.setTimeout(arguments[arguments.length - 1], 8000);");
	  		   TestUtil.captureScreenshot();
	  		   
	  		   Thread.sleep(6000);
	  		     		
	  	      	  //clicking the accept button  	
	  	    	 driver.findElement(element).click(); 
	  	    	 log.info("Work Ticket is Accepted");
	  	    	 TestUtil.captureScreenshot();
	  	    	test.log(LogStatus.PASS, "Work Ticket is Accepted"+test.addScreenCapture(TestUtil.screenshotName));
	  	    	 log.info("Child Window Title " + driver.getTitle());
	  	    	 
	  	    	System.out.println("TB: 548");
	  	    	 
	  	    	 Thread.sleep(8000);
				 
				click("Edit_icon");
				log.debug("Selected Edit Icon");
				test.log(LogStatus.PASS, "Selected Edit Icon");
				
				
				
				//selcalendar("sel_Datepicker");
				
				
				try {
				
				//editcalender("", Datenumber);
				
				
				} catch (NoSuchElementException e) {
  					System.out.println("Testbase: 354 and OR" );	
  				} 
				
				Thread.sleep(2000);
				 
	  	    	//Select Approval Icon
	  	  		 driver.findElement(By.xpath(OR.getProperty("aprv_icon"))).click();
	  	  		//Thread.sleep(4000); 
//	  	  		wait.until(ExpectedConditions.elementToBeClickable(aprv_icon));
	  	  		//vb.executeScript("arguments[0].click()", we);
	  	  		log.info("Approval Icon is clicked");
	  	  		TestUtil.captureScreenshot();
	  	  		test.log(LogStatus.PASS, "Approval Icon is clicked"+test.addScreenCapture(TestUtil.screenshotName));
	  	  		//driver.findElement(aprv_icon).click();
	  	  		driver.findElement(element).click();
		  	  		
	  	  		}
	  	  		
	  	  		driver.switchTo().window(parent);
	  	  		Thread.sleep(1000);
	  	  			
	  	  		}
	  	  		}
	  	  		
	  	  	
		
		
		
		
		
		public static void switchpage(String locator, String Ftype) throws InterruptedException, IOException {
			
			
			
			By element = By.xpath(OR.getProperty(locator));
			 
	  	  	String parent = driver.getWindowHandle();
	  	  	Set<String>ids=driver.getWindowHandles();
	  	    java.util.Iterator<String> it= ids.iterator();
	  	   
	  	  	while(it.hasNext())
	  	  	{
	  	    String child_window=it.next();
	  	     if(!parent.equals(child_window)){
	  		   driver.switchTo().window(child_window);
	  		   log.info("Navigated to New Tab post clicking the Tracking ID ");
	  		   test.log(LogStatus.PASS, "Navigated to New Tab post clicking the Tracking ID");
	  		  // wait.until(ExpectedConditions.elementToBeClickable(element));
	  		   JavascriptExecutor vb= (JavascriptExecutor)driver;
	  		   vb.executeAsyncScript("window.setTimeout(arguments[arguments.length - 1], 10000);");
	  		   TestUtil.captureScreenshot();
	  		   
	  		     		
	  	      	  //clicking the accept button  	
	  	    	 driver.findElement(element).click(); 
	  	    	 log.info("Work Ticket is Accepted");
	  	    	 	 TestUtil.captureScreenshot();
	  	    	test.log(LogStatus.PASS, "Work Ticket is Accepted"+test.addScreenCapture(TestUtil.screenshotName));
	  	    	
	  	    	 log.info("Child Window Title " + driver.getTitle());
	  	    	 
	  	    	 Thread.sleep(5000);
	  	    	log.info("waited ");
	  	    	
	  	    	if(Ftype == "Approve") {
	  	    		Thread.sleep(8000);
	  	    	 
	  	  		 //driver.findElement(By.xpath(OR.getProperty("aprv_icon"))).click();
	  	  		//Thread.sleep(4000); 
//	  	  		wait.until(ExpectedConditions.elementToBeClickable(aprv_icon));
	  	  		//vb.executeScript("arguments[0].click()", we);
	  	  		//log.info("Approval Icon is clicked");
	  	    		System.out.println("testbase : 633");
	  	  		TestUtil.captureScreenshot();
	  	  		test.log(LogStatus.PASS, "Approval Icon is clicked"+test.addScreenCapture(TestUtil.screenshotName));
	  	  		//driver.findElement(aprv_icon).click();
	  	  	driver.findElement(By.xpath(OR.getProperty("aprv_icon"))).click();
	  	  		driver.findElement(element).click();
	  	  	System.out.println("testbase : 638");
	  	  		
	  	    	}
	  	  		else if (Ftype == "Cancel") {
	  	  			Thread.sleep(8000);
	  	  			
	  	  		driver.findElement(By.xpath(OR.getProperty("Cancel_icon"))).click();
	  	  		//Thread.sleep(4000); 
//	  	  		wait.until(ExpectedConditions.elementToBeClickable(aprv_icon));
	  	  		//vb.executeScript("arguments[0].click()", we);
	  	  		log.info("Cancel Icon is clicked");
	  	  		TestUtil.captureScreenshot();
	  	  		test.log(LogStatus.PASS, "Cancel Icon is clicked"+test.addScreenCapture(TestUtil.screenshotName));
	  	  		//driver.findElement(aprv_icon).click();
	  	  		driver.findElement(element).click();
	  	  			
	  	  		
	  	  		}
	  	    	
	  	  		else if (Ftype == "Reassign"){
	  	  		
	  	  			
	  	  			try {
	  	  			
	  	  			System.out.println("to click reassign button");
	  	  			Thread.sleep(8000);
	  	  			
	  	  		driver.findElement(By.xpath(OR.getProperty("reassign_icon"))).click();
	  	  		
	  	  	//Thread.sleep(4000); 
//	  	  		wait.until(ExpectedConditions.elementToBeClickable(aprv_icon));
	  	  		//vb.executeScript("arguments[0].click()", we);
	  	  		log.info("Reassign Icon is clicked");
	  	  		TestUtil.captureScreenshot();
	  	  		test.log(LogStatus.PASS, "Reassign Icon is clicked"+test.addScreenCapture(TestUtil.screenshotName));
	  	  		//driver.findElement(aprv_icon).click();
	  	  		
	  	  		//Select from dropdown
	  	  		
	  	  		driver.findElement(By.xpath(OR.getProperty("dropd"))).click();
	  	  	Thread.sleep(8000);
	  	  		
	  	  	log.info("Dropdown Icon is clicked");
  	  		TestUtil.captureScreenshot();
  	  		test.log(LogStatus.PASS, "Dropdown Icon is clicked"+test.addScreenCapture(TestUtil.screenshotName));
  	  		//driver.findElement(aprv_icon).click();	
  	  		
  	  //	Thread.sleep(6000);
  	  		
  	  		//user name is selected from the list
  	  	
  	  	By eles = By.xpath("//div[contains(text(),'"+(OR.getProperty("assignto"))+"')]");
  	  	System.out.println(eles);
  	  	
  	  	
	  	  		WebElement userto = driver.findElement(eles);
            Actions builder = new Actions(driver);
           // Actions mouseOverHome = builder
            builder	.moveToElement(userto).doubleClick().perform();
            	  	  		
//	  	  		wait.until(ExpectedConditions.elementToBeClickable(aprv_icon));
	  	  		//vb.executeScript("arguments[0].click()", we);
	  	  		log.info("Username is selected from dropdown");
	  	  		TestUtil.captureScreenshot();
	  	  		test.log(LogStatus.PASS, "Username is selected from dropdown"+test.addScreenCapture(TestUtil.screenshotName));
	  	  		//driver.findElement(aprv_icon).click();	
	  	  		
		  	  	Thread.sleep(3000);
	  	  		//By appconfm_bt		= (By.xpath("//*[@id=\"approveButton\"]/span"));
	  	  		vb.executeAsyncScript("window.setTimeout(arguments[arguments.length - 1], 3000);");
	  	  		driver.findElement(element).click();
	  	  		
	  	  		//Ticket is assigned to the selected user name by clicking OK
		  	  	log.info("clicking OK");
	  	  		TestUtil.captureScreenshot();
	  	  		test.log(LogStatus.PASS, "Clicking OK"+test.addScreenCapture(TestUtil.screenshotName));
	  	  		//driver.findElement(aprv_icon).click();
	  	  		Thread.sleep(7000);
	  	  		
		  	  	log.info("Ticket is Reassigned & WinTab is closed");
			  	TestUtil.captureScreenshot();
	  	  		test.log(LogStatus.PASS, "Ticket is Reassigned & WinTab is closed"+test.addScreenCapture(TestUtil.screenshotName));	
	  	  		
	  	  	System.out.println("testbase : 721 - close");
	  	  		driver.close();
	  	  		
	  	  			} catch (NoSuchElementException e) {
	  					System.out.println("check assign icon in switch" );	
	  				} 
		  	  		
	  	  		}
	  	  		
	  	  		driver.switchTo().window(parent);
	  	  		Thread.sleep(5000);
	  	  			
	  	  		}
	  	  		}
	  	  		
	  	  	
		} 
		
		
	//from BasePage

		//public BasePage(WebDriver driver) {
		//	this.driver = driver;
		//	wait = new WebDriverWait(driver, 20);
		//} 
		//public void click(By element) throws InterruptedException {
		//	wait.until(ExpectedConditions.elementToBeClickable(element));
	//		driver.findElement(element).click();
		//}
		
		public void clickAndVerifyElement(By element,String message) throws InterruptedException {
			wait.until(ExpectedConditions.elementToBeClickable(element));
			driver.findElement(element).click();
			Thread.sleep(5000);
			verifyElementPresence(element,  message);
		}

	  
		public static  void fnSwitchFrame(By element) throws InterruptedException            
		{		
			
			List<WebElement> iframes = driver.findElements(By.tagName("iframe"));
			// print your number of frames
			System.out.println("Number of Iframes: : : : "+iframes.size());
			Thread.sleep(3000);
			
			for (WebElement iframe : iframes) {
				// switch to every frame
				System.out.println("Ifame:"+iframe);
				System.out.println(iframe.getAttribute("title"));
				driver.switchTo().frame(iframe);
				
				try{
					if(driver.findElement(element).isDisplayed());	
					{				
						System.out.println("frame has been switched to expected");
						break;
					}
					
				}catch(Exception e){
					driver.switchTo().defaultContent();
					System.out.println("FRAME not found");
				}
			}
			Thread.sleep(3000);
		}
		public void clickIfVisible(By element) throws InterruptedException {
			wait.until(ExpectedConditions.presenceOfElementLocated(element));
			if(driver.findElement(element).isEnabled()==true)
				wait.until(ExpectedConditions.elementToBeClickable(element));
			driver.findElement(element).click();
			Thread.sleep(10);
		}

		public void clickByJS(By element) {
			
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.findElement(element));
		}
		
		public void clickAction(By element) {
			
			Actions builder = new Actions(driver);
			builder.moveToElement(driver.findElement(element)).build().perform();
			
		}

		public String getText(By element) throws InterruptedException {
			wait.until(ExpectedConditions.presenceOfElementLocated(element));
			return driver.findElement(element).getText();
		}

		public static boolean isElementEnabled(String locator) throws InterruptedException {
			By element = By.xpath(OR.getProperty(locator));
			wait.until(ExpectedConditions.presenceOfElementLocated(element));
			if(driver.findElement(element).isEnabled()==true)
			{
				//test.log(LogStatus.PASS, "The object is enabled");
			}
			else
			{
				System.out.println("The object is disabled");
				//test.log(LogStatus.FAIL, "The object is disabled");
			}
			return true;
		}

		public void assertText(By element, String text) throws InterruptedException {
			wait.until(ExpectedConditions.presenceOfElementLocated(element));
			Assert.assertEquals(driver.findElement(element).getText(), text);
			if(driver.findElement(element).getText().equalsIgnoreCase(text))
			{
				//test.log(LogStatus.PASS, "The text is verified - "+text);
			}
			else
			{
				test.log(LogStatus.FAIL, "The text is not verified - "+text);
			}
		}

		public void takeScreenshot() throws InterruptedException, IOException {
			File file = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(file, new File("Screenshot.jpg"));
		}

		//public void setText(By element, String text) {
			
		//	wait.until(ExpectedConditions.presenceOfElementLocated(element));
		//	driver.findElement(element).sendKeys(text);
		//}

		public void clearText(By element) {
			wait.until(ExpectedConditions.presenceOfElementLocated(element));
			driver.findElement(element).clear();
		}


		public void waitForElement(By element) {

			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfElementLocated(element));
		}

		public void verifyLabel(By element, String strProperty, String strVerifytext)
		{
			if(strProperty.equalsIgnoreCase("text"))
			{
				System.out.println(driver.findElement(element).getText());
				if(driver.findElement(element).getText().equalsIgnoreCase(strVerifytext))
				{
					test.log(LogStatus.PASS, strVerifytext+" is displayed");
				}
				else
				{
					test.log(LogStatus.FAIL, strVerifytext+" is not displayed");
				}
			}else if(strProperty.equalsIgnoreCase("value"))
			{
				System.out.println(driver.findElement(element).getAttribute("value"));
				if(driver.findElement(element).getAttribute("value").equalsIgnoreCase(strVerifytext))
				{
					test.log(LogStatus.PASS, strVerifytext+" is displayed");
				}
				else
				{
					test.log(LogStatus.FAIL, strVerifytext+" is not displayed");
				}
			}
			else
			{
				test.log(LogStatus.FAIL, "No such property exists - "+strProperty);
			}
		}

		public boolean isElementDisabled(By element) throws InterruptedException {
			wait.until(ExpectedConditions.presenceOfElementLocated(element));
			if(driver.findElement(element).isEnabled()==true)
			{
				test.log(LogStatus.FAIL, "The object should not be enabled");
			}
			else
			{
				test.log(LogStatus.PASS, "The object is disabled");
			}
			return true;
		}

		public boolean verifyPasswordMask(By element,String strText) throws InterruptedException {
			waitForElement(element);
			driver.findElement(element).sendKeys("Test");
			if(driver.findElement(element).getText().contains("����"))
			{
				test.log(LogStatus.PASS, "The Password is masked in "+strText+" Text box");
			}
			else
			{
				test.log(LogStatus.FAIL, "The Password is not masked in "+strText+" Text box");
			}
			return true;
		}
		//verify presence of elements
		public boolean verifyElementPresence(By element, String strMessage) throws InterruptedException {
			if(driver.findElements(element).size()>0)
			{
				test.log(LogStatus.PASS, strMessage+" is present");
				return true;
			}
			else
			{
				test.log(LogStatus.FAIL, strMessage+" is not present");
				// captureSnapshot();
				return false;
			}
		}
		//verify absence of elements
		public boolean verifyElementAbsence(By element, String strMessage) throws InterruptedException {
			if(driver.findElements(element).size()>0)
			{
				test.log(LogStatus.FAIL, strMessage+" should not be present");       
				return false;
			}
			else
			{
				test.log(LogStatus.PASS, strMessage+" is not present"); 
				return true;
			}
		}

		/*verification of Elemnt's Presence with specific message*/

		public boolean verifyElementEnabled(By element, String objNAME) throws InterruptedException {

			wait.until(ExpectedConditions.presenceOfElementLocated(element));
			if(driver.findElement(element).isEnabled()==true)
			{
				test.log(LogStatus.PASS, "The object : '"+objNAME+"' is enabled");
			}
			else
			{
				test.log(LogStatus.FAIL, "The object : '"+objNAME+"' is disabled");
			}
			return true;
		}


		/* public void captureSnapshot() {
	    	WebDriver webDriver_fail = new DriverFactory().getInstance().getDriver();
	    	String base64Screenshot = "data:image/png;base64," + ((TakesScreenshot)webDriver_fail ).
					getScreenshotAs(OutputType.BASE64);
			test.log(LogStatus.INFO,
					test.addBase64ScreenShot(base64Screenshot));    	
	    }*/

		/*verification of Element's Absence with specific message*/

		public boolean verifyElementDisabled(By element, String strMessage) throws InterruptedException {
			wait.until(ExpectedConditions.presenceOfElementLocated(element));
			if(driver.findElement(element).isEnabled()==false)
			{
				test.log(LogStatus.PASS, strMessage+" is disabled");
			}
			else
			{
				test.log(LogStatus.FAIL, strMessage +" is enabled");
			}
			return true;
		}
		
		public static void switchToWindow( int windowNumber) {
			
			Set<String> s = driver.getWindowHandles();
			Iterator<String> ite = s.iterator();
			int i = 0;
			while (ite.hasNext() && i < 10) {
				String popupHandle = ite.next().toString();
				driver.switchTo().window(popupHandle);
				if (i == windowNumber)
					break;
				i++;
			}
		}
		
		public static void writeInEmailBody(String content) {

			String writeFileName = ("user.dir") + "\\Summary.txt";
			
			try {
				FileWriter fileWriter = new FileWriter(writeFileName, true);
				BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

				bufferedWriter.append(content);
				bufferedWriter.append(System.lineSeparator());
				bufferedWriter.close();

			} catch (IOException ex) {
				System.out.println("Error writing to file '" + writeFileName + "'");
			}

		}
		
		public static String takeScreenshot(String SubFolderName, String screenshotName)  {

			String encodedBase64 = null;;
			try {
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

				//String folderPATH = ExtentReporter.ReportFolder +"\\screenshots\\" + SubFolderName + "\\" + screenshotName + ".png";
				
				String folderPATH = ExcelReader1.ReportFolder +"\\screenshots\\" + SubFolderName + "\\" + screenshotName + ".jpeg";
				
				
				
							
				FileUtils.copyFile(scrFile, new File(folderPATH));

				System.out.println(folderPATH);

				
				try {

					@SuppressWarnings("resource")
					FileInputStream fileInputStream = new FileInputStream(folderPATH);
					byte[] bytes = new byte[(int) new File(folderPATH).length()];
					fileInputStream.read(bytes);
					encodedBase64 = new String(Base64.encodeBase64(bytes));

				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
			} catch (WebDriverException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return "data:image/png;base64," + encodedBase64;
		}
		
		
		
		
		public static void copyDirectory(String source, String destination) {

			try {
				File srcDir = new File(source);

				File destDir = new File(destination);

				FileUtils.copyDirectory(srcDir, destDir);
					

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		
		public static void copyfile(String source, String destination) {

			try {
				File srcDir = new File(source);

				File destDir = new File(destination);

				//FileUtils.moveFileToDirectory(srcDir, destDir, true);
				FileUtils.copyFileToDirectory(srcDir, destDir, true);
					

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		public static void delDirectory(String source, String destination) {

			try {
				File srcDir = new File(source);

				File destDir = new File(destination);

				FileUtils.cleanDirectory(srcDir);
					

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		
		 /*public static void setKey(String myKey)
		    {
		        MessageDigest sha = null;
		        try {
		            key = myKey.getBytes("UTF-8");
		            sha = MessageDigest.getInstance("SHA-1");
		            key = sha.digest(key);
		            key = Arrays.copyOf(key, 16);
		            secretKey = new SecretKeySpec(key, "AES");
		        }
		        catch (NoSuchAlgorithmException e) {
		            e.printStackTrace();
		        }
		        catch (UnsupportedEncodingException e) {
		            e.printStackTrace();
		        }
		    }
		    
		  
		 public static String decryptText(String strToDecrypt)
		    {
		        try
		        {
		            setKey("healthfirst");
		            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
		            cipher.init(Cipher.DECRYPT_MODE, secretKey);
		            return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
		        }
		        catch (Exception e)
		        {
		            System.out.println("Error while decrypting: " + e.toString());
		        }
		        return null;
		    }*/

	
		
		
		
				
}		
		
	


	

