package base;


import java.io.IOException;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.Reporter;

import com.relevantcodes.extentreports.LogStatus;

import utilities.ExcelReader1;
import utilities.TestUtil;



public  class CustomListeners extends TestBase implements ITestListener,ISuiteListener {
	public static String time = getDate();
	public 	String messageBody;
	public static String ReportName = "";
	public static String ReportFolder = "";
	public static String latestFolder = "";

	
	
	
	
	
	public static String getDate() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String name = dateFormat.format(date).toString().replaceFirst(" ", "_").replaceAll("/", "_").replaceAll(":",
				"_");
		return name;
	}
	
	public void onFinish(ITestContext arg0) {
		// TODO Auto-generated method stub
					}

	public void onStart(ITestContext arg0) {
		// TODO Auto-generated method stub
		
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult arg0) {
		// TODO Auto-generated method stub
		
	}

	public void onTestFailure(ITestResult arg0) {

		System.setProperty("org.uncommons.reportng.escape-output","false");
		try {
			TestUtil.captureScreenshot();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		test.log(LogStatus.FAIL,arg0.getName().toUpperCase()+" Failed with exception : "+arg0.getThrowable() );
		test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));
		
		
		
		
		Reporter.log("Click to see Screenshot");
		Reporter.log("<a target=\"_blank\" href="+TestUtil.screenshotName+">Screenshot</a>");
		Reporter.log("<br>");
		Reporter.log("<br>");
		Reporter.log("<a target=\"_blank\" href="+TestUtil.screenshotName+"><img src="+TestUtil.screenshotName+" height=200 width=200></img></a>");
		rep.endTest(test);
		rep.flush();
		
	}
	
	

	public void onTestSkipped(ITestResult arg0) {


		//test.log(LogStatus.SKIP, arg0.getName().toUpperCase()+" Skipped the test as it is not  defined, pls. check the Test data sheet");
		test.log(LogStatus.SKIP, " Skipped the test as it is not  defined, pls. check the Test data sheet");
		rep.endTest(test);
		rep.flush();
		
		
	}
	
	


	public void onTestStart(ITestResult result) {
		/*
		
		ReportFolder = System.getProperty("user.dir") + "/reports"  + "/" + "report"
				+ "_" + time ;
		latestFolder = System.getProperty("user.dir") + "/reports/Latest";
		
		try {
			FileUtils.cleanDirectory(new File (latestFolder));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		log.info("Starting test:  "+result.getMethod().getMethodName());
		

	//	test = rep.startTest(result.getName().toUpperCase());
		
	/*	
		try {
			TestUtil.captureScreenshot();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
		Reporter.log("Click to see Screenshot");
		Reporter.log("<a target=\"_blank\" href="+TestUtil.screenshotName+">Screenshot</a>");
		Reporter.log("<br>");
		Reporter.log("<br>");
		Reporter.log("<a target=\"_blank\" href="+TestUtil.screenshotName+"><img src="+TestUtil.screenshotName+" height=200 width=200></img></a>");
		rep.endTest(test);
		rep.flush();
		*/
	
	} 
	/*
	public synchronized static ExtentReports getReporter() {
		if (extent == null) {
			//Set HTML reporting file location;
			
			/*ReportName = ReportFolder+"\\report_" + time + ".html";	
			
			System.out.println(ReportName);*/
/*			
			ReportName = System.getProperty("user.dir") + "/reports"  + "/" + "report"
					+ "_" + time + "/" + "report" + "_" + time + ".html";
			
			System.out.println(ReportName);
			extent = new ExtentReports(ReportName, true);
		}
		return extent;
	}
*/
	public void onTestSuccess(ITestResult arg0) {
		
	/*	//System.setProperty("org.uncommons.reportng.escape-output","false");
		try {
			TestUtil.captureScreenshot();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//test.log(LogStatus.PASS, arg0.getName().toUpperCase()+" : Success");
		test.log(LogStatus.PASS, " ");
		//test.log(LogStatus.PASS, test.addScreenCapture(TestUtil.screenshotName));
		
		
		
		Reporter.log("Click to see Screenshot");
		Reporter.log("<a target=\"_blank\" href="+TestUtil.screenshotName+">Screenshot</a>");
		Reporter.log("<br>");
		Reporter.log("<br>");
		Reporter.log("<a target=\"_blank\" href="+TestUtil.screenshotName+"><img src="+TestUtil.screenshotName+" height=200 width=200></img></a>");
		rep.endTest(test);
		rep.flush();

/*
		test.log(LogStatus.PASS, arg0.getName().toUpperCase()+" PASS");
		rep.endTest(test);
		rep.flush();*/
		
	}
	/*
	
	public void onFinish(ISuite arg0) {
		
		/*MonitoringMail mail = new MonitoringMail();
		 
		try {
			messageBody = "http://" + InetAddress.getLocalHost().getHostAddress()
					+ ":8080/job/DataDrivenLiveProject/Extent_Reports/";
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		try {
			mail.sendMail(TestConfig.server, TestConfig.from, TestConfig.to, TestConfig.subject, messageBody);
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
*/
		
	


	public void onStart(ISuite arg0) {
		
		
		String source =( System.getProperty("user.dir") + "\\reports\\Latest\\" ); 
		String destination = ( System.getProperty("user.dir") + "\\reports\\Archive\\" );
		
		TestBase.copyDirectory( source, destination);
		TestBase.delDirectory( source, destination);
		//test.setDescription("Archived the old report" );
		System.out.println("Archived the old report" );
		rep.endTest(test);
		rep.flush();
				
	}

	public void onFinish(ISuite suite) {
		// TODO Auto-generated method stub
				
		
		
		
		String desfol =  ExcelReader1.ReportFolder;
		String source =( System.getProperty("user.dir")+"\\target\\surefire-reports\\html\\extent.html" ); 
		String destination = ( desfol + "\\Screenshot\\" );
		
			
		
		TestBase.copyfile( source, destination);
		
		System.out.println("Moved HTML report to Result folder" );
		
	}

}
