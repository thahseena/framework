package e2E;

/* Updated per date
 * splunk - done
 * down for shp and provider - done
 * search file  -
 * Integration - done
 * 
 */

import java.io.IOException;
import java.util.Hashtable;
import java.util.LinkedHashMap;

import org.openqa.selenium.WebDriver;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.LogStatus;
import base.TestBase;
import testcases.Apprflow;
import testcases.Approval;
import testcases.CanReflow;
import testcases.Cancel;
import testcases.Edit;
import testcases.Reassign;
import testcases.Shpcreatenapprove;
import testcases.Shpcreatencancel;
import testcases.loginTest;
import utilities.ExcelReader1;
import utilities.ExtentManager;
import utilities.TestUtil;


public class Iterflow extends TestBase {
	
	
	
	private static String CIDs = null;
	WebDriver webDriver = null;
	LinkedHashMap<String,Object[]> map = new LinkedHashMap<String,Object[]>();
	String LineItem ;
	String desfol =  ExcelReader1.ReportFolder;
	String repath = ( desfol + "\\" );
	
	//String Envi =  config.getProperty("ENV");
	
	
	@Test(priority = 1)
	public void login() throws InterruptedException, IOException{
		

		
		test = ExtentManager.startTest("Interactive Dashboard: HFIC", "Click here for  "+ "<a href='"+repath+"'>Report</a>");
		//test = ExtentManager.startTest("Interactive Dashboard: HFIC", "MEMBER");
		//test = ExtentManager.startTest("Login For Individual Letter","");
		
		if (config.getProperty("ENV").equalsIgnoreCase("RT")) {
				
		testcases.loginTest	login = new loginTest(webDriver);
	login.loginsTest();			
	
		}
	
		
	}
		
	
	@Test(priority =2,dataProviderClass=TestUtil.class,dataProvider="dp" )
	public void itrflow(Hashtable<String,String> data) throws Exception {
		
		String subflow = (data.get("subflow"));
		String flownames = (data.get("Defineflow"));
		
		if(data.get("Defineflow").equalsIgnoreCase("shp")) {
			
			test = ExtentManager.startTest((data.get("Defineflow"))+ (" functionalities: " + data.get("subflow")), 
					(data.get("Defineflow"))+ (" Type of functionality: " + data.get("subflow")));	
			System.out.println(data.get("Defineflow")+ ", "+ data.get("memberid"));
			
			
			
			
			 if(data.get("subflow").equalsIgnoreCase("create and Approve")) {
				 
				 
										
				System.out.println((data.get("subflow")));
				testcases.Shpcreatenapprove shpCA = new testcases.Shpcreatenapprove(webDriver);
				 CIDs = shpCA.CreateTicketApprove(data);
					System.out.println("tracking id from shp1: " +CIDs); 
				 
				
				 
				if(shpCA.success == true) {
					
					Thread.sleep(90000);
					testcases.Apprflow Donwstr = new Apprflow(webDriver);
					Donwstr.prepareTest(data , CIDs, flownames);
					map.put(" ", new Object[] {CIDs,(data.get("Defineflow")) , "Success"});
					ExcelReader1.resultup("Test_data_status", LineItem + "", map);
					test.setDescription("Downstream Validation is completed successfully for SHP");
					}
					
					else { 
						
						map.put(" ", new Object[] {(data.get("tracking_id")),(data.get("Defineflow")) , "Ticket creation failed"});
						ExcelReader1.resultup("Test_data_status", LineItem + "", map);
						TestUtil.captureScreenshot();
						test.log(LogStatus.FAIL, "Ticket creation failed"+test.addScreenCapture(TestUtil.screenshotName));  
						}
					
				}
			
			
		
	
				else if (data.get("subflow").equalsIgnoreCase("create and Cancel")) {
	
						Shpcreatencancel shpCC = new testcases.Shpcreatencancel(webDriver);
						CIDs = shpCC.CreateTicketCancel(data);
				 
				
				 
				if(shpCC.success == true) {
					
					Thread.sleep(90000);
					testcases.Apprflow Donwstr = new Apprflow(webDriver);
					Donwstr.prepareTest(data , CIDs, flownames);
					map.put(" ", new Object[] {CIDs,(data.get("Defineflow")) , "Success"});
					ExcelReader1.resultup("Test_data_status", LineItem + "", map);
					test.setDescription("Downstream Validation is completed successfully for SHP");
					}
					
					else { 
						
						map.put(" ", new Object[] {(data.get("tracking_id")),(data.get("Defineflow")) , "Ticket creation failed"});
						ExcelReader1.resultup("Test_data_status", LineItem + "", map);
						TestUtil.captureScreenshot();
						test.log(LogStatus.FAIL, "Ticket creation failed"+test.addScreenCapture(TestUtil.screenshotName));  
						}
					
				}
			
			
		}
	
		else  {
						
		test = ExtentManager.startTest((data.get("Defineflow"))+ (" FLow for Tracking_ID: " + data.get("tracking_id")), (data.get("Defineflow"))+ (" FLow for Tracking_ID: " + data.get("tracking_id")));	
		System.out.println(data.get("Defineflow")+ ", "+ data.get("tracking_id"));
		
		String flowname = (data.get("Defineflow"));
		
		String val = " ";
		
		if(data.get("Defineflow").equalsIgnoreCase("Approval")) {
			
					
					
			testcases.Approval	Approval = new Approval(webDriver);	
			Approval.Approvaltest(data);
			
				
			
			if(Approval.success == true) {
				
				Thread.sleep(5000);
				testcases.Apprflow Donwstr = new Apprflow(webDriver);
				Donwstr.prepareTest(data , flowname, val);
				System.out.println("Downstream Validation is completed successfully for Approval");
				map.put(" ", new Object[] {(data.get("tracking_id")),(data.get("Defineflow")) , "Success"});		
				ExcelReader1.resultup("Test_data_status", LineItem + "", map);
				System.out.println("updated result in the excel");
				
				}
			
				
				else { 
					
					map.put(" ", new Object[] {(data.get("tracking_id")),(data.get("Defineflow")) , "Tracking ID not Found in Dashboard1"});
					ExcelReader1.resultup("Test_data_status", LineItem + "", map);
					TestUtil.captureScreenshot();
					test.log(LogStatus.FAIL, "Ticket not found in the Dashboard[first check]"+test.addScreenCapture(TestUtil.screenshotName)); 
			System.out.println("No ID found");
				
			}
		
			
	}	
	
		else if(data.get("Defineflow").equalsIgnoreCase("Cancel")) {
			
			testcases.Cancel	Cancel = new Cancel(webDriver);	
			Cancel.cancelflow(data);
			
			if(Cancel.success == true) {
						
				Thread.sleep(5000);
				testcases.CanReflow Donwstr = new CanReflow(webDriver);
				Donwstr.prepareTest(data,flowname);
				map.put(" ", new Object[] {(data.get("tracking_id")),(data.get("Defineflow")) , "Success"});
				ExcelReader1.resultup("Test_data_status", LineItem + "", map);
				test.setDescription("Downstream Validation is completed successfully for Reassign");
			}
			
			else { 
				
				
				map.put(" ", new Object[] {(data.get("tracking_id")),(data.get("Defineflow")) , "Tracking ID not Found in the Dashboard"});
				ExcelReader1.resultup("Test_data_status", LineItem + "", map);
				TestUtil.captureScreenshot();
				test.log(LogStatus.FAIL, "Ticket not found in the Dashboard[first check]"+test.addScreenCapture(TestUtil.screenshotName)); }
			
		}
		
		else if(data.get("Defineflow").equalsIgnoreCase("Reassign")) {
			
			testcases.Reassign	Reassign = new Reassign(webDriver);	
			Reassign.Reassignflow(data);
			
			if(Reassign.success == true) { 
				
				Thread.sleep(5000);
				testcases.CanReflow Donwstr = new CanReflow(webDriver);
				Donwstr.prepareTest(data,flowname);
				map.put(" ", new Object[] {(data.get("tracking_id")),(data.get("Defineflow")) , "Success"});
				ExcelReader1.resultup("Test_data_status", LineItem + "", map);
				test.setDescription("Downstream Validation is completed successfully for Reassign");
				}
				
				else { 
					
					map.put(" ", new Object[] {(data.get("tracking_id")),(data.get("Defineflow")) , "Tracking ID not Found in the Dashboard"});
					ExcelReader1.resultup("Test_data_status", LineItem + "", map);
					TestUtil.captureScreenshot();
					test.log(LogStatus.FAIL, "Ticket not found in the Dashboard[first check]"+test.addScreenCapture(TestUtil.screenshotName));  }
				
			}
			
			
		
		else if(data.get("Defineflow").equalsIgnoreCase("Edit")) {
			testcases.Edit	Edit = new Edit(webDriver);	
			Edit.Edittest(data);
			
			if(Edit.success == true) {
				
				Thread.sleep(5000);
				testcases.Apprflow Donwstr = new Apprflow(webDriver);
				Donwstr.prepareTest(data , flowname, val);
				map.put(" ", new Object[] {(data.get("tracking_id")),(data.get("Defineflow")) , "Success"});
				ExcelReader1.resultup("Test_data_status", LineItem + "", map);
				test.setDescription("Downstream Validation is completed successfully for Edit");
				}
				
				else { 
					
					map.put(" ", new Object[] {(data.get("tracking_id")),(data.get("Defineflow")) , "Tracking ID not Found in the Dashboard"});
					ExcelReader1.resultup("Test_data_status", LineItem + "", map);
					TestUtil.captureScreenshot();
					test.log(LogStatus.FAIL, "Ticket not found in the Dashboard[first check]"+test.addScreenCapture(TestUtil.screenshotName));  }
				
			}
		
		
			
		else if((data.get("Defineflow").equalsIgnoreCase("Provider")) || (data.get("Defineflow").equalsIgnoreCase("HFIC"))) {
				
				System.out.println("into down validat for shp");
				Thread.sleep(5000);
				testcases.Apprflow Donwstr = new Apprflow(webDriver);
				Donwstr.prepareTest(data,  flowname, val);
				map.put(" ", new Object[] {(data.get("tracking_id")),(data.get("Defineflow")) , "Success"});
				ExcelReader1.resultup("Test_data_status", LineItem + "", map);
				test.setDescription("Downstream Validation is completed successfully" + data.get("Defineflow") );
				
											
			}	
			
	
		else if(data.get("Defineflow").equalsIgnoreCase("")) {
			map.put(" ", new Object[] {(data.get("tracking_id")),(data.get("Defineflow")) , "Skipped"});
			ExcelReader1.resultup("Test_data_status", LineItem + "", map);
			log.debug("Test case skipped as it was not defined");
			//test.log(LogStatus.SKIP, " Skipped the test as it is not  defined, pls. check the Test data sheet"); //this should be called only in onskip method - ilisteners
			throw new SkipException("Skipping the test as it is not  defined, pls. check the Test data sheet" );
			
			
	}
		}		
	
	}
	
	
	
	
	/*
	@AfterSuite(alwaysRun = true)
	public void tearDown() {
		webDriver.quit();
		if (testingEnv.equalsIgnoreCase(BaseTest.appEnv)) {
			test.info("Test Completed" + DriverFactory.getInstance().getDriver());
		} else if (testingEnv.equalsIgnoreCase("local")) {
			test.info("***Launching App in Local Environment***");
		}
	}
*/
	/*@AfterClass(alwaysRun = true)
	//@Parameters({ "environment" })

	void closedriver(String environment) throws IOException, InterruptedException {
		webDriver.quit();

	}*/
	
	@AfterSuite(alwaysRun = true)
	//@Parameters({ "environment" })

	 public void tearDown() {
		
		rep.endTest(test);
	     rep.flush();
	    // rep.close();
		driver.quit();

	}
	

}

