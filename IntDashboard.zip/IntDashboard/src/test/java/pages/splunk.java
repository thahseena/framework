package pages;

import java.io.File;
import java.io.IOException;
import java.util.Hashtable;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import base.TestBase;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;
import utilities.ExtentManager;
import utilities.PropertiesFileHandler;
import utilities.TestUtil;

public class splunk extends TestBase {

	public splunk(WebDriver driver) {
		super();
	}

	//ExtentTest test;
	
	public static boolean splunkLoginFlag;

	public static void login() throws IOException {
		
		TestBase.switchToWindow(2);
		
		

		splunkLoginFlag = false;
		
		try {
			String userName = config.getProperty("inspireURL_User");
			String password = config.getProperty("inspireURL_Pswd");
			
			System.out.println("Credentials = " + userName+"/" + password);
			Thread.sleep(6000);
			

			click("spusername");
			setText("spusername", userName);
			click("sppassword");
			setText("sppassword", password);
			
			Thread.sleep(3000);
			
			click("splogin"); 
			Thread.sleep(3000);
			waitForElement("spsearch");
			
		//	waitForElements("spsearchrange");
		//	click("spsearchrange");
		//	waitForElement("spsearchmode");
		//	Thread.sleep(2000);
			
			//click("spsearchmode");
			
			splunkLoginFlag = true;
			
			//TestUtil.captureScreenshot();
			test.log(LogStatus.PASS, "Successfully login into Splunk Application");
			

		} catch (Exception e) {

			//ExtentTestManager.getTest().log(LogStatus.FAIL, "Error with logging into the Inspire Application");
			TestUtil.captureScreenshot();
			test.log(LogStatus.FAIL, "Error with logging into the Splunk Application"+test.addScreenCapture(TestUtil.screenshotName));
			System.out.println("Error with logging into the Splunk Application" + e.toString());

			//TestBase.takeScreenshot("LoginPageError", "InspireScaler");

		}

	}

	public static void searchTheJobDetails(String strtrackingID, String strJobID, String flowname)  throws IOException, InterruptedException {

		try {
			System.out.println("*************\nSearching in the Splunk Application... \n*************");
			
			
			Thread.sleep(2000);
			waitForElement("spsearchrange");

			click("spsearchrange");
			waitForElement("spsearchmode");
			
			click("spsearchmode");
			waitForElement("spsearch");

			Thread.sleep(2000);
			click("spsearch");
			System.out.println("sp 1");
			Thread.sleep(5000);
			
			clearText("spsearch1");
			System.out.println("sp 2");

			
			Thread.sleep(5000);
			System.out.println("sp 3");
			setTextq("spsearch1", strtrackingID);
			System.out.println("sp 4");
			
			
			click("spclicksearch");
			//waitForElement("spshowlines1");
			
		//	click("spshowlines1");
			//click("Clickagan");
			//click("spshowlines2");
			
			Thread.sleep(5000);
			
			
			boolean splunkflag = false;

			try {
				waitForElement("spshowlines1");
				splunkflag = true;
			} catch (Exception e) {

				e.printStackTrace();

				if (isElementEnabled("uiLabelNoResult")) {
					TestUtil.captureScreenshot();
					test.log(LogStatus.FAIL,
							"Inspire Application has no records for the Tracking ID : " + strtrackingID+test.addScreenCapture(TestUtil.screenshotName));
					TestBase.takeScreenshot(strtrackingID, "InspireScaler_Page1");
					System.out.println("Inspire Application has no records for the Tracking ID : " + strtrackingID);
					
					Thread.sleep(1000);
					click("susername");
					Thread.sleep(1000);
					click("Ssignout");
					Thread.sleep(1000);
						
					
					driver.close();
					switchToWindow(0);
					
					
				}
			}
			
			System.out.println("flowname :"+ flowname);

			if (splunkflag == true) {
				
				/*
				include this when shp has more than one details to display
				String shp = "shp";
				
				if (!flowname.equals(shp))  {
					
				click("spshowlines1");
				System.out.println("sp 14");
				
				
				click("Clickagan");
				System.out.println("sp 15");
				
				
				
				Thread.sleep(6000);
				click("spshowlines2");
				System.out.println("sp 16");
				
				Thread.sleep(3000);
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("window.scrollBy(0,1000)");
				System.out.println("sp 11");
				
				}
				
				
				else {

					click("spshowlines1");
					System.out.println("splunk 12");  
					
					click("Clickagan");
					System.out.println("splunk 13");
					
					}
				
					*/
				
				
				
String shp = "shp";
				
				
					
				click("spshowlines1");
				System.out.println("sp 14");
				
				
				click("Clickagan");
				System.out.println("sp 15");
				
					
								
						System.out.println("Splunk displayed the details");
						TestUtil.captureScreenshot();
						test.log(LogStatus.PASS,"Splunk Application  : Record found for  : '" + strtrackingID + "' "+test.addScreenCapture(TestUtil.screenshotName));
						
						//String screenshotPatsh = System.getProperty("user.dir") + "\\Screenshot\\";
						//System.out.println(screenshotPatsh);
				       // Screenshot s=new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver);
				       // ImageIO.write(s.getImage(),"jpeg",new File(screenshotPatsh));				
						
						Thread.sleep(1000);
						click("susername");
						Thread.sleep(1000);
						click("Ssignout");
						Thread.sleep(1000);
							
							driver.close();
							switchToWindow(0);	
						

					}
			
			else {
						
						//Screenshot screenshot=new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver); 
						//ImageIO.write(screenshot.getImage(),"PNG",new File("path of the file"));
						
				        // capture screenshot and store the image
						

						System.out.println("splunk status  failed for : " + strtrackingID);
						TestUtil.captureScreenshot();
						test.log(LogStatus.FAIL, "Splunk Application  : Record not found for  : '"+ strtrackingID + "' "+test.addScreenCapture(TestUtil.screenshotName));
						
						Thread.sleep(1000);
						click("susername");
						Thread.sleep(1000);
						click("Ssignout");
						Thread.sleep(1000);
							
							driver.close();
							switchToWindow(0);
					}
					
					
			
		} catch (Exception e) {
			TestUtil.captureScreenshot();
			test.log(LogStatus.FAIL, "Error with working in the Splunk Application"+test.addScreenCapture(TestUtil.screenshotName));
			System.out.println("Error with working in the splunk Application" + e.toString());
			
			Thread.sleep(1000);
			click("susername");
			Thread.sleep(1000);
			click("Ssignout");
			Thread.sleep(1000);
				
				driver.close();
				switchToWindow(0);

			//TestBase.takeScreenshot(strtrackingID, "InspireScalerError");

		}

	}
	
	
	public static void closejobscaler(String strtrackingID, String strJobID) throws InterruptedException  {
		
		click("susername");
		Thread.sleep(1000);
		click("Ssignout");
		Thread.sleep(1000);
		
		driver.close();
		switchToWindow(0);
		
		System.out.println("Inspire Application is Closed as no JobId returned from DB");
		test.log(LogStatus.FAIL, "Inspire Application is Closed as no JobId returned from DB");
		
	
	}
}
