package pages;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;

import org.apache.commons.io.FileUtils;

import com.relevantcodes.extentreports.LogStatus;
import base.TestBase;



public class Tovendor extends TestBase{
	
	public static String ENV = (config.getProperty("ENV"));

	public static String StagingFolder = config.getProperty("StagingFolder_"+ ENV);
	
	public File[] filesFound;
	public ArrayList<String> fileList = new ArrayList<String>();
	
	public void isFileFound( final String trackingNumber) {
		
		System.out.println("TD: "+ trackingNumber);	

		try {
			File folder = new File(StagingFolder);

			System.out.println("*************\nSearching the PDF files...\n*************");
			
			FilenameFilter txtFileFilter = new FilenameFilter() {
				
			//	@Override
				public boolean accept(File dir, String name) {
					
					
				//	boolean tracknu = name.endsWith(".pdf");
					if ( (name.contains(trackingNumber))&&(name.endsWith(".pdf")) ) {
						fileList.add(dir + "\\" + name);
						
						return true;
					} else {
						return false;
					}
					
				//	if (name.contains(trackingNumber)) {
						// System.out.println(name);
					//	fileList.add(dir + "\\" + name);
					//	return true;

					//} else {
					//	return false;
					//}
				}

			};

			filesFound = folder.listFiles(txtFileFilter);
			//System.out.println("file list: "+ fileList);		

			
			if (fileList.isEmpty()) {
				System.out.println("The folder is empty: " + StagingFolder);
				test.log(LogStatus.INFO,
						"The folder is empty : " + StagingFolder);
		}

			for (String file : fileList) {
				if (file.contains(trackingNumber)) {

					System.out.println("filr: "+file);
					System.out.println("The tracking ID '" + trackingNumber + "' has  PDF File copied in the path : " + StagingFolder);
					test.log(LogStatus.PASS, "The tracking ID '" + trackingNumber + "' has the PDF file copied to the path : " + StagingFolder);
				}			
				else {
					
					System.out.println("The tracking ID '" + trackingNumber + "' has no PDF File in the path : " + StagingFolder);
					test.log(LogStatus.FAIL,
							"The tracking ID '" + trackingNumber + "' has no PDF File in the path : " + StagingFolder);
				}
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}
