package pages;

import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import base.TestBase;
import utilities.ExtentManager;
import utilities.PropertiesFileHandler;
import utilities.TestUtil;

public class InspireScaler extends TestBase {

	public InspireScaler(WebDriver driver) {
		super();
	}

	//ExtentTest test;
	
	public boolean inspireLoginFlag;

	public void login() throws IOException {

		inspireLoginFlag = false;
		String ENV = (config.getProperty("ENV"));

		try {
			String userName = config.getProperty("inspireURL_User");
			String password = config.getProperty("inspireURL_Pswd");
			
			System.out.println("Credentials = " + userName + password);

			click("uiTextUsername");
			setText("uiTextUsername", userName);
			click("uiTextPassword");
			setText("uiTextPassword", password);
			Thread.sleep(4000);

			click("uiBtnLogin"); 
			waitForElement("uiTabJobs");
			inspireLoginFlag = true;
			
			//TestUtil.captureScreenshot();
			test.log(LogStatus.PASS, "Successfully login into Inspire Application");
			

		} catch (Exception e) {

			//ExtentTestManager.getTest().log(LogStatus.FAIL, "Error with logging into the Inspire Application");
			TestUtil.captureScreenshot();
			test.log(LogStatus.FAIL, "Error with logging into the Inspire Application"+test.addScreenCapture(TestUtil.screenshotName));
			System.out.println("Error with logging into the Inspire Application" + e.toString());

			//TestBase.takeScreenshot("LoginPageError", "InspireScaler");

		}

	}

	public void searchTheJobDetails(String strtrackingID, String strJobID) throws IOException {

		try {
			System.out.println("*************\nSearching in the Inspire application... \n*************");
			
			TestBase.switchToWindow(1);

			Thread.sleep(2000);
			waitForElement("uiTabJobs");

			click("uiTabJobs");
			waitForElement("uiTabJobSearch");

			click("uiTabJobSearch");
			waitForElement("uiTxtJobID");

			Thread.sleep(2000);
			clearText("uiTxtJobID");
			setText("uiTxtJobID", strJobID);

			click("uiBtnSearch");
			boolean inspireFlag = false;

			try {
				waitForElement("uiLabelJobID");
				inspireFlag = true;
			} catch (Exception e) {

				e.printStackTrace();

				if (isElementEnabled("uiLabelNoResult")) {
					TestUtil.captureScreenshot();
					test.log(LogStatus.FAIL,
							"Inspire Application has no records for the Tracking ID : " + strtrackingID+test.addScreenCapture(TestUtil.screenshotName));
					TestBase.takeScreenshot(strtrackingID, "InspireScaler_Page1");
					System.out.println("Inspire Application has no records for the Tracking ID : " + strtrackingID);
					
					driver.close();
					switchToWindow(2);
				}
			}

			if (inspireFlag == true) {

				Thread.sleep(2000);
				
				By uiLabelJobID = By.xpath(OR.getProperty("uiLabelJobID"));
				
				if (driver.findElement(uiLabelJobID).getText().equals(strJobID)) {

					System.out.println("Job ID : " + strJobID + " is searched sucessfully");
					
					By uiLabelJobStatus = By.xpath(OR.getProperty("uiLabelJobStatus"));
					
					String uiJobStatus = driver.findElement(uiLabelJobStatus).getText();

					//TestBase.takeScreenshot(strtrackingID, "InspireScaler_Page1");
					
					
					Thread.sleep(4000);

					if (driver.findElement(uiLabelJobStatus).getText().equals("Completed")) {

						System.out.println("Job status is 'Completed'");
						TestUtil.captureScreenshot();
						test.log(LogStatus.PASS,"Inspire Scaler Application  : Status of : '" + strJobID + "' is Completed "+test.addScreenCapture(TestUtil.screenshotName));
						
						Thread.sleep(4000);
						click("uiLabelJobID");
						Thread.sleep(4000);

						switchToWindow(3);
						String uiStatus = driver.findElement(By.xpath("//div[text()='Status']/../following-sibling::div/div")).getText();

						TestUtil.captureScreenshot();
						test.log(LogStatus.PASS,"Status Sumamry of Tracking ID : '" + strJobID + "' is Completed "+test.addScreenCapture(TestUtil.screenshotName));

						System.out.println("Job status on New Window is : " + uiStatus);
						
						driver.close();
						switchToWindow(1);
						
						
						
						

					} else {

						System.out.println("Job status is : " + uiJobStatus);
						TestUtil.captureScreenshot();
						test.log(LogStatus.FAIL, "Inspire Scaler Application  :Status of : '"+ strJobID + "' is :" + uiJobStatus + "  "+test.addScreenCapture(TestUtil.screenshotName));
					}
					
				
					Thread.sleep(5000);
					click("prof");
					Thread.sleep(5000);
					click("sigout");
					Thread.sleep(5000);
					
					driver.close();
					switchToWindow(2);
					

				
				}
			}
		} catch (Exception e) {
			TestUtil.captureScreenshot();
			test.log(LogStatus.FAIL, "Error with working in the Inspire Application"+test.addScreenCapture(TestUtil.screenshotName));
			System.out.println("Error with working in the Inspire Application" + e.toString());

			//TestBase.takeScreenshot(strtrackingID, "InspireScalerError");

		}

	}
	
	
	public void closejobscaler(String strtrackingID, String strJobID) throws InterruptedException  {
		
		click("prof");
		Thread.sleep(5000);
		click("sigout");
		Thread.sleep(5000);
		
		driver.close();
		switchToWindow(2);
		
		System.out.println("Inspire Application is Closed as no JobId returned from DB");
		test.log(LogStatus.FAIL, "Inspire Application is Closed as no JobId returned from DB");
		
	}

}