package pages;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.LinkedHashMap;

import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import base.BaseTest;
import base.TestBase;
import utilities.DBHandler;
import utilities.ExcelReader;
import utilities.ExcelReader1;
import utilities.ExtentManager;
import utilities.PropertiesFileHandler;

public class InspireDbase extends TestBase {
	
	
	 public static String strJobID ="";
	
	public InspireDbase(WebDriver driver) {
		super();
	}
//	ExtentTest test;
	
	//public static ExtentReports rep = ExtentManager.getInstance();
	//public static ExtentTest test;
	
	public String[] execute_Inspire_Query(String trackingnumber)  {
		
		System.out.println("Into inspireDB");
		
		//String strJobID = null;
		
		String [] strJobID = new String [5];
		try {
			String sqlDRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
			
			String connectionUrl="";
			//strJobID = "";
			String query ="";
			
			System.out.println("*************\nQuerying the Inspire Database...\n*************");
			
			String ENV = (config.getProperty("ENV"));
			
			if (ENV.equalsIgnoreCase("RT")) {

			
				connectionUrl = (config.getProperty("inspiredb_RT"))+ ";authenticationScheme=NTLM;integratedSecurity=true;userName=user;password=password";
				System.out.println(connectionUrl);
			} 
			else if (ENV.equalsIgnoreCase("ST")) {
				
				connectionUrl = (config.getProperty("inspiredb_ST"))+ ";userName=user;password=password";
				System.out.println(connectionUrl);
			}
            else  {
				
				System.out.println("ERROR :   --->  Application Environment is not configured properly");
			}
			 
			String dbNAME = (config.getProperty("inspire_Database_"+ENV));
					
			 //query = "Select * from\n" + 
			//		" ["+dbNAME+"].[dbo].[Inspire_ScalerJobTracking]  where jobEndTime is not null  \n" + 
			//		" and correspondenceTrackingId = '"+trackingnumber+"'";
			 
			 query = "Select * from\n" + 
						" ["+dbNAME+"].[dbo].[Inspire_ScalerJobTracking]  where  correspondenceTrackingId = '"+trackingnumber+"'" + " order by jobEndTime asc";
			 
			 System.out.println(query);
			 
			String user = config.getProperty("inspire_User_"+ENV);
			String password = config.getProperty("inspire_Pswd_"+ENV);
			
			DBHandler handle = new DBHandler();
			ResultSet Result = handle.runTheQuery(sqlDRIVER,connectionUrl,query,user,password);

			
			ResultSetMetaData rsmd = Result.getMetaData();
			int columnsNumber = rsmd.getColumnCount();
			
			int LineItem =0 ;
			while (Result.next()) {
				
				LineItem++;
				LinkedHashMap<String,String> map = new LinkedHashMap<String,String>();

				for (int i = 1; i <= columnsNumber; i++) {
			       
			        String columnValue = Result.getString(i);
			        System.out.print("\n" + rsmd.getColumnName(i)+ " : " +columnValue + "\n");
			        
			        map.put(rsmd.getColumnName(i).trim(), columnValue.trim());
			       

			        if (rsmd.getColumnName(i).equals("scalerJobId")) {
			        	
			        	strJobID[0] = columnValue.trim(); 
			        	System.out.println("first scaler value "+ strJobID[0]);
			        }
			        
			        if (rsmd.getColumnName(i).equals("templateName")) {
			        	
			        	strJobID[1] = columnValue.trim();
			        	
			        	System.out.println("first tempalte value "+ strJobID[1]);
			        }
			        
			        
			         if(strJobID[0].isEmpty()) {
			        	 
			        	 test.log(LogStatus.FAIL,
			    					"Inspire Database has no records for the Tracking ID : " + trackingnumber);
			    			
			    			System.out.println("Inspire Database has no records for the Tracking ID : " + trackingnumber);	 
			         }
		    			
		    					    		
		    		/*
			        
			        if(!strJobID[2].isEmpty()) {
		    			
		    			test.log(LogStatus.FAIL,
		    					"Inspire Database has no records for the Tracking ID : " + trackingnumber);
		    			
		    			System.out.println("Inspire Database has no records for the Tracking ID : " + trackingnumber);}
		        //colum count 27
			        
			        //if (rsmd.getColumnName(i).equals("scalerJobId") {
			          if ((rsmd.getColumnName(i).equals("jobStatus") && (columnValue.equals("Triggering Systems Notified")))) {
			        		
			        		 
			        		//if (rsmd.getColumnName(1).equals("scalerJobId")) {
					        	strJobID[0] = Result.getString("scalerJobId");
					        	  System.out.println("Triggering 1 : "+strJobID[0]);
					        	  
					        	  //break; try it
					        	
					        //}
			        }
			        	
			        	else if ((rsmd.getColumnName(i).equals("jobStatus") && columnValue.equals("Interactive Cancel Ticket Successfully")) ){
			        		
			        		
			        		//if (rsmd.getColumnName(1).equals("scalerJobId")) {
			        			
			        			strJobID[0] = Result.getString("scalerJobId");
			        			
			        			System.out.println("Triggering 2: "+strJobID[0]);
			        	
			        		//}
			        }
			        	
			        	else if ((rsmd.getColumnName(i).equals("jobStatus") && columnValue.equals("Ticket Generated Successfully")) ){
			        		
			        		
			        		//if (rsmd.getColumnName(1).equals("scalerJobId")) {
			        			
			        			strJobID[0] = Result.getString("scalerJobId");
			        			
			        			System.out.println("Triggering 3: "+strJobID[0]);
			        	
			        		//}
			        	}
			        	
			        	else if ((rsmd.getColumnName(i).equals("jobStatus") && columnValue.equals("Exception occurred")) ){
			        		
			        		
			        		//if (rsmd.getColumnName(1).equals("scalerJobId")) {
			        			
			        			strJobID[0] = Result.getString("scalerJobId");
			        			
			        			System.out.println("Triggering exception 4 :  "+strJobID[0]);
			        	
			        		//}
			        	}
			        	
			        	else if ((rsmd.getColumnName(i).equals("jobStatus") && columnValue.equals("Job information received")) ){
			        		
			        		
			        		//if (rsmd.getColumnName(1).equals("scalerJobId")) {
			        			
			        			strJobID[0] = Result.getString("scalerJobId");
			        			
			        			System.out.println("Triggering exception 5 :  "+strJobID[0]);
			        	
			        		//}
			        	}
			        	
			          
			        	else
			        		
			        		test.log(LogStatus.FAIL,
			    					"Inspire Database has no records for the Tracking ID : " + trackingnumber);
			    			
			    			System.out.println("Inspire Database has no records for the Tracking ID : " + trackingnumber); 
			    			}
			          
			         */ 
			       	
			        
			         else  if (rsmd.getColumnName(i).equals("jobStatus")){
			        	
			        if(columnValue.equals("Triggering Systems Notified")) {
			        	
			        	System.out.println("JobStatus of : '" +trackingnumber+"' is Triggering Systems Notified" );
			        	//test.log(LogStatus.PASS, "Inspire-DB  [JobStatus of : '" +trackingnumber+"' for Row : '"+Result.getRow()+"' is Triggering Systems Notified ] ");
			        	test.log(LogStatus.PASS, "Inspire-DB  [JobStatus of : '" +trackingnumber+"'  is Triggering Systems Notified ");
			        	 
			        }else if(columnValue.equals("Ticket Generated Successfully")) {
			        	
			        	System.out.println("JobStatus of : '" +trackingnumber+"' is Ticket Generated Successfully" );
			        	test.log(LogStatus.PASS, "Inspire-DB  [JobStatus of : '" +trackingnumber+"' is Ticket Generated Successfully ");
			        	
			        }else if(columnValue.equals("Interactive Ticket Print Successfully")) {
			        	
			        	System.out.println("JobStatus of : '" +trackingnumber+"' is Interactive Ticket Print Successfully" );
			        	test.log(LogStatus.PASS, "Inspire-DB  [JobStatus of : '" +trackingnumber+"' is Interactive Ticket Print Successfully ");
			        	
			        	
			        }else if(columnValue.equals("Interactive Cancel Ticket Successfully")) {
	
			        	System.out.println("JobStatus of : '" +trackingnumber+"' is Interactive Cancel Ticket Successfully" );
			        	test.log(LogStatus.PASS, "Inspire-DB  [JobStatus of : '" +trackingnumber+"' is Interactive Ticket Cancelled Successfully ");	
			        	
			        }else if(columnValue.equals("Exception occurred")|| columnValue.equals("Job information received")  ) {
	
			        	System.out.println("JobStatus of : '" +trackingnumber+"' is Exception occurred" );
			        	test.log(LogStatus.PASS, "Inspire-DB  [JobStatus of : '" +trackingnumber+"' is Exception occurred" + "\n"+ "Check Inspire DB and Splunk for more information" );	
			        	
			        } 
			      
			        	 
			        
			        }

			    }
				
			    System.out.println("");
			    
			    ExcelReader1.storeIntoExcel("Inspire_DB_Data",LineItem+"",map);
			    
			}
			
			
		} catch (Exception e) {
			
			//ExtentTestManager.getTest().log(LogStatus.FAIL, "Error with Inspire DB : " + e.toString());
			System.out.println("Error with Inspire DB" + e.toString());
			e.printStackTrace();
		}
		
		
				
		System.out.println("Final tracking id going into other flow:"+strJobID[0]);
		return strJobID;
		
	}
		
}