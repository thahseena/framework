package utilities;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import core.BaseTest;

public class DBHandler extends BaseTest {
	
	
	public ResultSet runTheQuery(String driver, String url,String query,String username,String password) {

		ResultSet ResultSet = null;
		try {
			Connection con = DriverManager.getConnection(url,username,password);
			
			Statement stmt = con.createStatement();

			ResultSet = stmt.executeQuery(query);
		} catch (Exception e) {
			
			e.printStackTrace();
		}

		
		return ResultSet;
	}


}
