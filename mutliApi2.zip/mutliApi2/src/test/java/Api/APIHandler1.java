package Api;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import org.json.JSONObject;
import org.openqa.selenium.WebDriver;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.relevantcodes.extentreports.LogStatus;

import Reports.ExtentTestManager;
import core.BasePage;
import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class APIHandler1 extends BasePage {
	
public APIHandler1(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

public static String converToPrettyJSONFormat(String uglyJsonString) {
	
	Gson gson = new GsonBuilder().setPrettyPrinting().create();
	JsonParser jp = new JsonParser();
	JsonElement je = jp.parse(uglyJsonString);
	
	String prettyJsonString = gson.toJson(je);
	
	return prettyJsonString;
}

public static Headers getHeadersList(HashMap<String,String> key_value) {
	
	List<Header> headerList = new ArrayList<Header>();
	Headers header=null;
	
	for( Entry<String, String> element : key_value.entrySet()) {
		
	//Header h1= new Header(element.split(":")[0], element.split(":")[1]);
   
	headerList.add(new Header(element.getKey(), element.getValue()));
   
    header = new Headers(headerList);
	}
	return header;
}

public static String getOAUTHToken(String url,HashMap<String,String>headerParams)
{
	String accesstoken=null;
	try
	{
		
		ExtentTestManager.getTest().log(LogStatus.INFO,"Access Token : " + url);
		System.out.println("\nAccess Token : " + url);

		Response response = RestAssured.given()/*.config(RestAssured.config().sslConfig(new SSLConfig().allowAllHostnames()))*/
				.headers(headerParams)
				.when().get(url);

		int responseCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		
		System.out.println("Response Code : " + responseCode + " & Repsonse Body : " + converToPrettyJSONFormat(responseBody));
		
		if (responseCode == 200) {

			JsonPath jp = new JsonPath(responseBody);
			 accesstoken = jp.get("access_token");
			 
			ExtentTestManager.getTest().
					log(LogStatus.PASS,"Response Code : " + responseCode /*+ "<br />Repsonse Body : " + converToPrettyJSONFormat(responseBody)*/);

		}else {

			ExtentTestManager.getTest().
					log(LogStatus.FAIL,"Response Code : " + responseCode + "<br />Repsonse Body :<br /> " + converToPrettyJSONFormat(responseBody));
		}
	}
	catch(Exception e)
	{
		e.printStackTrace();
	    ExtentTestManager.getTest().log(LogStatus.ERROR,"Error with Access Token API : " + e.toString());
	}
	headerParams.clear();
	return accesstoken;

}

}