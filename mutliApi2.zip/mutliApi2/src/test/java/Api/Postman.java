package Api;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.net.ssl.HttpsURLConnection;

import org.apache.commons.io.FileUtils;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.relevantcodes.extentreports.LogStatus;
import com.relevantcodes.extentreports.ExtentTest;

import Reports.ExtentTestManager;
import core.BaseTest;
import io.restassured.path.json.JsonPath;
import utilities.APIHandler;
import utilities.ExcelReader;
import utilities.PropertiesFileHandler;


public class Postman {

	private static String accessToken;
	HashMap<String, String> headerParams = new HashMap<String, String>();
	private String Client_Secret;
	private String Client_ID;
	//public static List<String> trackingID = new ArrayList<String>();
	
	public static String environment = PropertiesFileHandler.readProperty("Env");
	String path = System.getProperty("user.dir") +PropertiesFileHandler.readProperty("testdata");
	static LinkedHashMap<String,Object[]> map = new LinkedHashMap<String,Object[]>();
	// public static Response response;
	 StringBuilder  response ;
	 String respo;
	private String val1;
	public static String val2;
	private String val3;
	private int finalr;
	private String trackingID;
	public static boolean lettertriger;
	
	public static ExtentTest test;
	private String val4;
	

	 /*
	public void getTrackingID() {

		try {
			/** Token */

/*			URL object = new URL(PropertiesFileHandler.readProperty("tokenURL_"+environment));
			
			
			Client_ID = PropertiesFileHandler.readProperty("client_id_"+environment);
			Client_Secret = PropertiesFileHandler.readProperty("client_secret_"+environment);
			
			System.out.println(Client_ID);
			System.out.println(Client_Secret);
			
			
			HttpsURLConnection connection = (HttpsURLConnection) object.openConnection();
			
			connection.setRequestProperty("Client_ID", Client_ID);
			connection.setRequestProperty("Client_Secret", Client_Secret);
			connection.setRequestProperty("grant_type", "client_credentials");
			connection.setRequestProperty("Scope", "READ");
			connection.setRequestMethod("PUT");
			

			int responseCode = connection.getResponseCode();

			BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			if (responseCode == 200) {

				JsonPath jp = new JsonPath(response.toString());
				accessToken = jp.get("access_token");

				ExtentTestManager.getTest().log(LogStatus.PASS,
						"Response Code : " + responseCode + "<br />Access Token : " + accessToken);

			} else {

				ExtentTestManager.getTest().log(LogStatus.FAIL, "Response Code : " + responseCode
						+ "<br />Repsonse Body :<br /> " + APIHandler.converToPrettyJSONFormat(response.toString()));
			}
			/** Get Corrid */
/*
			apiPutRequest();

			getTrackingIDNumber();

		} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.getTest().log(LogStatus.ERROR, "Error with GetCorrid API : " + e.toString());
		}

	}
*/	
	public String token(String aci, String acs, String auth1) {

		try {
			/** Token */
			
			
			//String urls = (PropertiesFileHandler.readProperty("tokenURL_"+environment));
			String urls = auth1;
			System.out.println(urls);

			//URL object = new URL(PropertiesFileHandler.readProperty("tokenURL_"+environment));
			URL object = new URL(auth1);
			Client_ID = aci;
			Client_Secret = acs;
			
			HttpsURLConnection connection = (HttpsURLConnection) object.openConnection();
			connection.setRequestProperty("Client_ID", Client_ID);
			connection.setRequestProperty("Client_Secret", Client_Secret);
			connection.setRequestProperty("grant_type", "client_credentials");
			connection.setRequestProperty("Scope", "READ");
			
			
			int responseCode = connection.getResponseCode();

			BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			if (responseCode == 200) {

				JsonPath jp = new JsonPath(response.toString());
				accessToken = jp.get("access_token");

				ExtentTestManager.getTest().log(LogStatus.PASS,
						"Response Code : " + responseCode + "<br />Access Token : " + accessToken);

			} else {

				//ExtentTestManager.getTest().log(LogStatus.FAIL, "Response Code : " + responseCode
				//		+ "<br />Repsonse Body :<br /> " + APIHandler.converToPrettyJSONFormat(response.toString()));
			}
			
			System.out.println("*************************** access token created : " + accessToken+ " **********************" );
			
		
		} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.getTest().log(LogStatus.ERROR, "Error with GetCorrid API : " + e.toString());
		}
		return accessToken;

	}

	@SuppressWarnings("static-access")
	public String trackingid(String tci, String tcs, String tid, String auths,String trackingidp, String snumb) {
		
		System.out.println("***************************\n tracking id generation process \n**********************");

		try {
			// ------------------------- List of User passed parameters
			// ----------------------------

//			String ePU = PropertiesFileHandler.readProperty("GetCorrId_"+environment);
			String ePU = tid;
			Client_ID = tci;
			Client_Secret = tcs;
			String firstauth = auths;
			
			Jsoncnvt objCF = new Jsoncnvt();
			
			String updatedBody = objCF.fupdateListinValues(trackingidp,snumb);
			//System.out.println("returned value" + updatedBody);
/*
			String payloadtemplatepath = System.getProperty("user.dir")
					+ PropertiesFileHandler.readProperty("GetCorrID_Paylaod");
			String TestDataWB = System.getProperty("user.dir") + PropertiesFileHandler.readProperty("testdesign");

			Jsoncnvt objCF = new Jsoncnvt();

			// ------------------------ Update Data from the data files as required
			// ---------------------------
			String inputPayload = objCF.freadTextFromFile(payloadtemplatepath).replace("*{", "{").replace("}*", "}");

			Map<Integer, Map<String, String>> inputDataMap = objCF.fGetDatafromExcelasMap(TestDataWB, "trackingid");

			java.util.Set<Integer> intRows = inputDataMap.keySet();

			// run for each row on excel
			for (int row : intRows) {

				String updatedBody = objCF.fupdateListofValues(inputPayload, inputDataMap.get(row));
				String updatedBodywithLineItems = updatedBody;

				// String timeforReport =objCF.fgetUniqueTimeStamp();

				/**
				 * WritePathFile
				 * =userDirectory+"\\API_Input\\JSON_PayLoad_Created\\"+TemplatePayloadfile+timeforReport;
				 * writeTofile = new File(WritePathFile); Files.write(Paths.get(WritePathFile),
				 * updatedBodywithLineItems.getBytes());
				 */

				// ---------------------------------- Make the Request
				// -----------------------------------
				//System.out.println(trackingidp);

				URL object = new URL(ePU);
				HttpsURLConnection connection = (HttpsURLConnection) object.openConnection();

				connection.setRequestProperty("Client_ID", Client_ID);
				connection.setRequestProperty("Client_Secret", Client_Secret);
				connection.setRequestProperty("Authorization", "Bearer " + firstauth);
				connection.setRequestProperty("Content-Type", "application/json");
				connection.setRequestMethod("PUT");
				connection.setDoOutput(true);
				OutputStreamWriter wr = new OutputStreamWriter(connection.getOutputStream());
				wr.write(updatedBody);
				wr.flush();
				int responseCode = connection.getResponseCode();

				BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
				String inputLine;
				StringBuffer response = new StringBuffer();
				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();

				//System.out.println(response);
				// ---------------------------------- Verify the Response
				// -----------------------------------
				if (responseCode == 200) {

					if (response.toString().contains("errorText")) {
						ExtentTestManager.getTest().log(LogStatus.ERROR,
								"Response Code : " + responseCode + "<br />Repsonse Body :<br /> "
										+ APIHandler.converToPrettyJSONFormat(response.toString()));

					} else {
						
						
						JsonPath jp = new JsonPath(response.toString());
						//String[] strArrLen = (jp.get("message").toString()).split(":");
						String[] strArrLen = (jp.get("message").toString()).split(":");
						
						 val1 = 	jp.get("message").toString();
						// val4 = 	jp.get("Msg").toString();
						// trackingID = 	jp.get("Response_Tracking_Id").toString();
						// val3 = 	jp.get("status").toString();
						
						
						System.out.println(val1);

						trackingID = strArrLen[strArrLen.length - 1];
						
						
						 
						 
						//trackingID.add(id);

						ExtentTestManager.getTest().log(LogStatus.PASS,
								"Response Code : " + responseCode + "<br />Tracking ID : " + trackingID);
						
						System.out.println("inside gen tracking id class tracking id value:"+trackingID);	
						
						//getTrackingIDNumber();

					}

				} else {
					ExtentTestManager.getTest().log(LogStatus.FAIL,
							"Response Code : " + responseCode + "<br />Repsonse Body :<br /> "
									+ APIHandler.converToPrettyJSONFormat(response.toString()));
					
					//writeTrackingIDToExcel(System.getProperty("user.dir") +PropertiesFileHandler.readProperty("testdesign"));

					System.out.println(response);
				}

			

		} catch (Exception e) {
			ExtentTestManager.getTest().log(LogStatus.ERROR,
					"Exception has been Received on Retreiving the data :" + e.getMessage());
			e.printStackTrace();
		}
		return trackingID;

	}

	public void getTrackingIDNumber() throws Exception {

		if (!trackingID.isEmpty()) {

			ExtentTestManager.getTest().log(LogStatus.INFO,
					"Tracking IDs are generated <br /> " + trackingID.toString());

			System.out.println(trackingID);
			//System.out.println("***************************\n tracking id generation done \n**********************");

			//writeTrackingIDToExcel(System.getProperty("user.dir") +PropertiesFileHandler.readProperty("testdesign"));

		} else {

			ExtentTestManager.getTest().log(LogStatus.FAIL,
					"No Tracking IDs are generated <br /> " + trackingID.toString());

			//System.out.println(trackingID);
		}

	}

	public void copyInputExcelToSharePATH() {

		try {
			String InputSheet = System.getProperty("user.dir") + PropertiesFileHandler.readProperty("API_var");
			File srcDir = new File(InputSheet);

			//File destDir = new File(System.getProperty("user.dir") + "/src/main/resources/Excel/S_letter_TestData.xlsx");
			File destDir = new File(PropertiesFileHandler.readProperty("dataSheet_Shared"));

			FileUtils.copyFile(srcDir, destDir);
			ExtentTestManager.getTest().log(LogStatus.INFO,
					"Input sheet is copied to the share path for Content Validation");
			System.out.println("Input sheet is copied to the share path for Content Validation : " + destDir.getName());
			
			Thread.sleep(10000);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/*
	public void writeTrackingIDToExcel(String data) throws Exception {

		try {

			InputStream ExcelFileToRead = new FileInputStream(data);
			XSSFWorkbook workBook = new XSSFWorkbook(ExcelFileToRead);
			XSSFSheet sheet = workBook.getSheet("Letterkey");

			int reqColNumber = ExcelReader.getColumnNumber(sheet.getRow(0), "trackingid");

			int rowNumber = 1;
			for (String id : trackingID) {
				
				System.out.println(id);

				sheet.getRow(rowNumber).getCell(reqColNumber).setCellValue(id);
				rowNumber++;
			}

			FileOutputStream fileOut = new FileOutputStream(data);

			System.out.println("Excel Input sheet is updated with Tracking IDs : " + data);
			ExtentTestManager.getTest().log(LogStatus.INFO, "Input sheet is updated with Tracking IDs : " + data);

			workBook.write(fileOut);
			workBook.close();
			fileOut.flush();

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}
	

	public void writeTrackingIDToExcels(String data) throws Exception {

		try {

			InputStream ExcelFileToRead = new FileInputStream(data);
			XSSFWorkbook workBook = new XSSFWorkbook(ExcelFileToRead);
			XSSFSheet sheet = workBook.getSheet("Letterkey");

			int reqColNumber = ExcelReader.getColumnNumber(sheet.getRow(0), "trackingid");

			int rowNumber = 2;
			for (String id : trackingID) {
				
				System.out.println(id);

				sheet.getRow(rowNumber).getCell(reqColNumber).setCellValue(id);
				rowNumber++;
			}

			FileOutputStream fileOut = new FileOutputStream(data);

			System.out.println("Excel Input sheet is updated with Tracking IDs : " + data);
			ExtentTestManager.getTest().log(LogStatus.INFO, "Input sheet is updated with Tracking IDs : " + data);

			workBook.write(fileOut);
			workBook.close();
			fileOut.flush();

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}
	*/
	public void writeToExcel(String data, String respo) throws Exception {

		try {
			System.out.println("response :" + respo);
			InputStream ExcelFileToRead = new FileInputStream(data);
			XSSFWorkbook workBook = new XSSFWorkbook(ExcelFileToRead);
			XSSFSheet sheet = workBook.getSheetAt(1);

			int reqColNumber = ExcelReader.getColumnNumber(sheet.getRow(0), "ActualResults");

			int rowNumber = 2;
			
			for ( rowNumber = 2; rowNumber < sheet.getPhysicalNumberOfRows(); ) {
			    final Row row = sheet.getRow(rowNumber);
			    
			    sheet.getRow(rowNumber).getCell(reqColNumber).setCellValue(respo);
			
			
			    	rowNumber++;
			    
			    }
			   
			
			
			
					FileOutputStream fileOut = new FileOutputStream(data);

			System.out.println("Excel Input sheet is updated with response : " + data);
			ExtentTestManager.getTest().log(LogStatus.INFO, "Input sheet is updated with response: " + data);

			workBook.write(fileOut);
			workBook.close();
			fileOut.flush();

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}

public static void resultup(String data,  LinkedHashMap<String, Object[]> map) {
		
		try {
			InputStream ExcelFileToRead = new FileInputStream(data);
			XSSFWorkbook workBook = new XSSFWorkbook(ExcelFileToRead);
			XSSFSheet sheet = workBook.getSheet("apiresponse");
			

			int LastRow = sheet.getLastRowNum();

			if (LastRow < 1) {
				
				System.out.println("header created");
				XSSFRow header = sheet.createRow(LastRow);
				XSSFRow row1 = sheet.createRow(LastRow+1);
				int counter = 0;
				for (Entry<String, Object[]> keys : map.entrySet()) {
					
					String Key = keys.getKey();
					Object [] obj1 = keys.getValue();
					
			
								
					
					for (Object obj : obj1) {
					
			            Cell cell = row1.createCell(counter++);
			           		           
			            if(obj instanceof Date) 
			                cell.setCellValue((Date)obj);
			            else if(obj instanceof Boolean)
			                cell.setCellValue((Boolean)obj);
			            else if(obj instanceof String)
			                cell.setCellValue((String)obj);
			            else if(obj instanceof Double)
			                cell.setCellValue((Double)obj); 

					sheet.autoSizeColumn(counter);
				}
			} }
			else {
				
				System.out.println("header already given");

				XSSFRow row1 = sheet.createRow(LastRow +1 );
				int counter = 0;
					for (Entry<String, Object[]> keys : map.entrySet()) {
					
					String Key = keys.getKey();
					Object [] obj1 = keys.getValue();
					for (Object obj : obj1) {
					
			            Cell cell = row1.createCell(counter++);
			           		           
			            if(obj instanceof Date) 
			                cell.setCellValue((Date)obj);
			            else if(obj instanceof Boolean)
			                cell.setCellValue((Boolean)obj);
			            else if(obj instanceof String)
			                cell.setCellValue((String)obj);
			            else if(obj instanceof Double)
			                cell.setCellValue((Double)obj); 

					sheet.autoSizeColumn(counter);
				}
			}
			}
			FileOutputStream fileOut = new FileOutputStream(data);

			System.out.println("values written" + data);
			//test.log(LogStatus.PASS, "Inspire DB record exported successfully");
			workBook.write(fileOut);
			System.out.println("values written" + data);
			workBook.close();
			System.out.println("values written" + data);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

		

	}	

	@SuppressWarnings("static-access")
	public void apiGETRequest(String api, String ci, String cs)  {
		
		try{
			// -------------------------   List of User passed parameters  ----------------------------
			System.out.println("apirul in getemethod:" + api);
			String ePU = api;
			Client_ID = ci;
			Client_Secret = cs;

						// ---------------------------------- Make the Request ----------------------------------- 	
			
				URL object = new URL(ePU);
				HttpsURLConnection connection = (HttpsURLConnection) object.openConnection();

				connection.setRequestProperty("Client_ID", Client_ID);
				connection.setRequestProperty("Client_Secret", Client_Secret);
				//connection.setRequestProperty("grant_type", "client_credentials");
				//connection.setRequestProperty("Scope", "WRITE");
				connection.setRequestProperty("Authorization", "Bearer " + accessToken);
				//connection.setRequestProperty("Content-Type", "application/json");
				connection.setRequestMethod("GET");
				connection.setDoOutput(true);
				connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.72 Safari/537.36");
				System.out.println("Access Token: "+ accessToken);
				
				System.out.println("AClient_ID: "+ Client_ID);
				System.out.println("Client_Secret: "+ Client_Secret);
				
				
				
				
				String responsemessage = connection.getResponseMessage();
				
				System.out.println("responsemsg: "+ responsemessage);
				
				int responseCode = connection.getResponseCode();
				
				System.out.println("responseCode: "+ responseCode);
				
				
				
				if (responseCode == 401) {
					
/*
				BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
				String inputLine;
				StringBuffer response = new StringBuffer();
				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();

	*/			//System.out.println(response);
				
				BufferedReader in = new BufferedReader(	new InputStreamReader(connection.getErrorStream())) ;

	                String inputLine;
	                StringBuilder  response = new StringBuilder();

	                while ((inputLine = in.readLine()) != null) {

	                	response.append(inputLine);
	                	response.append(System.lineSeparator());
	                	
	                }
	                in.close();
	                System.out.println("Error response: " +response.toString());
	                
	                
	                
	                 respo = response.toString();
	                 
	                 ExtentTestManager.getTest().log(LogStatus.FAIL, "Response Code : " + responseCode
	 						+ "<br />Repsonse Body :<br /> " + APIHandler.converToPrettyJSONFormat(response.toString()));
	                 
	                 map.put(" ", new Object[] {respo, "Failure"});
	         		resultup(path,  map);
	                
	               // writeToExcel(System.getProperty("user.dir") +PropertiesFileHandler.readProperty("testdesign"), respo);
	                
				}
				
				else {

					BufferedReader in = new BufferedReader(	new InputStreamReader(connection.getInputStream())) ;

	                String inputLine;
	                StringBuilder  response = new StringBuilder();

	                while ((inputLine = in.readLine()) != null) {

	                	response.append(inputLine);
	                	response.append(System.lineSeparator());
	                	
	                }
	                in.close();
				System.out.println("Positive: " +response.toString());
				  respo = response.toString();
				  
				  ExtentTestManager.getTest().log(LogStatus.PASS, "Response Code : " + responseCode
							+ "<br />Repsonse Body :<br /> " + APIHandler.converToPrettyJSONFormat(response.toString()));
	                
	               // writeToExcel(System.getProperty("user.dir") +PropertiesFileHandler.readProperty("testdesign"), respo);				
								
				// ---------------------------------- Verify the Response -----------------------------------  
				if(responseCode==200){

					if (response.toString().contains("errorText")) {
						ExtentTestManager.getTest().log(LogStatus.ERROR,
								"Response Code : " + responseCode + "<br />Repsonse Body :<br /> "
										+ APIHandler.converToPrettyJSONFormat(response.toString()));
						
						lettertriger = false;

					} 
					
					else {
						JsonPath jp = new JsonPath(response.toString());
//					String val1 =	jp.get("householdFlag").toString();
						String val1 =	jp.get("householdFlag");
					String val2 =	jp.get("householdGroup");

						ExtentTestManager.getTest().log(LogStatus.PASS,"Results : householdFlag: " + val1 + "       ||      householdGroup: "+ val2);
						map.put(" ", new Object[] {respo, val1, val2, "Success"});
		         		resultup(path,  map);
		         		
		         	lettertriger = true;	
		        		
					}

				} else {
					ExtentTestManager.getTest().log(LogStatus.FAIL,
							"Response Code : " + responseCode + "<br />Repsonse Body :<br /> "
									+ APIHandler.converToPrettyJSONFormat(response.toString()));
					//Report.updateTestLog("API Post Response", "Received Invalid response Code from API", Status.FAILNS);
					System.out.println("response: " +response.toString());
					
					map.put(" ", new Object[] {respo,"" , "", "failure"});
	         		resultup(path,  map);
	         		
	         		lettertriger = true;
	         		
				}

				}

		}catch(Exception e){
			ExtentTestManager.getTest().log(LogStatus.ERROR,
					"Exception has been Received on Retreiving the data :" + e.getMessage());
			//Report.updateTestLog("API Post Response", "Exception has been Received on Retreiving multiple lines:"+ e.getMessage(), Status.FAIL);
			e.printStackTrace();
		}

	}
	
	//this get method : passing parameters are : payload from cell, tracking from cell : method 2
	
	@SuppressWarnings("static-access")
	public String apiPostRequest(String ty,String apici, String apics, String api, String payload, String lk,String trackingid,String auths2 )  {
		try{
			// -------------------------   List of User passed parameters  ----------------------------
			String ePU = api;
			Client_ID = apici;
			Client_Secret = apics;
			
						
			Jsoncnvt objCF = new Jsoncnvt();
			
		//	for(Integer row:intRows){

				String updatedBody = objCF.fupdateListinValues(payload,trackingid);
				
				ExtentTestManager.getTest().log(LogStatus.INFO,"Triggered Payload" + updatedBody);
				
				
				//System.out.println("**********************updatedBody \n  " +updatedBody);
				
			//	String updatedBodywithLineItems=updatedBody;
				
				//String timeforReport =objCF.fgetUniqueTimeStamp();

				//System.out.println(updatedBodywithLineItems);	
				
				
			//	System.out.println("Access token 2:" + auths2);

				// ---------------------------------- Make the Request ----------------------------------- 	
				
				//System.out.println("payload  " +payload);
				URL object = new URL(ePU);
				HttpsURLConnection connection = (HttpsURLConnection) object.openConnection();

				connection.setRequestProperty("Client_ID", Client_ID);
				connection.setRequestProperty("Client_Secret", Client_Secret);
				connection.setRequestProperty("grant_type", "client_credentials");
				//connection.setRequestProperty("Scope", "WRITE");
				connection.setRequestProperty("Authorization", "Bearer " + auths2);
				connection.setRequestProperty("Content-Type", "application/json");
				connection.setRequestMethod("POST");
				connection.setDoOutput(true);
				OutputStreamWriter wr = new OutputStreamWriter(connection.getOutputStream());
				wr.write(updatedBody);
				//wr.write(payload);
				//wr.write(postDataBytes);
				
				//connection.getOutputStream().write(updatedBody);
				
				
				//System.out.println("***********************Positive: " +postDataBytes);
				
			//	Reader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));

		       
		    
             //   String inputLine;
            //    StringBuilder  response = new StringBuilder();

                
            //    for (int c; (c = in.read()) >= 0;)
            //    	response.append((char)c);
           //     String responses = response.toString();
                	
                
           //     in.close();
			//System.out.println("Positive: " +response.toString());
			//System.out.println("Positive: " +responses);
			  //respo = response.toString();  
		        
		        
	        
				
				wr.flush();
				int responseCode = connection.getResponseCode();
				
				System.out.println("responseCode: "+ responseCode);
				
				
				
				

		

			//	System.out.println(response);
				
				
				// ---------------------------------- Verify the Response -----------------------------------  
				if(responseCode==200){
					
					BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
					String inputLine;
					StringBuffer response = new StringBuffer();
					while ((inputLine = in.readLine()) != null) {
						response.append(inputLine);
					}
					in.close();

					if (response.toString().contains("errorText")) {
						ExtentTestManager.getTest().log(LogStatus.ERROR,
								"Response Code : " + responseCode + "<br />Repsonse Body :<br /> "
										+ APIHandler.converToPrettyJSONFormat(response.toString()));
						
						val1 = response.toString();
						
						System.out.println("val1:"+ val1);
						
						map.put(" ", new Object[] {ty,val1,trackingid, "Error"});
		         		resultup(path,  map);
		         		
		         		lettertriger = true;	

					} else {
						
						JsonPath jp = new JsonPath(response.toString());
					jp.get("message").toString().equalsIgnoreCase("LetterGeneration Complete");
					
					// val1 = 	response.toString();`
				////	 val4 = 	jp.get("message").toString();
				//	 val2 = 	jp.get("correspondenceTrackingId").toString();
				//	 val3 = 	jp.get("letterGeneratedDateTime").toString();
					
					System.out.println("postman : 854");
					
					 System.out.println("val1:"+ ty + val1+ val4+ val2 +val3);
					 
					 ExtentTestManager.getTest().log(LogStatus.PASS,  "Response Code : " + responseCode + "<br />Repsonse Body :<br /> " +
								"LetterGeneration Complete for the Letter Key :" +lk ); 
					 
					 System.out.println("postman : 861");
						
						//map.put(" ", new Object[] { ty, " ", val2, "Success"});
						
		         		//resultup(path,  map);
		         		
		         		lettertriger = true;	
					}

				} 
				
				else if(responseCode >= 400) {
					//System.out.println(response);
					
					BufferedReader in = new BufferedReader(	new InputStreamReader(connection.getErrorStream())) ;

		                String inputLine1;
		                StringBuilder  response1 = new StringBuilder();

		                while ((inputLine1 = in.readLine()) != null) {

		                	response1.append(inputLine1);
		                	response1.append(System.lineSeparator());
		                	
		                }
		                
		                in.close();
		                System.out.println("Error response1: " +response1.toString());
		                 
		                 val1 = response1.toString();
		                 
		                // map.put(" ", new Object[] {ty, val1,trackingid, "Error"});
			         		//resultup(path,  map);
			         		
			         		ExtentTestManager.getTest().log(LogStatus.ERROR,
									"Response Code : " + responseCode + "<br />Repsonse Body :<br /> "
											+ APIHandler.converToPrettyJSONFormat(response1.toString()));
		         		
		         		lettertriger = false;	
		                
		               // writeToExcel(System.getProperty("user.dir") +PropertiesFileHandler.readProperty("testdesign"), respo);
		                
					}
				/*
				else {
					
					ExtentTestManager.getTest().log(LogStatus.FAIL,
							"Response Code : " + responseCode + "<br />Repsonse Body :<br /> "
									+ APIHandler.converToPrettyJSONFormat(response.toString()));
					//Report.updateTestLog("API Post Response", "Received Invalid response Code from API", Status.FAILNS);
					System.out.println(response.toString());
				}
			
	*/
			
		}catch(Exception e){
			ExtentTestManager.getTest().log(LogStatus.ERROR,
					"Exception has been Received on Retreiving the data :" + e.getMessage());
			//Report.updateTestLog("API Post Response", "Exception has been Received on Retreiving multiple lines:"+ e.getMessage(), Status.FAIL);
			e.printStackTrace();
		}
		return val1;

	}

@SuppressWarnings("static-access")
public void apiPostRequests(String ty,String ci, String cs, String api, String payload, String lk, String auths2)  {
	try{
		// -------------------------   List of User passed parameters  ----------------------------
		String ePU = api;
		Client_ID = ci;
		Client_Secret = cs;
		
		
		String payloadtemplatepath = System.getProperty("user.dir")
				+ PropertiesFileHandler.readProperty("Payload");
		String TestDataWB = System.getProperty("user.dir") + PropertiesFileHandler.readProperty("testdata");

		Jsoncnvt objCF = new Jsoncnvt();
		// ---------------------------------- Get Data from the Mapping ---------------------------	
					// ----------------------------- Get Data from the respective data files -------------------------		

		String inputPayload = objCF.freadTextFromFile(payloadtemplatepath).replace("*{", "{").replace("}*", "}");
		
		
		System.out.println("inputPayload  " +payload);
		
		Map<Integer, Map<String, String>> inputDataMap = objCF.fGetDatafromExcelasMap(TestDataWB,"PayLoad");
								
		java.util.Set<Integer> intRows= inputDataMap.keySet();
		
		

		for(Integer row:intRows){

			String updatedBody = objCF.fupdateListofValues(inputPayload,inputDataMap.get(row));
			
		//	System.out.println("updatedBody  " +updatedBody);
			
			String updatedBodywithLineItems=updatedBody;
			
			String timeforReport =objCF.fgetUniqueTimeStamp();

			System.out.println(updatedBodywithLineItems);	
			
			
			System.out.println("Access token 2:" + accessToken);

			// ---------------------------------- Make the Request ----------------------------------- 	
			
			//System.out.println("payload  " +payload);
			URL object = new URL(ePU);
			HttpsURLConnection connection = (HttpsURLConnection) object.openConnection();

			connection.setRequestProperty("Client_ID", Client_ID);
			connection.setRequestProperty("Client_Secret", Client_Secret);
			connection.setRequestProperty("grant_type", "client_credentials");
			//connection.setRequestProperty("Scope", "WRITE");
			connection.setRequestProperty("Authorization", "Bearer " + accessToken);
			connection.setRequestProperty("Content-Type", "application/json");
			connection.setRequestMethod("POST");
			connection.setDoOutput(true);
			OutputStreamWriter wr = new OutputStreamWriter(connection.getOutputStream());
			//wr.write(updatedBodywithLineItems);
			wr.write(payload);
			wr.flush();
			int responseCode = connection.getResponseCode();
			
			System.out.println("responseCode: "+ responseCode);
			
			
			
			/*

			BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			System.out.println(response);
			
			*/
			
			

			if (responseCode >= 400) {
				
/*
			BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

*/			//System.out.println(response);
			
			BufferedReader in = new BufferedReader(	new InputStreamReader(connection.getErrorStream())) ;

                String inputLine;
                StringBuilder  response = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {

                	response.append(inputLine);
                	response.append(System.lineSeparator());
                	
                }
                in.close();
                System.out.println("Error response: " +response.toString());
                
                               
                 respo = response.toString();
                 
              //   map.put(" ", new Object[] {ty,respo, "Failure"});
         		//resultup(path,  map);
         		lettertriger = false;	
                
               // writeToExcel(System.getProperty("user.dir") +PropertiesFileHandler.readProperty("testdesign"), respo);
                
			}
			
			else {

				BufferedReader in = new BufferedReader(	new InputStreamReader(connection.getInputStream())) ;

                String inputLine;
                StringBuilder  response = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {

                	response.append(inputLine);
                	response.append(System.lineSeparator());
                	
                }
                in.close();
			System.out.println("Positive: " +response.toString());
			  respo = response.toString();
			  
			 
			
			
			
			// ---------------------------------- Verify the Response -----------------------------------  
			if(responseCode==200){

				if (response.toString().contains("errorText")) {
					ExtentTestManager.getTest().log(LogStatus.ERROR,
							"Response Code : " + responseCode + "<br />Repsonse Body :<br /> "
									+ APIHandler.converToPrettyJSONFormat(response.toString()));
					
					val1 = response.toString();
					
					System.out.println("val1:"+ val1);
					
					////map.put(" ", new Object[] { ty,val1, "Error"});
	         	//	resultup(path,  map);
	         		
	         		lettertriger = false;	

				} else {
					JsonPath jp = new JsonPath(response.toString());
				jp.get("message").toString().equalsIgnoreCase("LetterGeneration Complete");
				 val1 = 	jp.get("message").toString();
				 val2 = 	jp.get("correspondenceTrackingId").toString();
				 val3 = 	jp.get("letterGeneratedDateTime").toString();
				
				 System.out.println("val1:"+ val1+ val2 +val3);
				 
					ExtentTestManager.getTest().log(LogStatus.PASS,
							"LetterGeneration Complete for the Letter Key :" +lk);
					
					///map.put(" ", new Object[] { ty,val1, val2,val3, "Success"});
	         	//	resultup(path,  map);
	         		
	         		lettertriger = true;	
				}

			} else {
				ExtentTestManager.getTest().log(LogStatus.FAIL,
						"Response Code : " + responseCode + "<br />Repsonse Body :<br /> "
								+ APIHandler.converToPrettyJSONFormat(response.toString()));
				//Report.updateTestLog("API Post Response", "Received Invalid response Code from API", Status.FAILNS);
				System.out.println(response.toString());
			}
		}
		
		}
	}catch(Exception e){
		ExtentTestManager.getTest().log(LogStatus.ERROR,
				"Exception has been Received on Retreiving the data :" + e.getMessage());
		//Report.updateTestLog("API Post Response", "Exception has been Received on Retreiving multiple lines:"+ e.getMessage(), Status.FAIL);
		e.printStackTrace();
	}

}
	
	public static void apicdIntoExcel(String path, LinkedHashMap<String, String> map) {

		try {
			InputStream ExcelFileToRead = new FileInputStream(path);
			XSSFWorkbook workBook = new XSSFWorkbook(ExcelFileToRead);
			XSSFSheet sheet = workBook.getSheet("apiresponse");

			int LastRow = sheet.getLastRowNum();

			if (LastRow < 1) {
				System.out.println("creating the header line");

				XSSFRow header = sheet.createRow(0);

				header.createCell(0).setCellValue(" ");

				XSSFRow row1 = sheet.createRow(0);

				row1.createCell(0).setCellValue("");

				int counter = 0;
				for (Entry<String, String> keys : map.entrySet()) {

					counter++;

					header.createCell(counter).setCellValue(keys.getKey().trim());

					row1.createCell(counter).setCellValue(keys.getValue().trim());

					sheet.autoSizeColumn(counter);
				}
			} else {
				
				System.out.println("skipping the header line");

				//XSSFRow row = sheet.getRow(LastRow + 1);
				XSSFRow row = sheet.getRow(LastRow);

				//row.getCell(0).setCellValue(LineItem);

				int counter = 3;
				for (Entry<String, String> keys : map.entrySet()) {

					counter++;

					row.createCell(counter).setCellValue(keys.getValue());

					sheet.autoSizeColumn(counter);
				}
			}

			FileOutputStream fileOut = new FileOutputStream(path);

			System.out.println(path);
			workBook.write(fileOut);
			workBook.close();
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

}


/*//<appending the values after splitting 	
File jsonFile = new File(payload);
FileInputStream fis = null;
FileBody jsondata = new FileBody(jsonFile);


 System.out.println("*********************ptext  " +jsondata);

  Map<String,Object> params = new LinkedHashMap<>();
    params.put("correspondenceTrackingId", trackingid);

    StringBuilder postData = new StringBuilder();
    for (Map.Entry<String,Object> param : params.entrySet()) {
        if (postData.length() != 0) postData.append('&');
        
        postData.append('"');
        postData.append(URLEncoder.encode(param.getKey(), "UTF-8"));
        	            
        postData.append('"');
        
        postData.append('=');
        
        postData.append('"');
        postData.append(URLEncoder.encode(String.valueOf(""+param.getValue()+""), "UTF-8"));
        postData.append('"');
        postData.append(',');
    } 
 
    byte[] postDataBytes = postData.toString().getBytes("UTF-8");
    
    
    
 System.out.println("*********************ptext  " +postData.toString());
// appending the values after splitting  till her> */

