package pages;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;
import com.jayway.jsonpath.spi.json.JacksonJsonNodeJsonProvider;
import com.jayway.jsonpath.spi.mapper.JacksonMappingProvider;


public class Jsoncnvt {

	
	

public String fgetUniqueTimeStamp() {

	Random rand = new Random();
	String executionTime= new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	int value = rand.nextInt(50);
	String timeforReport =executionTime.replace(".", "_") + value;
	return timeforReport;
}



public static String fupdateListofValues(String inputReqTemplate,Map<String,String>valuesFromDataSheet){
	   DocumentContext json = null;
	try{
		
	   java.util.Set<String> StringstoUpdate = null;
	// fix for updating the Integer/Float Values for a repetitive object
	io.restassured.path.json.JsonPath restJsonPath = null;
	try {
		Configuration config = Configuration.builder().jsonProvider(new JacksonJsonNodeJsonProvider())
		   .mappingProvider(new JacksonMappingProvider()).build();   

		   json = JsonPath.using(config).parse(inputReqTemplate);
		   StringstoUpdate = valuesFromDataSheet.keySet();
		   restJsonPath = io.restassured.path.json.JsonPath.from(inputReqTemplate);
	} catch (Exception e3) {
		// TODO Auto-generated catch block
		e3.printStackTrace();
	}
	   
	   for(String keynode:StringstoUpdate){
				    
			try{
			
			if(!keynode.contains("-NA")){
				
				if(restJsonPath.get().getClass().getSimpleName().contains("Integer") || restJsonPath.get().getClass().getSimpleName().contains("Float")
						||restJsonPath.get().getClass().getSimpleName().contains("Double")){
// to be Unit Tested				
					json=json.set(keynode, 	Double.parseDouble(valuesFromDataSheet.get(keynode)));
				}
				else
				
				json=json.set(keynode, valuesFromDataSheet.get(keynode));
				
				
				}
			   }
			   catch(PathNotFoundException e){

				   System.out.println(keynode +" is not available on the InputTemplate to update");

			   }
			   catch(NullPointerException e1){
				   e1.printStackTrace();
			   }
			   catch(Exception e2){
				   e2.printStackTrace();
			   }
			   }	 

			   return json.jsonString();
	}
	catch(Exception e){
		System.out.println("test" + e.getMessage());
	}
	return json.jsonString();
}



public Map<Integer,Map<String,String>> fGetDatafromExcelasMap(String payloadinputWB, String Sheetname) {
			
	String TestDataWB=payloadinputWB;
	Map<Integer,Map<String,String>> TestInputMap=new HashMap<Integer,Map<String,String>>();
	FileInputStream fip;
	XSSFWorkbook ipWB = null;
	try {
		fip = new FileInputStream(TestDataWB);
	
		ipWB = new XSSFWorkbook(fip);
    
    XSSFSheet ipSheet = ipWB.getSheet(Sheetname);
    
    int noRows=ipSheet.getPhysicalNumberOfRows();
    System.out.println("HI");
    for(int i=2;i<noRows;i++){
    	Map<String, String> intMap=new HashMap<String,String>();
           
                 for(int j=0;j<ipSheet.getRow(i).getLastCellNum();j++){
                	  XSSFCell headerrow=ipSheet.getRow(1).getCell(j);
                      XSSFCell values=ipSheet.getRow(i).getCell(j);
                      intMap.put(headerrow.toString().trim(),values.toString());
                      }
                 
                 TestInputMap.put(i-1, intMap);    
    }
    ipWB.close();
    fip.close();
    
	} catch (FileNotFoundException e) {
		
		e.printStackTrace();
	} catch (IOException e) {
	
		e.printStackTrace();
	}
    
	return TestInputMap;
}
public String freadTextFromFile(String payloadtemplatename) {
	String jsonRequest=null;
	try {
		jsonRequest= new String(Files.readAllBytes(Paths.get(payloadtemplatename)));
	
	}catch(FileNotFoundException e){
		System.out.println(e.getMessage());
	}
	catch (IOException e) {
		e.printStackTrace();
	}
	return jsonRequest;
			
		}



}
