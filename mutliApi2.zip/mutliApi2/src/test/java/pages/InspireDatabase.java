package pages;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.LinkedHashMap;

import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import Reports.ExtentTestManager;
import core.BasePage;
import core.BaseTest;
import utilities.DBHandler;
import utilities.ExcelReader;
import utilities.PropertiesFileHandler;

public class InspireDatabase extends BasePage {
	
	//public static String environment = PropertiesFileHandler.readProperty("Env");
	// public static String strJobID ="";
	String path = System.getProperty("user.dir") +PropertiesFileHandler.readProperty("testdata");
	
	public InspireDatabase(WebDriver driver) {
		super(driver);
	}
	ExtentTest test;
	
	@SuppressWarnings({ "null", "null", "null" })
	public String[] execute_Inspire_Query(String trackingnumber)  {
		
		String [] strJobID = new String [2];
		//strJobID = null;
		//String LOB = null;
		try {
			String sqlDRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
			
			String connectionUrl="";
			String query ="";
			//strJobID = "";
			//LOB ="";
			System.out.println("*************\nQuerying the Inspire Database...\n*************");
			
			if (environment.equals("RT"))

			{
				//connectionUrl = PropertiesFileHandler.readProperty("inspire_Url_" + environment)/*+";domain=HEALTHFIRST"*/+ ";integratedSecurity=true";
				connectionUrl = PropertiesFileHandler.readProperty("inspire_Url_" + environment) + ";authenticationScheme=NTLM;integratedSecurity=true;userName=user;password=password";
				
				String dbNAME = PropertiesFileHandler.readProperty("inspire_Database_"+environment);
				
				String insidate = PropertiesFileHandler.readProperty("InsDate");
				
				/*
				 query = "Select * from\n" + 
						" ["+dbNAME+"].[dbo].[Inspire_ScalerJobTracking]  where jobEndTime is not null  \n" + 
						" and correspondenceTrackingId = '"+trackingnumber+"' + "+insidate+" ";	
						*/
				
				 query = "Select * from\n" + 
							" ["+dbNAME+"].[dbo].[Inspire_ScalerJobTracking]  where correspondenceTrackingId = '"+trackingnumber+"'";// "+insidate+" ";	
				
				 System.out.println(query);
				
			}
			else if (environment.equals("ST")) {
			
				connectionUrl = PropertiesFileHandler.readProperty("inspire_Url_" + environment)+ ";userName=user;password=password";
				System.out.println(connectionUrl);
				
				String dbNAME = PropertiesFileHandler.readProperty("inspire_Database_"+environment);
				
				String insidate = PropertiesFileHandler.readProperty("InsDate");
				
				 query = "Select * from\n" + 
							" ["+dbNAME+"].[dbo].[Inspire_ScalerJobTracking]  where correspondenceTrackingId = '"+trackingnumber+"' "; // "+insidate+" ";	
				 
				 System.out.println(query);
			}
            else  {
				
				System.out.println("ERROR :   --->  Application Environment is not configured properly");
			}
			
			
			/* 
			String dbNAME = PropertiesFileHandler.readProperty("inspire_Database_"+environment);
					
			String query = "Select * from\n" + 
					" ["+dbNAME+"].[dbo].[Inspire_ScalerJobTracking]  where jobEndTime is not null  \n" + 
					" and correspondenceTrackingId = '"+trackingnumber+"'";
			*/
			
			String user = PropertiesFileHandler.readProperty("inspire_User_"+environment);
			String password = PropertiesFileHandler.readProperty("inspire_Pswd_"+environment);
			
			DBHandler handle = new DBHandler();
			ResultSet Result = handle.runTheQuery(sqlDRIVER,connectionUrl,query,user,password);

			
			ResultSetMetaData rsmd = Result.getMetaData();
			int columnsNumber = rsmd.getColumnCount();
			
			int LineItem =0 ;
			while (Result.next()) {
				
				LineItem++;
				LinkedHashMap<String,String> map = new LinkedHashMap<String,String>();

				for (int i = 1; i <= columnsNumber; i++) {
			       
			        String columnValue = Result.getString(i);
			        System.out.print("\n" + rsmd.getColumnName(i)+ " S: " +columnValue );
			        
			        map.put(rsmd.getColumnName(i).trim(), columnValue.trim());
			        
			        if (rsmd.getColumnName(i).equals("scalerJobId")) {
			        	
			        	strJobID[0] = columnValue.trim(); 
			        	System.out.println(strJobID[0]);
			        }
			        
			        if (rsmd.getColumnName(i).equals("templateName")) {
			        	
			        	strJobID[1] = columnValue.trim();
			        }
			        
			        if(rsmd.getColumnName(i).equals("jobStatus")){
			        	
			        if(columnValue.equals("Triggering Systems Notified")) {
			        	
			        	System.out.println("JobStatus of : '" +trackingnumber+"' is Triggering Systems Notified" );
			        	ExtentTestManager.getTest().log(LogStatus.PASS, "Inspire-DB  [JobStatus of : '" +trackingnumber+"' for Row : '"+Result.getRow()+"' is Triggering Systems Notified  ] ");
			        	 
			        }else {
			        	
			        	System.out.println("JobStatus of : '" +trackingnumber+"' is : "+columnValue );
			        	ExtentTestManager.getTest().log(LogStatus.FAIL, "Inspire-DB  JobStatus of : '" +trackingnumber+"' for Row : '"+Result.getRow()+"' is : "+columnValue +"  ]");
			        	 
			        }
			        }

			    }
			    System.out.println("");
			    
			    ExcelReader.storeIntoExcel(path, "Inspire_DB_Data",LineItem+"",map);
			}
			

			if(strJobID[0].isEmpty()) {
				
				ExtentTestManager.getTest().log(LogStatus.FAIL,
						"Inspire Database has no records for the Tracking ID : " + trackingnumber);
				
				System.out.println("Inspire Database has no records for the Tracking ID : " + trackingnumber);
			}
			
			
			
		} catch (Exception e) {
			
			ExtentTestManager.getTest().log(LogStatus.FAIL, "Error with Inspire DB : " + e.toString());
			System.out.println("Error with Inspire DB" + e.toString());
			e.printStackTrace();
		}
		
		
		return strJobID ;
		
	}
		
}