package testRunner;

import core.BaseTest;

import org.testng.TestListenerAdapter;
import org.testng.TestNG;
import org.testng.annotations.Listeners;
import org.testng.collections.Lists;

import java.util.List;

import static core.BaseTest.projectPath;

@Listeners(Reports.ExtentReporter.class)
public class TestRunner {

    public static void main(String[] args) {
        String environment = "ST";
        String executionType = "Positive";
        if( args.length == 2){
            environment = parseEnvironment(args[0], args[1]);
            BaseTest.appEnv = environment;
            BaseTest.appExe = executionType;
        }
        else if( args.length == 4){
        	environment = parseEnvironment(args[0], args[1]);
            BaseTest.appEnv = environment;
            executionType = parseExecutionType(args[2], args[3]);
            BaseTest.appExe = executionType;
        }
        else
        {
        	 BaseTest.appEnv = environment;
        	 BaseTest.appExe = executionType;
        }
        TestListenerAdapter tla = new TestListenerAdapter();
        TestNG testng = new TestNG();
        List<String> suites = Lists.newArrayList();
        
        /* if(BaseTest.appExe.equalsIgnoreCase("Smoke"))
        {
        	if( BaseTest.appEnv.equalsIgnoreCase("QA"))
        	{
        		suites.add(projectPath + "/Smoke_PROD.xml"); // Switch testng.xml file based on the environment
        	}
        	else if( BaseTest.appEnv.equalsIgnoreCase("RT")|| BaseTest.appEnv.equalsIgnoreCase("ST"))
        	{
        		suites.add(projectPath + "/Smoke_ST_RT.xml"); // Switch testng.xml file based on the environment
        	}
        	
        	
        }
        else
        {
        	suites.add(projectPath + "/" + environment + ".xml");
        }*/
        suites.add(projectPath + "/" + "testng.xml");
       // suites.add(projectPath + "/" + environment + ".xml");
       // testng.setTestClasses(new Class[] { Dwnstream.class });
        testng.setTestSuites(suites);
        testng.addListener(tla);
        testng.run();
    }

    private static String parseEnvironment(String command, String value) {
        if(command == null || command.isEmpty()){
            return "";
        }
        else if(!command.toLowerCase().contains("environment")){ //Contains so that it can test positive for --environment also
            return "";
        }
        else {
            return value;
        }
    }
    //Parse Execution Type - Regression/smoke
    private static String parseExecutionType(String command, String value) {
        if(command == null || command.isEmpty()){
            return "";
        }
        else if(!command.contains("executionType")){
            return "";
        }
        else {
            return value;
        }
    }
}