package core;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import Reports.ExtentReporter;
import Reports.ExtentTestManager;
import utilities.PropertiesFileHandler;


public class BasePage {

	protected static WebDriver driver;
	protected  WebDriverWait wait;
	protected static int defaultWaitTime = 60;
	protected final String LEFT = "left";
	protected final String RIGHT = "right";
	protected final String UP = "up";
	protected final String DOWN = "down";
	private static SecretKeySpec secretKey;
	private static byte[] key;
	public static String environment = PropertiesFileHandler.readProperty("Env");


	@SuppressWarnings("static-access")
	public BasePage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 20);
	}
	
	public void click(By element) throws InterruptedException {
		wait.until(ExpectedConditions.elementToBeClickable(element));
		driver.findElement(element).click();
	}
	
	public  void clicks(By element) throws InterruptedException {
		wait.until(ExpectedConditions.elementToBeClickable(element));
		driver.findElement(element).click();
	}
	
	public void clickAndVerifyElement(By element,String message) throws InterruptedException {
		wait.until(ExpectedConditions.elementToBeClickable(element));
		driver.findElement(element).click();
		Thread.sleep(5000);
		verifyElementPresence(element,  message);
	}

  
	public static  void fnSwitchFrame(By element) throws InterruptedException            
	{		
		
		List<WebElement> iframes = driver.findElements(By.tagName("iframe"));
		// print your number of frames
		System.out.println("Number of Iframes: : : : "+iframes.size());
		Thread.sleep(3000);
		
		for (WebElement iframe : iframes) {
			// switch to every frame
			System.out.println("Ifame:"+iframe);
			System.out.println(iframe.getAttribute("title"));
			driver.switchTo().frame(iframe);
			
			try{
				if(driver.findElement(element).isDisplayed());	
				{				
					System.out.println("frame has been switched to expected");
					break;
				}
				
			}catch(Exception e){
				driver.switchTo().defaultContent();
				System.out.println("FRAME not found");
			}
		}
		Thread.sleep(3000);
	}
	public void clickIfVisible(By element) throws InterruptedException {
		wait.until(ExpectedConditions.presenceOfElementLocated(element));
		if(driver.findElement(element).isEnabled()==true)
			wait.until(ExpectedConditions.elementToBeClickable(element));
		driver.findElement(element).click();
		Thread.sleep(10);
	}

	public void clickByJS(By element) {
		
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.findElement(element));
	}
	
	public void clickAction(By element) {
		
		Actions builder = new Actions(driver);
		builder.moveToElement(driver.findElement(element)).build().perform();
		
	}

	public String getText(By element) throws InterruptedException {
		wait.until(ExpectedConditions.presenceOfElementLocated(element));
		return driver.findElement(element).getText();
	}
	
	
	public  boolean isElementEnableds(By element) throws InterruptedException {
		wait.until(ExpectedConditions.presenceOfElementLocated(element));
		if(driver.findElement(element).isEnabled()==true)
		{
			//ExtentTestManager.getTest().log(LogStatus.PASS, "The object is enabled");
		}
		else
		{
			System.out.println("The object is disabled");
			//ExtentTestManager.getTest().log(LogStatus.FAIL, "The object is disabled");
		}
		return true;
	}


	public boolean isElementEnabled(By element) throws InterruptedException {
		wait.until(ExpectedConditions.presenceOfElementLocated(element));
		if(driver.findElement(element).isEnabled()==true)
		{
			//ExtentTestManager.getTest().log(LogStatus.PASS, "The object is enabled");
		}
		else
		{
			System.out.println("The object is disabled");
			//ExtentTestManager.getTest().log(LogStatus.FAIL, "The object is disabled");
		}
		return true;
	}

	public void assertText(By element, String text) throws InterruptedException {
		wait.until(ExpectedConditions.presenceOfElementLocated(element));
		Assert.assertEquals(driver.findElement(element).getText(), text);
		if(driver.findElement(element).getText().equalsIgnoreCase(text))
		{
			//ExtentTestManager.getTest().log(LogStatus.PASS, "The text is verified - "+text);
		}
		else
		{
			ExtentTestManager.getTest().log(LogStatus.FAIL, "The text is not verified - "+text);
		}
	}

	public void takeScreenshot() throws InterruptedException, IOException {
		File file = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(file, new File("Screenshot.jpg"));
	}

	public void setText(By element, String text) {
		wait.until(ExpectedConditions.presenceOfElementLocated(element));
		driver.findElement(element).sendKeys(text);
	}
	
	public   void setTextq(By spsearch1, String id) {
		
		//String quer = " \"(index=\"mulesoft_ec_inspire\" correspondenceTrackingId=\ + id +\")\";
				String quer = "index=\"mulesoft_ec_inspire\" correspondenceTrackingId=\""+id+"\"";
		
		System.out.println(quer);
		
		
		wait.until(ExpectedConditions.presenceOfElementLocated(spsearch1));
		driver.findElement(spsearch1).sendKeys(quer);
		
			
	}
	
	public  void clearTexts(By element) {
		wait.until(ExpectedConditions.presenceOfElementLocated(element));
		driver.findElement(element).clear();
	}

	public void clearText(By element) {
		wait.until(ExpectedConditions.presenceOfElementLocated(element));
		driver.findElement(element).clear();
	}
	
	public void clearTextb(By element) {
		wait.until(ExpectedConditions.presenceOfElementLocated(element));
		WebElement clr = driver.findElement(element);
		clr.sendKeys(Keys.chord(Keys.CONTROL,"a",Keys.DELETE));
		
		//clr.sendKeys(Keys.CONTROL,"a");
		//clr.sendKeys(Keys.DELETE);
		
		
	}

	public static void waitForElements(By element) {

		WebDriverWait wait = new WebDriverWait(driver, 40);
		wait.until(ExpectedConditions.visibilityOfElementLocated(element));
	}

	public void waitForElement(By element) {

		WebDriverWait wait = new WebDriverWait(driver, 40);
		wait.until(ExpectedConditions.visibilityOfElementLocated(element));
	}

	public void verifyLabel(By element, String strProperty, String strVerifytext)
	{
		if(strProperty.equalsIgnoreCase("text"))
		{
			System.out.println(driver.findElement(element).getText());
			if(driver.findElement(element).getText().equalsIgnoreCase(strVerifytext))
			{
				ExtentTestManager.getTest().log(LogStatus.PASS, strVerifytext+" is displayed");
			}
			else
			{
				ExtentTestManager.getTest().log(LogStatus.FAIL, strVerifytext+" is not displayed");
			}
		}else if(strProperty.equalsIgnoreCase("value"))
		{
			System.out.println(driver.findElement(element).getAttribute("value"));
			if(driver.findElement(element).getAttribute("value").equalsIgnoreCase(strVerifytext))
			{
				ExtentTestManager.getTest().log(LogStatus.PASS, strVerifytext+" is displayed");
			}
			else
			{
				ExtentTestManager.getTest().log(LogStatus.FAIL, strVerifytext+" is not displayed");
			}
		}
		else
		{
			ExtentTestManager.getTest().log(LogStatus.FAIL, "No such property exists - "+strProperty);
		}
	}

	public boolean isElementDisabled(By element) throws InterruptedException {
		wait.until(ExpectedConditions.presenceOfElementLocated(element));
		if(driver.findElement(element).isEnabled()==true)
		{
			ExtentTestManager.getTest().log(LogStatus.FAIL, "The object should not be enabled");
		}
		else
		{
			ExtentTestManager.getTest().log(LogStatus.PASS, "The object is disabled");
		}
		return true;
	}

	public boolean verifyPasswordMask(By element,String strText) throws InterruptedException {
		waitForElement(element);
		driver.findElement(element).sendKeys("Test");
		if(driver.findElement(element).getText().contains("����"))
		{
			ExtentTestManager.getTest().log(LogStatus.PASS, "The Password is masked in "+strText+" Text box");
		}
		else
		{
			ExtentTestManager.getTest().log(LogStatus.FAIL, "The Password is not masked in "+strText+" Text box");
		}
		return true;
	}
	//verify presence of elements
	public boolean verifyElementPresence(By element, String strMessage) throws InterruptedException {
		if(driver.findElements(element).size()>0)
		{
			ExtentTestManager.getTest().log(LogStatus.PASS, strMessage+" is present");
			return true;
		}
		else
		{
			ExtentTestManager.getTest().log(LogStatus.FAIL, strMessage+" is not present");
			// captureSnapshot();
			return false;
		}
	}
	//verify absence of elements
	public boolean verifyElementAbsence(By element, String strMessage) throws InterruptedException {
		if(driver.findElements(element).size()>0)
		{
			ExtentTestManager.getTest().log(LogStatus.FAIL, strMessage+" should not be present");       
			return false;
		}
		else
		{
			ExtentTestManager.getTest().log(LogStatus.PASS, strMessage+" is not present"); 
			return true;
		}
	}

	/*verification of Elemnt's Presence with specific message*/

	public boolean verifyElementEnabled(By element, String objNAME) throws InterruptedException {

		wait.until(ExpectedConditions.presenceOfElementLocated(element));
		if(driver.findElement(element).isEnabled()==true)
		{
			ExtentTestManager.getTest().log(LogStatus.PASS, "The object : '"+objNAME+"' is enabled");
		}
		else
		{
			ExtentTestManager.getTest().log(LogStatus.FAIL, "The object : '"+objNAME+"' is disabled");
		}
		return true;
	}


	/* public void captureSnapshot() {
    	WebDriver webDriver_fail = new DriverFactory().getInstance().getDriver();
    	String base64Screenshot = "data:image/png;base64," + ((TakesScreenshot)webDriver_fail ).
				getScreenshotAs(OutputType.BASE64);
		ExtentTestManager.getTest().log(LogStatus.INFO,
				ExtentTestManager.getTest().addBase64ScreenShot(base64Screenshot));    	
    }*/

	/*verification of Element's Absence with specific message*/

	public boolean verifyElementDisabled(By element, String strMessage) throws InterruptedException {
		wait.until(ExpectedConditions.presenceOfElementLocated(element));
		if(driver.findElement(element).isEnabled()==false)
		{
			ExtentTestManager.getTest().log(LogStatus.PASS, strMessage+" is disabled");
		}
		else
		{
			ExtentTestManager.getTest().log(LogStatus.FAIL, strMessage +" is enabled");
		}
		return true;
	}
	
	public void switchToWindow( int windowNumber) {
		Set<String> s = driver.getWindowHandles();
		Iterator<String> ite = s.iterator();
		int i = 0;
		while (ite.hasNext() && i < 10) {
			String popupHandle = ite.next().toString();
			driver.switchTo().window(popupHandle);
			if (i == windowNumber)
				break;
			i++;
		}
	}
	
	public static void writeInEmailBody(String content) {

		String writeFileName = ExtentReporter.ReportFolder + "\\Summary.txt";
		
		try {
			FileWriter fileWriter = new FileWriter(writeFileName, true);
			BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

			bufferedWriter.append(content);
			bufferedWriter.append(System.lineSeparator());
			bufferedWriter.close();

		} catch (IOException ex) {
			System.out.println("Error writing to file '" + writeFileName + "'");
		}

	}
	
	public static String takeScreenshot(String SubFolderName, String screenshotName)  {

		String encodedBase64 = null;;
		try {
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

			String folderPATH = ExtentReporter.ReportFolder+"\\screenshots\\" + SubFolderName + "\\"
					+ screenshotName + ".png";
			
			FileUtils.copyFile(scrFile, new File(folderPATH));

			System.out.println(folderPATH);

			
			try {

				@SuppressWarnings("resource")
				FileInputStream fileInputStream = new FileInputStream(folderPATH);
				byte[] bytes = new byte[(int) new File(folderPATH).length()];
				fileInputStream.read(bytes);
				encodedBase64 = new String(Base64.encodeBase64(bytes));

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		} catch (WebDriverException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "data:image/png;base64," + encodedBase64;
	}
	
	 /*public static void setKey(String myKey)
	    {
	        MessageDigest sha = null;
	        try {
	            key = myKey.getBytes("UTF-8");
	            sha = MessageDigest.getInstance("SHA-1");
	            key = sha.digest(key);
	            key = Arrays.copyOf(key, 16);
	            secretKey = new SecretKeySpec(key, "AES");
	        }
	        catch (NoSuchAlgorithmException e) {
	            e.printStackTrace();
	        }
	        catch (UnsupportedEncodingException e) {
	            e.printStackTrace();
	        }
	    }
	    
	  
	 public static String decryptText(String strToDecrypt)
	    {
	        try
	        {
	            setKey("healthfirst");
	            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
	            cipher.init(Cipher.DECRYPT_MODE, secretKey);
	            return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
	        }
	        catch (Exception e)
	        {
	            System.out.println("Error while decrypting: " + e.toString());
	        }
	        return null;
	    }*/

}