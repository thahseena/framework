package core;


import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;

import com.relevantcodes.extentreports.ExtentTest;

public class BaseTest {

	public static ExtentTest test;
	public static String CSVDataSheet = "";
	public static String appEnv = "";
	public static Logger logger = Logger.getLogger(BaseTest.class); //Initialized logger object
	public static String testingEnv = "";
	 public static String appExe = "";
	 public final static String projectPath = System.getProperty("user.dir");
	 
    /*protected static WebDriverWait wait;
    private String testCaseName;
    private long testStartTime;
    private long testFinishTime;
    private long testDurationTime;
    private String testFailedMsg;
   
    public static String testUsername = "";
    public static String testPassword = "";
    public static String clientId = "";
    public static String clientSecret = "";
    protected static String accessKey = "";
    protected static String UDID = "";
   
    public static String bundleID = "";
    protected static String appName = "";
    
    
    public static String loginUsername = "";
    public static String loginPassword = "";
    public static String platformVersion = "";
    public static String platformName = "";
    public static String getInstance = "";
    public static String deviceInfo = "";
  
   
    public static String appVersion = "";
    public static String MDM_ClientID = "";
    public static String MDM_ClientSecret = "";
   
    public static Boolean isAppLaunched;*/

/*    protected long getTestStartTime() {
        return testStartTime;
    }
    protected void setTestStartTime(long testStartTime) {
        this.testStartTime = testStartTime;
    }
    protected long getTestFinishTime() {
        return testFinishTime;
    }
    protected void setTestFinishTime(long testFinishTime) {
        this.testFinishTime = testFinishTime;
    }
    protected long getTestDurationTime() {
        return testDurationTime;
    }
    protected void setTestDurationTime(long testDurationTime) {
        this.testDurationTime = testDurationTime;
    }
    protected String getTestCaseName() {
        return testCaseName;
    }
    protected void setTestCaseName(String testCaseName) {
        this.testCaseName = testCaseName;
    }
    public String getTestFailedMsg() {
        return testFailedMsg;
    }
    public void setTestFailedMsg(String testFailedMsg) {
        this.testFailedMsg = testFailedMsg;
    }*/
	 
    //Setting the Environment and access key details
    @Parameters({"environment"})
    public static void setEnv(String environment){
    	try {
    		
    		if(BaseTest.appEnv.equals("")) {
    			
				BaseTest.appEnv = "RT";
			}
    		
    	} catch (Exception exp) {
    		System.out.println(exp.getMessage());
    		logger.error(exp.getMessage());
    		exp.getCause();
    		exp.printStackTrace();
    	}
    }
    
    
}  
   
    
 