package tests.Validation;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import Api.Jsoncnvt;
import Api.Postman;
import Reports.ApExcelReader;
import Reports.ExtentTestManager;
import core.BasePage;
import core.BaseTest;
import core.DriverFactory;

import pages.CIDDatabase;
import pages.InspireDatabase;

import pages.InspireScaler;
import pages.PegaApplication;
import pages.SearchFile;
//import pages.splunk;
import utilities.ExcelReader;
import utilities.PropertiesFileHandler;

@Listeners(Reports.ExtentReporter.class)
public class Tryout extends BaseTest {
	
	String path = System.getProperty("user.dir") +PropertiesFileHandler.readProperty("testdata");
	private int finalr;
	private String strtrackingID;
	
	private static final String LineItem = null;
	WebDriver webDriver ;
	String strjsonModel = null;
	
		//public static String environment = "RT";
	static LinkedHashMap<String,Object[]> map = new LinkedHashMap<String,Object[]>();
	private static final Object API = null;
	public static String environment = PropertiesFileHandler.readProperty("Env");
	public static String userstory = PropertiesFileHandler.readProperty("id");
	public static ArrayList<ArrayList<Object>> list ;
	public static String ltype = PropertiesFileHandler.readProperty("type");
	 public static XSSFWorkbook workbook;
	 public static XSSFSheet worksheet;
	 public static DataFormatter formatter= new DataFormatter();
	 //public static String file_location = System.getProperty("user.dir")+"/Akeneo_product";
	// static String SheetName= "Sheet1";
	 public  String Res;
	private int DataSet;
	


	@BeforeClass(alwaysRun = true)
	//@Parameters({ "environment" })

	public void prepareTest(/*String environment*/) throws Exception {
		
		setEnv(environment);
		test = ExtentTestManager.startTest("User story " + userstory, userstory );
		System.out.println(" **************** Tryout***********************************");	
	}

	@Test(dataProvider="ReadVariant",threadPoolSize = 20, invocationCount = 1)
	
	//@Test(threadPoolSize = 2, invocationCount = 2)
	public void createPDF( String Type,
			String	Test_case_Name,
			String LetterKey,
			String clientid,
			String	clientsecret,
			String	auth,
			String	tclientid,
			String	tclientsecret,
			String	trackingid,
			String	aaclientid,
			String	aaclientsecret,
			String	aauth,
			String	aclientid,
			String	aclientsecret,
			String	API,
			String	Payload,
			String	tracking_id,
			String	cquery,
			String	lquery,
			String	dtrackng,
			String	snumb ) throws Exception {
		
		
		
		
		
		//ArrayList<ArrayList<Object>> list = ApExcelReader.extractAsList(BaseTest.projectPath + PropertiesFileHandler.readProperty("testdata"), "Automation");
		
 		
		//int iter = 0;
		
		//for(ArrayList<Object> singleRow : list){
		/*	
			String ty =  (String )singleRow.get(0);
			String tc =  (String )singleRow.get(1);
			String lk =  (String )singleRow.get(2);
			String aci = (String )singleRow.get(3);
			String acs =  (String )singleRow.get(4);
			String auth = (String )singleRow.get(5);
			String tci = (String )singleRow.get(6);
			String tcs = (String )singleRow.get(7);
			String tid = (String )singleRow.get(8);
			String aaci = (String )singleRow.get(9);
			String aacs = (String )singleRow.get(10);
			String aauth = (String )singleRow.get(11);
			String apici	= (String )singleRow.get(12);
			String apics =  (String )singleRow.get(13);
			String api =  (String )singleRow.get(14);
			String payload =  (String )singleRow.get(15);
			String trackingidp =  (String )singleRow.get(16);
			String cquery =  (String )singleRow.get(17);
			String pquery =  (String )singleRow.get(18);
			String dtrackng =  (String )singleRow.get(19);
			String snumb = (String )singleRow.get(20);  */
			
		
		DataSet++;
		
		
			String ty =  Type;
			String tc = 	Test_case_Name;
			String lk =  LetterKey;
			String aci =  clientid;
			String acs = clientsecret;
			String auth1 = 	auth;
			String tci =  	tclientid;
			String tcs = 	tclientsecret;
			String tid = 	trackingid;
			String aaci = (String)	aaclientid;
			String aacs = (String)	aaclientsecret;
			String aauth1 = (String)	aauth;
			String apici	= (String)	aclientid;
			String apics = (String)	aclientsecret;
			String api = (String)	API;
			String payload = (String)	Payload;
			String trackingidp = (String)	tracking_id;
			String cquery1 = (String)	cquery;
			String pquery = (String)	lquery;
			String dtrackng1 = (String)	dtrackng;
			String snumb1 = (String)	snumb;

			System.out.println("TY : " + ty);
		    
		
		
	}
	
	
	
    @DataProvider

    public Object[][] Authentication() throws Exception{
//    public ArrayList<ArrayList<Object>> Authentication() throws Exception{

         //Object[][] testObjArray = ExcelUtils.getTableArray("D://ToolsQA//OnlineStore//src//testData//TestData.xlsx","Sheet1");
    	Object[][] testObjArray = ApExcelReader.getTableArray(BaseTest.projectPath + PropertiesFileHandler.readProperty("testdata"), "Automation");
         //ArrayList<ArrayList<Object>> list = ApExcelReader.extractAsList(BaseTest.projectPath + PropertiesFileHandler.readProperty("testdata"), "Automation");

         return (testObjArray);
         //return (list);

		}
    
    
    
    @DataProvider (name = "ReadVariant" ,parallel=true)
    public static Object[][] ReadVariant() throws IOException
    {
    FileInputStream fileInputStream= new FileInputStream(BaseTest.projectPath + PropertiesFileHandler.readProperty("testdata")); //Excel sheet file location get mentioned here
    workbook = new XSSFWorkbook (fileInputStream); //get my workbook 
    worksheet=workbook.getSheet("Automation");// get my sheet from workbook
          XSSFRow Row=worksheet.getRow(0);   //get my Row which start from 0   
      
       	int RowNum = worksheet.getPhysicalNumberOfRows();// count my number of Rows
       	int ColNum= Row.getLastCellNum(); // get last ColNum 
       	
       	Object Data[][]= new Object[RowNum-1][ColNum]; // pass my  count data in array
       	
       	 for(int i=0; i<RowNum-1; i++) //Loop work for Rows
        {  
        XSSFRow row= worksheet.getRow(i+1);
        
        for (int j=0; j<ColNum; j++) //Loop work for colNum
        {
        if(row==null)
        Data[i][j]= "";
        else 
        {
        XSSFCell cell= row.getCell(j);
        if(cell==null)
        Data[i][j]= ""; //if it get Null value it pass no data 
        else
        {
        String value=formatter.formatCellValue(cell);
        Data[i][j]=value; //This formatter get my all values as string i.e integer, float all type data value
        }
        }
        }
        }
    
       	return Data;
       }
   
	

	@AfterMethod(alwaysRun = true)
	public void tearDown() {
		
		if (testingEnv.equalsIgnoreCase(BaseTest.appEnv)) {
			logger.info("Test Completed" + DriverFactory.getInstance().getDriver());
		} else if (testingEnv.equalsIgnoreCase("local")) {
			logger.info("***Launching App in Local Environment***");
		}
	}


}
