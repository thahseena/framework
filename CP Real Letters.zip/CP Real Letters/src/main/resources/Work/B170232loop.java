package tests.Validation;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Reports.ExtentTestManager;
import core.BaseTest;
import core.DriverFactory;
import pages.CIDDatabase;
import pages.InspireDatabase;
import sprintneOfive.APIDB;
import sprintneOfive.ApExcelReader;
import sprintneOfive.CIDDatabase_api;
import sprintneOfive.InspireDatabase_api;
import sprintneOfive.Jsoncnvt;
import sprintneOfive.Postman;
import utilities.PropertiesFileHandler;

@Listeners(Reports.ExtentReporter.class)
public class B170232loop extends BaseTest {
	
	String path = System.getProperty("user.dir") +PropertiesFileHandler.readProperty("testdesign");
	private String updatedBodywithLineItems;
	private FileInputStream fip1;
	private XSSFWorkbook ipWB1;
	private int finalr;
	private String lk;
	private String ci;
	private String cs;
	private String auth;
	private String api;
	private String payload;
	private String cquery;
	private String iquery;
	private String tid;
	private String strtrackingID;
	static LinkedHashMap<String,Object[]> map = new LinkedHashMap<String,Object[]>();
	private static final Object API = null;
	public static String environment = PropertiesFileHandler.readProperty("Env");
	public static String userstory = PropertiesFileHandler.readProperty("id");
	public static ArrayList<ArrayList<Object>> list ;
	


	@BeforeClass(alwaysRun = true)
	//@Parameters({ "environment" })

	void prepareTest(/*String environment*/) throws Exception {
		
		setEnv(environment);
		test = ExtentTestManager.startTest("API - PDF Letter Generation", "Creates Tracking IDs and generates respective PDF letters");
		System.out.println("***********************************1");	
	}

	@Test(groups = { "Regression"})
	public void createPDF() throws EncryptedDocumentException, InvalidFormatException, IOException {
		
		
	    		    	
		
			
		ArrayList<ArrayList<Object>> list = ApExcelReader.extractAsList(BaseTest.projectPath + PropertiesFileHandler.readProperty("testdesign"), "LetterKey");
		
		//   "correspondenceTrackingId" : "correspondenceTrackingId",
 		
		int iter = 0;
		
		for(ArrayList<Object> singleRow : list){
			
			
			 lk =  (String )singleRow.get(1);
			 ci =  (String )singleRow.get(2);
			 cs =  (String )singleRow.get(3);
			 auth =  (String )singleRow.get(4);
			 tid =  (String )singleRow.get(5);
			 api =  (String )singleRow.get(6);
			 
			 fip1 = new FileInputStream(path);
				
			 ipWB1 = new XSSFWorkbook(fip1);
	    
			 XSSFSheet ipSheet1 = ipWB1.getSheet("LetterKey"); 
	    
	    int noRows1=ipSheet1.getPhysicalNumberOfRows();
	   // int noRows1=ipSheet1.getLastRowNum();
	    System.out.println("noRows : "+ noRows1);	
	        
	    
	    int i;
	    	    
	    for( i=2;i<noRows1;){
	    	
	    	 finalr = i ;
	    	
	    	System.out.println("rowiter:" + finalr);
			
		    
		 	  
		 		    
		   // ExtentTestManager.startTest( "CID look up API call for : " +lk, lk);	
		
					Postman gen = new Postman();
					gen.token(ci, cs, auth);
					gen.trackingid(ci, cs, tid, finalr);   		
	         		gen.token(ci, cs, auth);
	    			//gen.apiPostRequest(ci, cs, api,finalr);
	    			//gen.copyInputExcelToSharePATH();
	    			
	    			
	    			
	    			if (Postman.lettertriger == true) {
	    				
	    				strtrackingID = Postman.val2;
	    				
	    				System.out.println("strtrackingID:" + strtrackingID);
	    				
	    				CIDDatabase_api cidDB = new CIDDatabase_api();
	    				InspireDatabase_api inspireDB = new InspireDatabase_api();
	    				inspireDB.execute_Inspire_Query(strtrackingID);	
	    				cidDB.execute_CID_Query("StatusLog", strtrackingID);
	    				cidDB.execute_CID_Query("OutboundData", strtrackingID);
	    				
	    				
	    				
	    			}
	    			  iter++;
	    			
	    			
	    			 
	         		}  
	    i++;
	    
	  
		
		}
		
	   
	}
		
	
	

	@AfterMethod(alwaysRun = true)
	public void tearDown() {
		
		if (testingEnv.equalsIgnoreCase(BaseTest.appEnv)) {
			logger.info("Test Completed" + DriverFactory.getInstance().getDriver());
		} else if (testingEnv.equalsIgnoreCase("local")) {
			logger.info("***Launching App in Local Environment***");
		}
	}


}
