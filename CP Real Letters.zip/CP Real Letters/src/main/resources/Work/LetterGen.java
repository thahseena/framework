package tests.Validation;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Reports.ExtentTestManager;
import core.BaseTest;
import core.DriverFactory;
import sprintneOfive.Postman;

@Listeners(Reports.ExtentReporter.class)
public class LetterGen extends BaseTest {
	
	public static String environment = "RT";

	@BeforeClass(alwaysRun = true)
	//@Parameters({ "environment" })

	void prepareTest(/*String environment*/) throws Exception {
		setEnv(environment);
		test = ExtentTestManager.startTest("PDF Letter Generation", "Creates Tracking IDs and generates respective PDF letters");
		
	}

	@Test(groups = { "Regression"})
	public void createPDF() {
		
		Postman gen = new Postman();
		//gen.getTrackingID();
		//gen.apiPostRequest();
		gen.copyInputExcelToSharePATH();
		
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() {
		
		if (testingEnv.equalsIgnoreCase(BaseTest.appEnv)) {
			logger.info("Test Completed" + DriverFactory.getInstance().getDriver());
		} else if (testingEnv.equalsIgnoreCase("local")) {
			logger.info("***Launching App in Local Environment***");
		}
	}


}
