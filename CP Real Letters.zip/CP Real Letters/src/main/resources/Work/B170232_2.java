package tests.Validation;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Reports.ExtentTestManager;
import core.BaseTest;
import core.DriverFactory;
import sprintneOfive.ApExcelReader;
import sprintneOfive.Jsoncnvt;
import sprintneOfive.Postman;
import utilities.PropertiesFileHandler;

@Listeners(Reports.ExtentReporter.class)
public class B170232_2 extends BaseTest {
	
	String path = System.getProperty("user.dir") +PropertiesFileHandler.readProperty("testdesign");
	private String updatedBodywithLineItems;
	private FileInputStream fip1;
	private XSSFWorkbook ipWB1;
	private int finalr;
	static LinkedHashMap<String,Object[]> map = new LinkedHashMap<String,Object[]>();
	private static final Object API = null;
	public static String environment = PropertiesFileHandler.readProperty("Env");
	public static String userstory = PropertiesFileHandler.readProperty("id");
	public static ArrayList<ArrayList<Object>> list ;


	@BeforeClass(alwaysRun = true)
	//@Parameters({ "environment" })

	void prepareTest(/*String environment*/) throws Exception {
		
		setEnv(environment);
		test = ExtentTestManager.startTest("API - PDF Letter Generation", "Creates Tracking IDs and generates respective PDF letters");
		System.out.println("***********************************1");	
	}

	@Test(groups = { "Regression"})
	public void createPDF() throws EncryptedDocumentException, InvalidFormatException, IOException {
		
			
		ArrayList<ArrayList<Object>> list = ApExcelReader.extractAsList(BaseTest.projectPath + PropertiesFileHandler.readProperty("testdesign"), "LetterKey");
		
		//   "correspondenceTrackingId" : "correspondenceTrackingId",
 		
		int iter = 0;
		
		for(ArrayList<Object> singleRow : list){
			
			
			String lk =  (String )singleRow.get(1);
			String ci =  (String )singleRow.get(2);
			String cs =  (String )singleRow.get(3);
			String auth =  (String )singleRow.get(4);
			String tid =  (String )singleRow.get(5);
			String api =  (String )singleRow.get(6);
			String payload	= (String )singleRow.get(7);
			String cquery =  (String )singleRow.get(8);
			String iquery =  (String )singleRow.get(9);
			
			
		    
		  iter++;
		  
		  System.out.println("*************************************values fetched from sheet********************");
		  
		    System.out.println(lk);    // Get me the value of first column
		    System.out.println(ci);
		    System.out.println(cs);
		    System.out.println(auth);
		    System.out.println(tid);
		    System.out.println(api);
		   // System.out.println(payload);
		  //  System.out.println(cquery);
		   // System.out.println(iquery);

		    System.out.println("*************************************values fetched from sheet********************");
		    
		   // ExtentTestManager.startTest( "CID look up API call for : " +lk, lk);	
		    
		
		    fip1 = new FileInputStream(path);
			
			 ipWB1 = new XSSFWorkbook(fip1);
	    
			 XSSFSheet ipSheet1 = ipWB1.getSheet("LetterKey"); 
	    
	    int noRows1=ipSheet1.getPhysicalNumberOfRows();
	    //int noRows=ipSheet.getLastRowNum();
	    
	    
	    System.out.println("noRows : "+ noRows1);	
	    
	    
	    System.out.println(" ---------------------------------- Get Data from the Mapping ---------------------------");
	    
	    for(int i=2;i<noRows1;i++){
	    	
	    	 finalr = i ;
	    	
	    	System.out.println("rowiter:" + finalr);
	    	
	    	
	    }
		    
		    
		    
		    
		
		Postman gen = new Postman();
		gen.token(ci, cs, auth);
		gen.trackingid(ci, cs, tid, finalr);
		
		
			System.out.println("json work*******************************");
		
		String payloadtemplatepath = System.getProperty("user.dir")
				+ PropertiesFileHandler.readProperty("Payload");
		String TestDataWB = System.getProperty("user.dir") + PropertiesFileHandler.readProperty("testdesign");
		
		System.out.println("payloadtemplatepath : "+ payloadtemplatepath);
		System.out.println("TestDataWB : "+ TestDataWB);
		
		
		
		Map<Integer,Map<String,String>> TestInputMap=new HashMap<Integer,Map<String,String>>();
		FileInputStream fip;
		XSSFWorkbook ipWB = null;
		
			try {
			 fip = new FileInputStream(TestDataWB);
		
			 ipWB = new XSSFWorkbook(fip);
	    
			 XSSFSheet ipSheet = ipWB.getSheet("payload"); 
	    
	    int noRows=ipSheet.getPhysicalNumberOfRows();
	    //int noRows=ipSheet.getLastRowNum();
	    
	    
	    System.out.println("noRows : "+ noRows);	
	    
	    
	    System.out.println(" ---------------------------------- Get Data from the Mapping ---------------------------");
	    
	    for(int i=2;i<noRows;i++){
	    	
	    	System.out.println("noRows : "+ noRows);
	    	
	    	Map<String, String> intMap=new HashMap<String,String>();
	    	
	    	System.out.println("noRows : "+ noRows);
	           
	                 for(int j=0;j<ipSheet.getRow(i).getLastCellNum();j++){
	                	  XSSFCell headerrow=ipSheet.getRow(1).getCell(j);
	                      XSSFCell values=ipSheet.getRow(i).getCell(j);
	                      //System.out.println("values : "+ values);
	                      
	                      intMap.put(headerrow.toString().trim(),values.toString());
	                      
	                      //System.out.println("intMap : "+ intMap);
	                      }
	                 
	                 TestInputMap.put(i-1, intMap); 
	                 
	                 Map<Integer, Map<String, String>> inputDataMap = TestInputMap;
	                 
	                 java.util.Set<Integer> intRows= inputDataMap.keySet();
	                 
	                 System.out.println("noRowsl : "+ noRows);
	                	
	                 System.out.println(" ----------------------------- Get Data from the respective data files -------------------------");	
	                 
	                 Jsoncnvt objCF = new Jsoncnvt();
	                 
	                 String inputPayload = objCF.freadTextFromFile(payloadtemplatepath).replace("*{", "{").replace("}*", "}");
	     			
	     			System.out.println("inputPayload  " +inputPayload);
	         		
	         			         		
	         		for(Integer row:intRows){

	         			String updatedBody = Jsoncnvt.fupdateListofValues(inputPayload,inputDataMap.get(row));
	         			
	         			System.out.println("updatedBody  " +updatedBody);
	         			
	         			 updatedBodywithLineItems=updatedBody;
	         			
	         			String timeforReport =objCF.fgetUniqueTimeStamp();

	         			System.out.println("updatedBodywithLineItems:" +updatedBodywithLineItems);  
	         		
	         		gen.token(ci, cs, auth);
	    			
	    			//gen.apiPostRequest(ci, cs, api,updatedBodywithLineItems);
	    		
	    			//gen.copyInputExcelToSharePATH();
	                 
	         		}          
	    }
	    ipWB.close();
	    fip.close();
	    
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
	
	}
		}
	}
	

	@AfterMethod(alwaysRun = true)
	public void tearDown() {
		
		if (testingEnv.equalsIgnoreCase(BaseTest.appEnv)) {
			logger.info("Test Completed" + DriverFactory.getInstance().getDriver());
		} else if (testingEnv.equalsIgnoreCase("local")) {
			logger.info("***Launching App in Local Environment***");
		}
	}


}
