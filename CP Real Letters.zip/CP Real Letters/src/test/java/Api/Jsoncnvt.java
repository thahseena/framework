package Api;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;
import com.jayway.jsonpath.spi.json.JacksonJsonNodeJsonProvider;
import com.jayway.jsonpath.spi.mapper.JacksonMappingProvider;


public class Jsoncnvt {

	

private static String strtrck;
private static DocumentContext parsed;
private static BufferedWriter writer;
private static BufferedReader reader;
private static String oldcontent;
private static BufferedWriter mwriter;
private static String mpayload;


/**
 * This Method retrieves the attributes list from the Config Sheet
 * @param WBname = Config.xlsx
 * @param Sheetname = Attributes
 * @param Rowname = ScenarioMappingname
 * @return a List Object
 * @author skedarnath
 */

public List<String> fGetAttributesForService(String WBname,String Sheetname,String Rowname) {
		
	List<String> nameAttributes = new ArrayList<String>();
	try{
		
		FileInputStream fip = new FileInputStream(WBname);
		XSSFWorkbook ipWB = new XSSFWorkbook(fip);
		XSSFSheet ipSheet = ipWB.getSheet(Sheetname);
		
		int noRows=ipSheet.getPhysicalNumberOfRows();
		
		for(int i=1;i<noRows;i++){
			
			XSSFCell testCase=ipSheet.getRow(i).getCell(0);
			XSSFCell testenv=ipSheet.getRow(i).getCell(1);
			
			if(testCase.toString().equals(Rowname) ){
				for(int j=1;j<ipSheet.getRow(i).getLastCellNum();j++){
					nameAttributes.add(ipSheet.getRow(i).getCell(j).toString());
				}
				break;
			}
			
		}
		ipWB.close();
		fip.close();
		
		}
		catch(FileNotFoundException e){
			System.out.println("File is not available");
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return nameAttributes;
	}

	
//----------------- To convert the claim number to hit the service with the required param      
	public static String getEndPointParamKeyId(String SearchID,String oObjectName) {

	            String searchbyID =SearchID;
	            String Modifiedclm =null;
	            
	            if(oObjectName.toLowerCase().contains("claim1")){
	          	  oObjectName="ClaimsDetails";
	            }
	            switch(oObjectName){
	            
	            case "ClaimsDetails":
	                   if( searchbyID.length()==13){
	                   
	                   String init=searchbyID.substring(0,2);
	                   String datemonth=searchbyID.substring(2,6);
	                   String clmyear =searchbyID.substring(6,8);
	                   String restofclaim1= searchbyID.substring(8,11);
	                   String restofClaim2= searchbyID.substring(11,13);
	                   
	                   Modifiedclm=init+"~"+"2"+clmyear+datemonth+"~"+restofclaim1+"~"+restofClaim2;
	                     }
	                   break;
	            case "AuthDetailspage":
	                   if( searchbyID.length()==14){
	                         //01216040400105
	                         String init=searchbyID.substring(0,2);
	                         String strDate =searchbyID.substring(2,8);
	                         
	                         String restofclaim1= searchbyID.substring(8,11);
	                         String restofClaim2= searchbyID.substring(11,13);
	                         
	                         Modifiedclm=init+"~"+strDate+"~"+restofclaim1+"~"+restofClaim2;

	                         }
			              
	            break;
	            
	            default:
	          	  Modifiedclm=searchbyID;
	          	  break;
	            }

	          	  return Modifiedclm;
	     }
	

/**
 * This method will generate a unique timestamp for the file being generated
 * @return current timestamp as string
 * @category General
 */
public String fgetUniqueTimeStamp() {

	Random rand = new Random();
	String executionTime= new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	int value = rand.nextInt(50);
	String timeforReport =executionTime.replace(".", "_") + value;
	return timeforReport;
}


/**
 * This Method will create the multiple lines request based on the Repetitive Object passed
 * @category General 
 */	
public static String fupdateListofValueswithItemID(String updatedBody, String RepetitiveObj,
		String itemIDs, Map<Integer, Map<String, String>> inputLineDataMap) {
		String[] noOfLinetemsRequired=itemIDs.split("-");
		System.out.println("Hi");
		int Lbound =0;
		int Ubound =0;
		JSONObject obj = null;
		try {
			if(noOfLinetemsRequired.length==2){
				Lbound = Integer.parseInt(noOfLinetemsRequired[0]);
				Ubound = Integer.parseInt(noOfLinetemsRequired[1]);
			}
			else{
				System.out.println("Data not in proper format for repetitive object is not present");
				Lbound=Integer.parseInt(itemIDs);
				Ubound=Integer.parseInt(itemIDs);
			
			}
				
		String RepeatingReq="";
		
			obj = new JSONObject(updatedBody);
			Object objMultipleLines = obj.get(RepetitiveObj);
			obj.remove(RepetitiveObj);
			System.out.println(objMultipleLines.getClass().getSimpleName());
			
			String value = objMultipleLines.toString().substring(1,objMultipleLines.toString().length()-1);

			for (int i=Lbound;i<=Ubound;i++){
				RepeatingReq=RepeatingReq+fupdateListofValues(value,inputLineDataMap.get(i));
		}	
		obj.put(RepetitiveObj,"["+RepeatingReq+"]");
				
		} catch (JSONException e) {
			System.out.println("JSON parsing exception "+e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
				System.out.println("Unhandled Exception - "+e.getMessage());
			e.printStackTrace();
		}
		
		return obj.toString().replace("\\", "").replace("\"[", "[").replace("]\"", "]").replace("}{", "},{");
	}

/**
 * This Method take the input request and updates it with the data from the test data sheet against
 * each Json path provided
 * @category Api
 * @param inputReqTemplate
 * @return data as String
 * @author skedarnath
 */
public static String fupdateListofValuess(String inputReqTemplate,String trackingid){
	   DocumentContext json = null;
	try{
		String temp = ("\"correspondenceTrackingId\" : \"<correspondenceTrackingId>\"");
	   String StringstoUpdate = null;
	// fix for updating the Integer/Float Values for a repetitive object
	io.restassured.path.json.JsonPath restJsonPath = null;
	try {
		Configuration config = Configuration.builder().jsonProvider(new JacksonJsonNodeJsonProvider())
		   .mappingProvider(new JacksonMappingProvider()).build();   

		   json = JsonPath.using(config).parse(inputReqTemplate);
		  StringstoUpdate = "correspondenceTrackingId";
		   
		   //"correspondenceTrackingId" : "<correspondenceTrackingId>",
		  
		   restJsonPath = io.restassured.path.json.JsonPath.from(inputReqTemplate);
		   
		   
		   
	} catch (Exception e3) {
		// TODO Auto-generated catch block
		e3.printStackTrace();
	}
	   
	 //  for(String keynode:StringstoUpdate){
				    
			try{	
					System.out.println("**********************************"+StringstoUpdate + "     / " + trackingid);
				
				json=json.set(StringstoUpdate, restJsonPath);
				
				//json=json.set(keynode, valuesFromDataSheet.get(keynode));
				
				
				
				}
			   catch(PathNotFoundException e){

				   System.out.println(StringstoUpdate +" is not available on the InputTemplate to update");

			   }
			   catch(NullPointerException e1){
				   e1.printStackTrace();
			   }
			   catch(Exception e2){
				   e2.printStackTrace();
			   }
			
			System.out.println("*****************json278"+json.jsonString());
			   	 

			   return json.jsonString();
	}
	catch(Exception e){
		System.out.println("test" + e.getMessage());
	}
	
	System.out.println("******************************************************json287"+json.jsonString());
	return json.jsonString();
}

public static String fupdateListinValues(String payload,String trackingid){
	
	//trackingid = snumb  for gen trakcing id
	   DocumentContext json = null;
	   
	try{
	
	try {
			   
		System.out.println("value from excel " + trackingid);
		
		
		File file = new File("src/main/resources/JSON/txt.txt");
				File mfile = new File("src/main/resources/JSON/mtxt.txt");
		
		
		writer = new BufferedWriter(new FileWriter(file));
		
		writer.write(payload);
		writer.close();	
		
		String  oldstring = "correspondenceTrackingIds";
		
		   
		oldcontent = "" ;
		
		reader = new BufferedReader(new FileReader(file));
		
		String line = reader.readLine();
		
		while (line !=null)
			
		{
			
			oldcontent = oldcontent + line + System.lineSeparator();
			line = reader.readLine();		
					
		}
		
		String newcontent = oldcontent.replaceAll(oldstring, trackingid);
		
		mwriter = new BufferedWriter(new FileWriter(mfile));
		mwriter.write(newcontent);
		
		
		
		reader.close();
		mwriter.close();
		   
		
		//into string
			
		
		InputStream is = new FileInputStream(mfile); 
		
		BufferedReader buf = new BufferedReader(new InputStreamReader(is)); 
		
		String sline = buf.readLine();
		StringBuilder sb = new StringBuilder(); 
		
		while(sline != null){ 
			sb.append(sline).append("\n");
		sline = buf.readLine();
		} 
		
		 mpayload = sb.toString(); 
		System.out.println("converted to string");
		
		//System.out.println("converted to string" + mpayload);
		
		   
		   
	} catch (Exception e3) {
		// TODO Auto-generated catch block
		e3.printStackTrace();
	}
	   
	
			
			//System.out.println("*****************json278"+json.jsonString());
			   	 

			  // return json.jsonString();
	
	System.out.println("converted to string" + mpayload);
			   
			   return  mpayload ;
			   
			   
			   
	}
	catch(Exception e){
		System.out.println("test" + e.getMessage());
	}
	
	System.out.println("******************************************************\n json287\n"  +mpayload);
	return mpayload;
}



public static String fupdateListofValues(String inputReqTemplate,Map<String,String>valuesFromDataSheet){
	   DocumentContext json = null;
	try{
		
	   java.util.Set<String> StringstoUpdate = null;
	// fix for updating the Integer/Float Values for a repetitive object
	io.restassured.path.json.JsonPath restJsonPath = null;
	try {
		Configuration config = Configuration.builder().jsonProvider(new JacksonJsonNodeJsonProvider())
		   .mappingProvider(new JacksonMappingProvider()).build();   

		   json = JsonPath.using(config).parse(inputReqTemplate);
		   StringstoUpdate = valuesFromDataSheet.keySet();
		   restJsonPath = io.restassured.path.json.JsonPath.from(inputReqTemplate);
	} catch (Exception e3) {
		// TODO Auto-generated catch block
		e3.printStackTrace();
	}
	   
	   for(String keynode:StringstoUpdate){
				    
			try{
			
			if(!keynode.contains("-NA")){
				
				if(restJsonPath.get().getClass().getSimpleName().contains("Integer") || restJsonPath.get().getClass().getSimpleName().contains("Float")
						||restJsonPath.get().getClass().getSimpleName().contains("Double")){
//to be Unit Tested				
					json=json.set(keynode, 	Double.parseDouble(valuesFromDataSheet.get(keynode)));
				}
				else
				
				json=json.set(keynode, valuesFromDataSheet.get(keynode));
				
				
				}
			   }
			   catch(PathNotFoundException e){

				   System.out.println(keynode +" is not available on the InputTemplate to update");

			   }
			   catch(NullPointerException e1){
				   e1.printStackTrace();
			   }
			   catch(Exception e2){
				   e2.printStackTrace();
			   }
			   }	 

			   return json.jsonString();
	}
	catch(Exception e){
		System.out.println("test" + e.getMessage());
	}
	return json.jsonString();
}


/**
 * This Method retrieves the Column mapping for Comparison
 * @param configWB = if (req Type = get) 
 * 						\JSON_DBMapping\ScenarioMappingname.xlsx
 * 					else
 * 						test datasheet from the Config.xlsx against the Scenario
 * 			
 * @param Sheetname
 * @return
 */
public Map<String, String> fgetColumnMapping(String configWB, String Sheetname) {

	Map<String,String> ExcelDataMap=new HashMap<String, String>();
	
	try{
	FileInputStream fip = new FileInputStream(configWB);
	@SuppressWarnings("resource")
	XSSFWorkbook ipWB = new XSSFWorkbook(fip);
	XSSFSheet ipSheet = ipWB.getSheet(Sheetname);
	
	int noRows=ipSheet.getPhysicalNumberOfRows();
	
	for(int i=1;i<noRows;i++){
		
		XSSFCell apiColumn=ipSheet.getRow(i).getCell(0);
		XSSFCell DBColumn=ipSheet.getRow(i).getCell(1);
		
		ExcelDataMap.put(apiColumn.toString(), DBColumn.toString());
			
		}
	ipWB.close();
	fip.close();
			
	}
	catch(FileNotFoundException e){
		System.out.println("File is not available");
	}
	catch (IOException e) {

		e.printStackTrace();
	}
	
	return ExcelDataMap;
}

		
/**
 * This Method returns the entire data from the excel sheet as map of maps
 * @param payloadinputWB
 * @param Sheetname  the sheetname from which the data needs to be fetched
 * @throws FileNotFoundException , IOException
 * @return Excelsheet Data as Map of Map's
 * @category General
 */
public Map<Integer,Map<String,String>> fGetDatafromExcelasMap(String payloadinputWB, String Sheetname) {
	
	String TestDataWB=payloadinputWB;
	Map<Integer,Map<String,String>> TestInputMap=new HashMap<Integer,Map<String,String>>();
	FileInputStream fip;
	XSSFWorkbook ipWB = null;
	try {
		fip = new FileInputStream(TestDataWB);
	
		ipWB = new XSSFWorkbook(fip);
    
    XSSFSheet ipSheet = ipWB.getSheet(Sheetname);
    
    int noRows=ipSheet.getPhysicalNumberOfRows();
    System.out.println("HI");
    for(int i=1;i<noRows;i++){
    	Map<String, String> intMap=new HashMap<String,String>();
           
                 for(int j=0;j<ipSheet.getRow(i).getLastCellNum();j++){
                	  XSSFCell headerrow=ipSheet.getRow(1).getCell(j);
                      XSSFCell values=ipSheet.getRow(i).getCell(j);
                      intMap.put(headerrow.toString().trim(),values.toString());
                      }
                 
                 TestInputMap.put(i-1, intMap);    
    }
    ipWB.close();
    fip.close();
    
	} catch (FileNotFoundException e) {
		
		e.printStackTrace();
	} catch (IOException e) {
	
		e.printStackTrace();
	}
    
	return TestInputMap;
}

public Map<Integer,Map<String,String>> fGetDatafromExcelasMaps(String payloadinputWB, String Sheetname, int finalr) {
	
	String TestDataWB=payloadinputWB;
	Map<Integer,Map<String,String>> TestInputMap=new HashMap<Integer,Map<String,String>>();
	FileInputStream fip;
	XSSFWorkbook ipWB = null;
	try {
		fip = new FileInputStream(TestDataWB);
	
		ipWB = new XSSFWorkbook(fip);
    
    XSSFSheet ipSheet = ipWB.getSheet(Sheetname);
    
    int noRows=ipSheet.getPhysicalNumberOfRows();
    System.out.println("HI");
   // for(int i=2;i<noRows;i++){
    
    int i = finalr;
    	Map<String, String> intMap=new HashMap<String,String>();
           
                 for(int j=0;j<ipSheet.getRow(i).getLastCellNum();j++){
                	 
                	  XSSFCell headerrow=ipSheet.getRow(1).getCell(j);
                      XSSFCell values=ipSheet.getRow(i).getCell(j);
                      intMap.put(headerrow.toString().trim(),values.toString());
                      
                      }
                 
                 TestInputMap.put(i-1, intMap);    
   // }
    ipWB.close();
    fip.close();
    
	} catch (FileNotFoundException e) {
		
		e.printStackTrace();
	} catch (IOException e) {
	
		e.printStackTrace();
	}
    
	return TestInputMap;
}


public String freadTextFromFile(String payloadtemplatename) {
	String jsonRequest=null;
	try {
		jsonRequest= new String(Files.readAllBytes(Paths.get(payloadtemplatename)));
	
	}catch(FileNotFoundException e){
		System.out.println(e.getMessage());
	}
	catch (IOException e) {
		e.printStackTrace();
	}
	System.out.println("jsonRequest :"+ jsonRequest);
	return jsonRequest;
	
	
			
		}



}
