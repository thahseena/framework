package pages;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.net.ssl.HttpsURLConnection;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.relevantcodes.extentreports.LogStatus;

import Reports.ExtentTestManager;
import io.restassured.path.json.JsonPath;
import utilities.APIHandler;
import utilities.ExcelReader;
import utilities.PropertiesFileHandler;

public class Postman {

	private static String accessToken;
	HashMap<String, String> headerParams = new HashMap<String, String>();
	private String Client_Secret;
	private String Client_ID;
	public static List<String> trackingID = new ArrayList<String>();
	public static String environment = PropertiesFileHandler.readProperty("Env");
	String path = System.getProperty("user.dir") +PropertiesFileHandler.readProperty("testdata");
	static LinkedHashMap<String,Object[]> map = new LinkedHashMap<String,Object[]>();
	// public static Response response;
	 StringBuilder  response ;
	 String respo;

	public void getTrackingID() {

		try {
			/** Token */

			URL object = new URL(PropertiesFileHandler.readProperty("tokenURL_"+environment));
			
			Client_ID = PropertiesFileHandler.readProperty("client_id_"+environment);
			Client_Secret = PropertiesFileHandler.readProperty("client_secret_"+environment);
			
			System.out.println(Client_ID);
			System.out.println(Client_Secret);
			
			
			HttpsURLConnection connection = (HttpsURLConnection) object.openConnection();
			
			connection.setRequestProperty("Client_ID", Client_ID);
			connection.setRequestProperty("Client_Secret", Client_Secret);
			connection.setRequestProperty("grant_type", "client_credentials");
			connection.setRequestProperty("Scope", "READ");
			connection.setRequestProperty("Content-Type", "application/json");

			int responseCode = connection.getResponseCode();

			BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			if (responseCode == 200) {

				JsonPath jp = new JsonPath(response.toString());
				accessToken = jp.get("access_token");

				ExtentTestManager.getTest().log(LogStatus.PASS,
						"Response Code : " + responseCode + "<br />Access Token : " + accessToken);

			} else {

				ExtentTestManager.getTest().log(LogStatus.FAIL, "Response Code : " + responseCode
						+ "<br />Repsonse Body :<br /> " + APIHandler.converToPrettyJSONFormat(response.toString()));
			}
			/** Get Corrid */

			apiPutRequest();

			getTrackingIDNumber();

		} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.getTest().log(LogStatus.ERROR, "Error with GetCorrid API : " + e.toString());
		}

	}
	
	public void token() {

		try {
			/** Token */
			System.out.println(environment);
			
			String urls = (PropertiesFileHandler.readProperty("tokenURL_"+environment));
			System.out.println(urls);

			URL object = new URL(PropertiesFileHandler.readProperty("tokenURL_"+environment));
			Client_ID = PropertiesFileHandler.readProperty("client_id_"+environment);
			Client_Secret = PropertiesFileHandler.readProperty("client_secret_"+environment);
			
			
			
			HttpsURLConnection connection = (HttpsURLConnection) object.openConnection();
			connection.setRequestProperty("Client_ID", Client_ID);
			connection.setRequestProperty("Client_Secret", Client_Secret);
			connection.setRequestProperty("grant_type", "client_credentials");
			connection.setRequestProperty("Scope", "READ");
			
			
			int responseCode = connection.getResponseCode();

			BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			if (responseCode == 200) {

				JsonPath jp = new JsonPath(response.toString());
				accessToken = jp.get("access_token");

				ExtentTestManager.getTest().log(LogStatus.PASS,
						"Response Code : " + responseCode + "<br />Access Token : " + accessToken);

			} else {

				ExtentTestManager.getTest().log(LogStatus.FAIL, "Response Code : " + responseCode
						+ "<br />Repsonse Body :<br /> " + APIHandler.converToPrettyJSONFormat(response.toString()));
			}
			
			System.out.println("*************************** access token created **********************");
			
		
		} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.getTest().log(LogStatus.ERROR, "Error with GetCorrid API : " + e.toString());
		}

	}

	@SuppressWarnings("static-access")
	public void apiPutRequest() {
		
		System.out.println("***************************\n tracking id generation process \n**********************");

		try {
			// ------------------------- List of User passed parameters
			// ----------------------------

			String endPointURL = PropertiesFileHandler.readProperty("GetCorrId_"+environment);
			Client_ID = PropertiesFileHandler.readProperty("client_id_"+environment);
			Client_Secret = PropertiesFileHandler.readProperty("client_secret_"+environment);

			String payloadtemplatepath = System.getProperty("user.dir")
					+ PropertiesFileHandler.readProperty("GetCorrID_Paylaod");
			String TestDataWB = System.getProperty("user.dir") + PropertiesFileHandler.readProperty("trackid");

			Jsoncnvt objCF = new Jsoncnvt();

			// ------------------------ Update Data from the data files as required
			// ---------------------------
			String inputPayload = objCF.freadTextFromFile(payloadtemplatepath).replace("*{", "{").replace("}*", "}");

			Map<Integer, Map<String, String>> inputDataMap = objCF.fGetDatafromExcelasMap(TestDataWB, "PayLoad");

			java.util.Set<Integer> intRows = inputDataMap.keySet();

			// run for each row on excel
			for (int row : intRows) {

				String updatedBody = objCF.fupdateListofValues(inputPayload, inputDataMap.get(row));
				String updatedBodywithLineItems = updatedBody;

				

				// ---------------------------------- Make the Request
				// -----------------------------------
				System.out.println(updatedBodywithLineItems);

				URL object = new URL(endPointURL);
				HttpsURLConnection connection = (HttpsURLConnection) object.openConnection();

				connection.setRequestProperty("Client_ID", Client_ID);
				connection.setRequestProperty("Client_Secret", Client_Secret);
				connection.setRequestProperty("grant_type", "client_credentials");
				connection.setRequestProperty("Scope", "WRITE");
				connection.setRequestProperty("Authorization", "Bearer " + accessToken);
				connection.setRequestProperty("Content-Type", "application/json");
				connection.setRequestMethod("PUT");
				connection.setDoOutput(true);
				OutputStreamWriter wr = new OutputStreamWriter(connection.getOutputStream());
				wr.write(updatedBodywithLineItems);
				wr.flush();
				int responseCode = connection.getResponseCode();

				BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
				String inputLine;
				StringBuffer response = new StringBuffer();
				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();

				System.out.println(response);
				// ---------------------------------- Verify the Response
				// -----------------------------------
				if (responseCode == 200) {

					if (response.toString().contains("errorText")) {
						ExtentTestManager.getTest().log(LogStatus.ERROR,
								"Response Code : " + responseCode + "<br />Repsonse Body :<br /> "
										+ APIHandler.converToPrettyJSONFormat(response.toString()));

					} else {
						JsonPath jp = new JsonPath(response.toString());
						String[] strArrLen = (jp.get("message").toString()).split(":");

						String id = strArrLen[strArrLen.length - 1];
						trackingID.add(id);

						ExtentTestManager.getTest().log(LogStatus.PASS,
								"Response Code : " + responseCode + "<br />Tracking ID : " + id);

					}

				} else {
					ExtentTestManager.getTest().log(LogStatus.FAIL,
							"Response Code : " + responseCode + "<br />Repsonse Body :<br /> "
									+ APIHandler.converToPrettyJSONFormat(response.toString()));

					System.out.println(response);
				}

			}

		} catch (Exception e) {
			ExtentTestManager.getTest().log(LogStatus.ERROR,
					"Exception has been Received on Retreiving the data :" + e.getMessage());
			e.printStackTrace();
		}

	}

	public void getTrackingIDNumber() throws Exception {

		if (!trackingID.isEmpty()) {

			ExtentTestManager.getTest().log(LogStatus.INFO,
					"Tracking IDs are generated <br /> " + trackingID.toString());

			System.out.println(trackingID);
			System.out.println("***************************\n tracking id generation done \n**********************");

			writeTrackingIDToExcel(System.getProperty("user.dir") +PropertiesFileHandler.readProperty("API_var"));

		} else {

			ExtentTestManager.getTest().log(LogStatus.FAIL,
					"No Tracking IDs are generated <br /> " + trackingID.toString());

			System.out.println(trackingID);
		}

	}

	public void copyInputExcelToSharePATH() {

		try {
			String InputSheet = System.getProperty("user.dir") + PropertiesFileHandler.readProperty("API_var");
			File srcDir = new File(InputSheet);

			//File destDir = new File(System.getProperty("user.dir") + "/src/main/resources/Excel/S_letter_TestData.xlsx");
			File destDir = new File(PropertiesFileHandler.readProperty("dataSheet_Shared"));

			FileUtils.copyFile(srcDir, destDir);
			ExtentTestManager.getTest().log(LogStatus.INFO,
					"Input sheet is copied to the share path for Content Validation");
			System.out.println("Input sheet is copied to the share path for Content Validation : " + destDir.getName());
			
			Thread.sleep(10000);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void writeTrackingIDToExcel(String data) throws Exception {

		try {

			InputStream ExcelFileToRead = new FileInputStream(data);
			XSSFWorkbook workBook = new XSSFWorkbook(ExcelFileToRead);
			XSSFSheet sheet = workBook.getSheetAt(0);

			int reqColNumber = ExcelReader.getColumnNumber(sheet.getRow(0), "correspondenceTrackingId");

			int rowNumber = 2;
			for (String id : trackingID) {

				sheet.getRow(rowNumber).getCell(reqColNumber).setCellValue(id);
				rowNumber++;
			}

			FileOutputStream fileOut = new FileOutputStream(data);

			System.out.println("Excel Input sheet is updated with Tracking IDs : " + data);
			ExtentTestManager.getTest().log(LogStatus.INFO, "Input sheet is updated with Tracking IDs : " + data);

			workBook.write(fileOut);
			workBook.close();
			fileOut.flush();

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}
	
	public void writeToExcel(String data, String respo) throws Exception {

		try {
			System.out.println("response :" + respo);
			InputStream ExcelFileToRead = new FileInputStream(data);
			XSSFWorkbook workBook = new XSSFWorkbook(ExcelFileToRead);
			XSSFSheet sheet = workBook.getSheetAt(1);

			int reqColNumber = ExcelReader.getColumnNumber(sheet.getRow(0), "ActualResults");

			int rowNumber = 2;
			
			for ( rowNumber = 2; rowNumber < sheet.getPhysicalNumberOfRows(); ) {
			    final Row row = sheet.getRow(rowNumber);
			    
			    sheet.getRow(rowNumber).getCell(reqColNumber).setCellValue(respo);
			
			
			    	rowNumber++;
			    
			    }
			   
			
			
			
					FileOutputStream fileOut = new FileOutputStream(data);

			System.out.println("Excel Input sheet is updated with response : " + data);
			ExtentTestManager.getTest().log(LogStatus.INFO, "Input sheet is updated with response: " + data);

			workBook.write(fileOut);
			workBook.close();
			fileOut.flush();

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}

public static void resultup(String data,  LinkedHashMap<String, Object[]> map) {
		
		try {
			InputStream ExcelFileToRead = new FileInputStream(data);
			XSSFWorkbook workBook = new XSSFWorkbook(ExcelFileToRead);
			XSSFSheet sheet = workBook.getSheet("apiresponse");
			

			int LastRow = sheet.getLastRowNum();

			if (LastRow < 1) {
				
				System.out.println("no header");
				XSSFRow header = sheet.createRow(LastRow);
				XSSFRow row1 = sheet.createRow(LastRow+1);
				int counter = 0;
				for (Entry<String, Object[]> keys : map.entrySet()) {
					
					String Key = keys.getKey();
					Object [] obj1 = keys.getValue();
					
			
								
					
					for (Object obj : obj1) {
					
			            Cell cell = row1.createCell(counter++);
			           		           
			            if(obj instanceof Date) 
			                cell.setCellValue((Date)obj);
			            else if(obj instanceof Boolean)
			                cell.setCellValue((Boolean)obj);
			            else if(obj instanceof String)
			                cell.setCellValue((String)obj);
			            else if(obj instanceof Double)
			                cell.setCellValue((Double)obj); 

					sheet.autoSizeColumn(counter);
				}
			} }
			else {
				
				System.out.println("with  header");

				XSSFRow row1 = sheet.createRow(LastRow +1 );
				int counter = 0;
					for (Entry<String, Object[]> keys : map.entrySet()) {
					
					String Key = keys.getKey();
					Object [] obj1 = keys.getValue();
					for (Object obj : obj1) {
					
			            Cell cell = row1.createCell(counter++);
			           		           
			            if(obj instanceof Date) 
			                cell.setCellValue((Date)obj);
			            else if(obj instanceof Boolean)
			                cell.setCellValue((Boolean)obj);
			            else if(obj instanceof String)
			                cell.setCellValue((String)obj);
			            else if(obj instanceof Double)
			                cell.setCellValue((Double)obj); 

					sheet.autoSizeColumn(counter);
				}
			}
			}
			FileOutputStream fileOut = new FileOutputStream(data);

			System.out.println("values written" + data);
			//test.log(LogStatus.PASS, "Inspire DB record exported successfully");
			workBook.write(fileOut);
			workBook.close();
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

		

	}	

	@SuppressWarnings("static-access")
	public void apiGETRequest(String apiurl)  {
		
		try{
			// -------------------------   List of User passed parameters  ----------------------------
			String endPointURL = apiurl;
			Client_ID = PropertiesFileHandler.readProperty("client_id");
			Client_Secret = PropertiesFileHandler.readProperty("client_secret");

						// ---------------------------------- Make the Request ----------------------------------- 	
				URL object = new URL(endPointURL);
				HttpsURLConnection connection = (HttpsURLConnection) object.openConnection();

				connection.setRequestProperty("Client_ID", Client_ID);
				connection.setRequestProperty("Client_Secret", Client_Secret);
				//connection.setRequestProperty("grant_type", "client_credentials");
				//connection.setRequestProperty("Scope", "WRITE");
				connection.setRequestProperty("Authorization", "Bearer " + accessToken);
				//connection.setRequestProperty("Content-Type", "application/json");
				connection.setRequestMethod("GET");
				connection.setDoOutput(true);
				
				
				String responsemessage = connection.getResponseMessage();
				
				System.out.println("responsemsg: "+ responsemessage);
				
				int responseCode = connection.getResponseCode();
				
				System.out.println("responseCode: "+ responseCode);
				
				if (responseCode == 401) {
					
					
				
/*
				BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
				String inputLine;
				StringBuffer response = new StringBuffer();
				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();

	*/			//System.out.println(response);
				
				BufferedReader in = new BufferedReader(	new InputStreamReader(connection.getErrorStream())) ;

	                String inputLine;
	                StringBuilder  response = new StringBuilder();

	                while ((inputLine = in.readLine()) != null) {

	                	response.append(inputLine);
	                	response.append(System.lineSeparator());
	                	
	                }
	                in.close();
	                System.out.println("Error response: " +response.toString());
	                
	                
	                
	                 respo = response.toString();
	                 
	                 map.put(" ", new Object[] {respo, "Failure"});
	         		resultup(path,  map);
	                
	               // writeToExcel(System.getProperty("user.dir") +PropertiesFileHandler.readProperty("testdesign"), respo);
	                
				}
				
				else {

					BufferedReader in = new BufferedReader(	new InputStreamReader(connection.getInputStream())) ;

	                String inputLine;
	                StringBuilder  response = new StringBuilder();

	                while ((inputLine = in.readLine()) != null) {

	                	response.append(inputLine);
	                	response.append(System.lineSeparator());
	                	
	                }
	                in.close();
				System.out.println("Positive: " +response.toString());
				  respo = response.toString();
				  
				  map.put(" ", new Object[] {respo, "Success"});
	         		resultup(path,  map);
	                
	               // writeToExcel(System.getProperty("user.dir") +PropertiesFileHandler.readProperty("testdesign"), respo);				
								
				// ---------------------------------- Verify the Response -----------------------------------  
				if(responseCode==200){

					if (response.toString().contains("errorText")) {
						ExtentTestManager.getTest().log(LogStatus.ERROR,
								"Response Code : " + responseCode + "<br />Repsonse Body :<br /> "
										+ APIHandler.converToPrettyJSONFormat(response.toString()));

					} else {
						JsonPath jp = new JsonPath(response.toString());
						jp.get("message").toString();

						ExtentTestManager.getTest().log(LogStatus.PASS,
								"response received");

					}

				} else {
					ExtentTestManager.getTest().log(LogStatus.FAIL,
							"Response Code : " + responseCode + "<br />Repsonse Body :<br /> "
									+ APIHandler.converToPrettyJSONFormat(response.toString()));
					//Report.updateTestLog("API Post Response", "Received Invalid response Code from API", Status.FAILNS);
					System.out.println("response: " +response.toString());
				}

				}

		}catch(Exception e){
			ExtentTestManager.getTest().log(LogStatus.ERROR,
					"Exception has been Received on Retreiving the data :" + e.getMessage());
			//Report.updateTestLog("API Post Response", "Exception has been Received on Retreiving multiple lines:"+ e.getMessage(), Status.FAIL);
			e.printStackTrace();
		}

	}
	
	@SuppressWarnings("static-access")
	public void apiPostRequest()  {
		try{
			// -------------------------   List of User passed parameters  ----------------------------
			String endPointURL = PropertiesFileHandler.readProperty("apiurl_"+environment);
			Client_ID = PropertiesFileHandler.readProperty("client_id");
			Client_Secret = PropertiesFileHandler.readProperty("client_secret");

			String payloadtemplatepath = System.getProperty("user.dir")
					+ PropertiesFileHandler.readProperty("Payload");
			String TestDataWB = System.getProperty("user.dir") + PropertiesFileHandler.readProperty("API_var");

			Jsoncnvt objCF = new Jsoncnvt();
			// ---------------------------------- Get Data from the Mapping ---------------------------	
						// ----------------------------- Get Data from the respective data files -------------------------		

			String inputPayload = objCF.freadTextFromFile(payloadtemplatepath).replace("*{", "{").replace("}*", "}");
			
			Map<Integer, Map<String, String>> inputDataMap = objCF.fGetDatafromExcelasMap(TestDataWB,"PayLoad");
			
			java.util.Set<Integer> intRows= inputDataMap.keySet();

			for(Integer row:intRows){

				String updatedBody = objCF.fupdateListofValues(inputPayload,inputDataMap.get(row));
				String updatedBodywithLineItems=updatedBody;
				
				String timeforReport =objCF.fgetUniqueTimeStamp();

				System.out.println(updatedBodywithLineItems);	

				// ---------------------------------- Make the Request ----------------------------------- 	
				URL object = new URL(endPointURL);
				HttpsURLConnection connection = (HttpsURLConnection) object.openConnection();

				connection.setRequestProperty("Client_ID", Client_ID);
				connection.setRequestProperty("Client_Secret", Client_Secret);
				connection.setRequestProperty("grant_type", "client_credentials");
				//connection.setRequestProperty("Scope", "WRITE");
				connection.setRequestProperty("Authorization", "Bearer " + accessToken);
				connection.setRequestProperty("Content-Type", "application/json");
				connection.setRequestMethod("POST");
				connection.setDoOutput(true);
				OutputStreamWriter wr = new OutputStreamWriter(connection.getOutputStream());
				wr.write(updatedBodywithLineItems);
				wr.flush();
				int responseCode = connection.getResponseCode();
				
				System.out.println("responseCode: "+ responseCode);

				BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
				String inputLine;
				StringBuffer response = new StringBuffer();
				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();

				System.out.println(response);
				// ---------------------------------- Verify the Response -----------------------------------  
				if(responseCode==200){

					if (response.toString().contains("errorText")) {
						ExtentTestManager.getTest().log(LogStatus.ERROR,
								"Response Code : " + responseCode + "<br />Repsonse Body :<br /> "
										+ APIHandler.converToPrettyJSONFormat(response.toString()));

					} else {
						JsonPath jp = new JsonPath(response.toString());
						jp.get("message").toString().equalsIgnoreCase("LetterGeneration Complete");

						ExtentTestManager.getTest().log(LogStatus.PASS,
								"LetterGeneration Complete");

					}

				} else {
					ExtentTestManager.getTest().log(LogStatus.FAIL,
							"Response Code : " + responseCode + "<br />Repsonse Body :<br /> "
									+ APIHandler.converToPrettyJSONFormat(response.toString()));
					//Report.updateTestLog("API Post Response", "Received Invalid response Code from API", Status.FAILNS);
					System.out.println(response.toString());
				}

			}

		}catch(Exception e){
			ExtentTestManager.getTest().log(LogStatus.ERROR,
					"Exception has been Received on Retreiving the data :" + e.getMessage());
			//Report.updateTestLog("API Post Response", "Exception has been Received on Retreiving multiple lines:"+ e.getMessage(), Status.FAIL);
			e.printStackTrace();
		}

	}

}
