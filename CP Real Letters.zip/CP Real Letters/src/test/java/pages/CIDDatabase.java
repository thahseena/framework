package pages;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import Reports.ExtentTestManager;
import core.BasePage;
import core.BaseTest;
import utilities.DBHandler;
import utilities.ExcelReader;
import utilities.PropertiesFileHandler;

public class CIDDatabase  {

	ExtentTest test;
	
	static String path = System.getProperty("user.dir") +PropertiesFileHandler.readProperty("testdata");
	
	public static String environment = PropertiesFileHandler.readProperty("Env");

	public void execute_CID_Query(String queryName, String strtrackingID) {

		try {
			String postgresqlDRIVER = "org.postgresql.Driver";

			System.out.println("Querying the CID Database for " + queryName + "... \n");

			String connectionUrl = PropertiesFileHandler.readProperty("cid_Url_" + environment);

			String Query = "";

			if (queryName.equals("OutboundData")) {

				Query = "select a.pdf_path,a.page_cnt,a.recipient_display_nm,a.recipient_middle_nm,a.recipient_last_nm,a.recipient_suffix,a.recipient_first_nm, \n" +
						"a.correspondence_tracking_fk,a.correspondence_outbound_pk,a.document_Archived_dtm,a.letter_generate_dtm,\n" + 
						"a.scaler_job_id,a.sensitive_info_flg,a.template_library_fk,k.letter_key,k.template_nm,b.template_path_txt,\n" + 
						"a.letter_tp_fk,c.letter_tp_cd,c.letter_tp_dscr,a.correspondence_channel_fk,d.channel_cd,d.channel_dscr,\n" + 
						"a.channel_output_txt,a.printing_vendor_id_cd,a.processing_system_fk,e.system_cd,e.system_dscr,\n" + 
						"a.recipient_class_fk,f.recipient_tp_cd,f.recipient_tp_dscr,a.repository_system_fk,g.system_cd,g.system_dscr,\n" + 
						"a.printed_iso_language_fk,h.iso_language_cd,h.iso_language_nm, a.company_fk,i.company_cd,i.company_nm, \n" + 
						"a.lob_fk,j.lob_cd,j.lob_nm,a.recipient_id_cd,a.pcp_id,a.address_ln_1,a.address_ln_2,a.city_nm,\n" + 
						"a.state_cd,a.zip_cd,a.zip_extension_cd,a.document_folder_id,a.print_dtm,a.mail_dtm,a.first_scan_dtm,\n" + 
						"a.printing_vendor_reference_id,a.mail_txt_intelligent_barcode,a.record_insert_dtm,a.record_update_dtm,\n" + 
						"a.requested_legacy_language_fk,a.correspondence_print_transaction_fk,a.priority_cd\n" + 
						"from cid.correspondence_outbound a , \n" + 
						"cid.template_library b,\n" + 
						"cid.letter_tp c,\n" + 
						"cid.correspondence_channel d,\n" + 
						"cid.system e,\n" + 
						"cid.recipient_tp f,\n" + 
						"cid.system g,\n" + 
						"cid.lookup_iso_language h,\n" + 
						"cid.lookup_company i,\n" + 
						"cid.lookup_lob j,\n" + 
						"cid.letter_template k\n" + 
						"where \n" + 
						"a.template_library_fk= b.template_library_pk \n" + 
						"and a.letter_tp_fk=c.letter_tp_pk \n" + 
						"and a.correspondence_channel_fk=d.correspondence_channel_pk\n" + 
						"and a.processing_system_fk=e.system_pk\n" + 
						"and a.recipient_class_fk=f.recipient_tp_pk\n" + 
						"and a.repository_system_fk= g.system_pk\n" + 
						"and a.printed_iso_language_fk=h.iso_language_pk\n" + 
						"and a.company_fk=i.company_pk\n" + 
						"and a.lob_fk=j.lob_pk\n" + 
						"and k.letter_template_pk=b.letter_template_fk\n" + 
						"and correspondence_tracking_fk in (' "+ strtrackingID + "')" ;
				
				
			} else if (queryName.equals("Xref query")) {
				
				//strtrackingID=lk
				
				Query = "select * from cid.print_priority_xref where letter_key = '"+ strtrackingID + "' and printing_vendor_id_cd = 'RRD'";

			} else if (queryName.equals("EventData")) {

				Query = "select * from cid.correspondence_event where correspondence_outbound_fk in  \n"
						+ "(select correspondence_outbound_pk from cid.correspondence_outbound where correspondence_tracking_fk = '"
						+ strtrackingID + "')";

			} else if (queryName.equals("StatusLog")) {

				Query = "SELECT a.correspondence_tracking_fk  ,s.system_cd, s.system_dscr ,s.system_tp,l.stt_log_pk, l.stt_log_cd\n"
						+ "          ,l.stt_log_dscr  ,a.tracking_activity_dtm  ,a.record_insert_by   ,a.record_insert_dtm ,a.record_update_dtm ,a.correspondence_tracking_activity_pk\n"
						+ "FROM cid.correspondence_tracking_activity a\n"
						+ "       JOIN cid.system s on a.system_fk = s.system_pk\n"
						+ "       JOIN cid.stt_log l on a.stt_log_fk = l.stt_log_pk\n"
						+ "WHERE correspondence_tracking_fk = '" + strtrackingID + "'";
				
			} else if (queryName.equals("BatchData")) {
			
			Query = "select * from cid.correspondence_batch_detail a \n" + 
					"join cid.correspondence_tracking b on a.job_unique_id_cd = b.job_unique_id_cd where  b.correspondence_tracking_pk  =  '" + strtrackingID + "'";
			}else {

				System.out.println("ERROR :   --->  Wrong Query name is mentioned");
			}

			String user = PropertiesFileHandler.readProperty("cid_User_" + environment);
			String password = PropertiesFileHandler.readProperty("cid_Pswd_" + environment);

			DBHandler handle = new DBHandler();
			ResultSet Result = handle.runTheQuery(postgresqlDRIVER, connectionUrl, Query, user, password);

			ResultSetMetaData rsmd = Result.getMetaData();
			int columnsNumber = rsmd.getColumnCount();

			/*LinkedHashMap<String, String> codes = new LinkedHashMap<String, String>();
			codes.put("1", "1011");
			codes.put("2", "1008");
			codes.put("3", "1005");
			codes.put("4", "1002");
			codes.put("5", "1003");
			codes.put("6", "1001");*/
			
			ArrayList<String> codes = new ArrayList<String> ();
			
			codes.add("1011");
			codes.add("1008");
			codes.add("1005");
			codes.add("1002");
			codes.add("1001");
			codes.add("1003");
			codes.add("1047");

			int LineItem = 0;
			while (Result.next()) {

				LineItem++;
				LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();

				for (int i = 1; i <= columnsNumber; i++) {

					String columnValue = Result.getString(i);
					System.out.print("\n" + rsmd.getColumnName(i) + " : " + columnValue);

					if (rsmd.getColumnName(i).equals("stt_log_cd")) {

						//if (codes.get(Result.getRow() + "").equals(columnValue)) {
						if (codes.contains(columnValue)) {

							System.out.println("CID-DB : " + queryName + "  [Row : '" + Result.getRow() + "' of '"
									+ strtrackingID + "' has 'stt_log_cd' as : " + columnValue + "]");
							ExtentTestManager.getTest().log(LogStatus.PASS,
									"CID-DB : " + queryName + "  [Row : '" + Result.getRow() + "' of '" + strtrackingID
											+ "' has 'stt_log_cd' : " + columnValue + "]");
						} else {
							System.out.println("CID-DB : " + queryName + "  [Row : '" + Result.getRow() + "' of '"
									+ strtrackingID + "' has 'stt_log_cd' as : " + columnValue + "]");
							ExtentTestManager.getTest().log(LogStatus.FAIL,
									"CID-DB : " + queryName + "  [Row : '" + Result.getRow() + "' of '" + strtrackingID
											+ "' has 'stt_log_cd' : " + columnValue + "]");

						}
					}

					map.put(rsmd.getColumnName(i) + "", columnValue + "");
				}
				if (!queryName.equals("StatusLog")) {

					if (Result.getRow() == 1) {

						System.out.println("CID-DB : " + queryName + "  [Row : '" + Result.getRow() + "' of '"
								+ strtrackingID + "' has data]");
						ExtentTestManager.getTest().log(LogStatus.PASS, "CID-DB : " + queryName + "  [Row : '"
								+ Result.getRow() + "' of '" + strtrackingID + "' has data]");
					} else {

						System.out.println("CID-DB : " + queryName + "  [Row : '" + Result.getRow() + "' of '"
								+ strtrackingID + "' is additional]");
						ExtentTestManager.getTest().log(LogStatus.INFO, "CID-DB : " + queryName + "  [Row : '"
								+ Result.getRow() + "' of '" + strtrackingID + "' is additional]");

					}
				}

				System.out.println("CID values are being written**************************");
				ExcelReader.storeIntoExcel( path, "CID_DB_" + queryName, LineItem + "", map);

			}
			
			if(LineItem==0) {
				
				ExtentTestManager.getTest().log(LogStatus.FAIL,
						"CID Database ("+queryName+") has no records for the Tracking ID : " + strtrackingID);
				
				System.out.println("CID Database ("+queryName+") has no records for the Tracking ID : " + strtrackingID);
			}

		} catch (Exception e) {

			ExtentTestManager.getTest().log(LogStatus.FAIL, "Error with CID DB : " + queryName + " : " + e.toString());
			System.out.println("Error with CID DB : " + queryName + " : " + e.toString());
			e.printStackTrace();
		}

	}

}
