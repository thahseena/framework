package pages;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

import org.apache.commons.io.FileUtils;

import com.relevantcodes.extentreports.LogStatus;

import Reports.ExtentTestManager;
import core.BaseTest;
import utilities.PropertiesFileHandler;

public class SearchFile {
	
	public static String environment = PropertiesFileHandler.readProperty("Env");
	
	
	
		public static String StagingFolder = "";
	//public static String StagingFolder = "C:\\Users\\raskumar\\Documents";
	public File[] filesFound;
	public ArrayList<String> fileList = new ArrayList<String>();
	public static String pdfp = PropertiesFileHandler.readProperty("pdfpath");
	
	public void isFileFound(final String trackingNumber,final String LOB) {
		
		System.out.println("search environment " + environment);
		
		if ((LOB.equalsIgnoreCase("SMG Application Status")) || (LOB.equalsIgnoreCase("SMG Follow Up Letter"))) {
			StagingFolder = PropertiesFileHandler.readProperty("StagingFolder4_"+environment);
			
		}
		
		else if(LOB.equalsIgnoreCase("Member IDN Denial Letter")) {
			StagingFolder = PropertiesFileHandler.readProperty("StagingFolder3_"+environment);
		
		}
		
		else if(LOB.equalsIgnoreCase("Overpayment Recovery Request")) {
			StagingFolder = PropertiesFileHandler.readProperty("StagingFolder1_"+environment);
		
		}
		
		else if((LOB.equalsIgnoreCase("Second Level Appeal Previously Received")) ||(LOB.equalsIgnoreCase("Ineligible Review and Reconsideration"))
				|| (LOB.equalsIgnoreCase("Uphold Review and Reconsideration"))|| (LOB.equalsIgnoreCase("Adjustment Review and Reconsideration")) 
				|| (LOB.equalsIgnoreCase("Appeal Review and Reconsideration"))|| (LOB.equalsIgnoreCase("Previously Received Review and Reconsideration"))
				|| (LOB.equalsIgnoreCase("Proactive Education - Member Adherent"))|| (LOB.equalsIgnoreCase("Proactive Education - Member General Reminder"))
				|| (LOB.equalsIgnoreCase("Proactive Education - Member Non-Adherence"))|| (LOB.equalsIgnoreCase("Proactive Education - Member Social Determinants of Health"))
				|| (LOB.equalsIgnoreCase("Second Level Appeal Adjustment"))|| (LOB.equalsIgnoreCase("Second Level Appeal Ineligible"))
				|| (LOB.equalsIgnoreCase("Second Level Appeal Payment Policy Denial Uphold"))|| (LOB.equalsIgnoreCase("Second Level Appeal Previously Received"))
				|| (LOB.equalsIgnoreCase("Second Level Appeal Uphold"))|| (LOB.equalsIgnoreCase("Uphold IHT Denial"))|| (LOB.equalsIgnoreCase("Proactive Education - Member Welcome")))
				{
			StagingFolder = PropertiesFileHandler.readProperty("StagingFolder1_"+environment);
		
		}
		
		
		
		

		try {
			File folder = new File(StagingFolder);

			System.out.println("*************\nSearching the PDF files...\n*************");
			
			FilenameFilter txtFileFilter = new FilenameFilter() {
				public boolean accept(File dir, String name) {

					if (name.contains(trackingNumber)) {
						 System.out.println(name);
						fileList.add(dir + "\\" + name);
						
						
						
						return true;

					} else {
						return false;
					}
				}

			};

			filesFound = folder.listFiles(txtFileFilter);

			
			if (fileList.isEmpty()) {
				System.out.println("The tracking ID '" + trackingNumber + "' has no PDF File in the path : " + StagingFolder);
				ExtentTestManager.getTest().log(LogStatus.FAIL,
						"The tracking ID '" + trackingNumber + "' has no PDF File in the path : " + StagingFolder);
			}

			for (String file : fileList) {
				if (file.contains(trackingNumber)) {
					
					// System.out.println(file);
					
					// System.out.println(StagingFolder+"\\"+trackingNumber+".pdf");
					// System.out.println(StagingFolder+"\\"+trackingNumber+".txt");
					
					//copyFile(file, pdfp);
					//copyFile(StagingFolder+"\\"+trackingNumber+".txt", pdfp);

					System.out.println(file);
					ExtentTestManager.getTest().log(LogStatus.PASS, "The tracking ID '" + trackingNumber
							+ "' has the PDF file generated in the path : " + StagingFolder);
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static void copyFile(String from, String to) throws IOException{
		Path src = Paths.get(from); 
		Path dest = Paths.get(to); 
		//Files.copy(src.toFile(), dest.toFile());
		Files.copy(src, dest);
}

	
	
	public static void copyDirectory(String source, String destination) {

		try {
			File srcDir = new File(source);

			File destDir = new File(destination);

			FileUtils.copyDirectory(srcDir, destDir);
			

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
