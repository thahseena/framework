package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import Reports.ExtentTestManager;
import core.BasePage;
import utilities.PropertiesFileHandler;

public class InspireScaler extends BasePage {

	public InspireScaler(WebDriver driver) {
		super(driver);
	}

	ExtentTest test;
	By btnOK = By
			.xpath("//*[name()='text'][text()='ParseTrackingXML']/following-sibling::*[name()='text'][text()='OK']");

	// PageObjects
	// Login
	private static By uiTextUsername = By.id("usernameInput");
	private static By uiTextPassword = By.id("passwordInput");
	private static By uiBtnLogin = By.xpath("//input[@value='SIGN IN']");
	private static By uiTabJobs = By.xpath("//div[@class='app-header-btn-icon']/following-sibling::div[text()='Jobs']");
	private static By uiTabJobSearch = By.xpath("//div[text()='Job Search']");
	private static By uiTxtJobID = By.name("jobId");
	private static By uiBtnSearch = By.xpath("//div[text()='SEARCH']");
	private static By uiLabelStatus = By.xpath("//div[text()='Status']/../following-sibling::div/div");
	private static By uiLabelJobID = By.xpath("//div[@data-context-id]/div[1]/a");
	private static By uiLabelJobStatus = By.xpath("//div[@data-context-id]/div[4]/span");
	private static By uiLabelNoResult = By.xpath("//div[text()='No result found.']");
	private static By notifys = By.xpath("//*[text ()= 'NotifySourceSystem']");
	private static By scriptlog = By.xpath("//*[text ()= 'Script Log']");
	private static By Reqbo = By.xpath("(//*[contains(@class,'messageBaseStyle')])[4]");
	private static By debug = By.xpath("(//*[text()[contains(.,'DEBUG')]])[2]"); 
	
	
	
	public boolean inspireLoginFlag;

	public void login() {

		inspireLoginFlag = false;

		try {
			String userName = PropertiesFileHandler.readProperty("inspireURL_User");
			String password = PropertiesFileHandler.readProperty("inspireURL_Pswd");

			click(uiTextUsername);
			clearText(uiTextUsername);
			setText(uiTextUsername, userName);
			click(uiTextPassword);
			setText(uiTextPassword, password);
			
			

			click(uiBtnLogin);
			waitForElement(uiTabJobs);
			inspireLoginFlag = true;
			
			ExtentTestManager.getTest().log(LogStatus.PASS, "logging into the Inspire Application Success");

		} catch (Exception e) {

			ExtentTestManager.getTest().log(LogStatus.FAIL, "Error with logging into the Inspire Application");
			System.out.println("Error with logging into the Inspire Application" + e.toString());

			BasePage.takeScreenshot("LoginPageError", "InspireScaler");

		}

	}

	public void searchTheJobDetails(String strtrackingID, String strJobID) {

		try {
			System.out.println("*************\nSearching in the Inspire application... \n*************");

			Thread.sleep(2000);
			waitForElement(uiTabJobs);

			click(uiTabJobs);
			waitForElement(uiTabJobSearch);

			click(uiTabJobSearch);
			waitForElement(uiTxtJobID);

			Thread.sleep(2000);
			clearText(uiTxtJobID);
			setText(uiTxtJobID, strJobID);

			click(uiBtnSearch);
			boolean inspireFlag = false;

			try {
				waitForElement(uiLabelJobID);
				inspireFlag = true;
			} catch (Exception e) {

				e.printStackTrace();

				if (isElementEnabled(uiLabelNoResult)) {

					ExtentTestManager.getTest().log(LogStatus.FAIL,
							"Inspire Application has no records for the Tracking ID : " + strtrackingID);
					BasePage.takeScreenshot(strtrackingID, "InspireScaler_Page1");

					System.out.println("Inspire Application has no records for the Tracking ID : " + strtrackingID);
				}
			}

			if (inspireFlag == true) {

				Thread.sleep(2000);
				if (driver.findElement(uiLabelJobID).getText().equals(strJobID)) {

					System.out.println("Job ID : " + strJobID + " is searched sucessfully");

					String uiJobStatus = driver.findElement(uiLabelJobStatus).getText();

					BasePage.takeScreenshot(strtrackingID, "InspireScaler_Page1");

					if (driver.findElement(uiLabelJobStatus).getText().equals("Completed")) {

						System.out.println("Job status is 'Completed'");
						ExtentTestManager.getTest().log(LogStatus.PASS,
								"Inspire Scaler Application  [Status of : '" + strJobID + "' is Completed  ]");
						
						
					} else {

						System.out.println("Job status is : " + uiJobStatus);
						ExtentTestManager.getTest().log(LogStatus.FAIL, "Inspire Scaler Application  [Status of : '"
								+ strJobID + "' is :" + uiJobStatus + "  ]");
					}
					
					

					click(uiLabelJobID);
					Thread.sleep(4000);

					switchToWindow(1);
					Thread.sleep(4000);
					
					String uiStatus = driver.findElement(uiLabelStatus).getText();
					
					System.out.println("text taken from status : " + uiStatus);

					BasePage.takeScreenshot(strtrackingID, "InspireScaler_Page2");

					System.out.println("Job status on New Window is : " + uiStatus);
					
					
					Thread.sleep(4000);
					
					click(notifys);
					
					BasePage.takeScreenshot(strtrackingID, "InspireScaler_Page3");

					System.out.println("notifys");
					
					Thread.sleep(3000);
					
					click(scriptlog);
					
					BasePage.takeScreenshot(strtrackingID, "InspireScaler_Page4");

					System.out.println("log:");
					
					Thread.sleep(3000);
					
					click(Reqbo);
					
					click(debug);

					JavascriptExecutor js = (JavascriptExecutor) driver;
				//	js.executeScript("scroll(0, 250)");
				//	js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("(//*[text()[contains(.,'DEBUG')]])[1]")));
					
					BasePage.takeScreenshot(strtrackingID, "InspireScaler_Page5");

					System.out.println("Reqbo:");
					
					System.out.println("NotifiedSystem 'Completed'");
					ExtentTestManager.getTest().log(LogStatus.PASS,
							"Inspire Scaler Application  - Notified Source System is good  ");
					
					
					
							
					
					

					//driver.close();

				}

			}
		} catch (Exception e) {

			ExtentTestManager.getTest().log(LogStatus.FAIL, "Error with working in the Inspire Application");
			System.out.println("Error with working in the Inspire Application" + e.toString());

			BasePage.takeScreenshot(strtrackingID, "InspireScalerError");

		}

	}

}