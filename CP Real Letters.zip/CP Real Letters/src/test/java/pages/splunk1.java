package pages;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import Reports.ExtentTestManager;
import core.BasePage;
import utilities.PropertiesFileHandler;

public class splunk1 extends BasePage {

	public splunk1(WebDriver driver) {
		super(driver);
	}

	ExtentTest test;
	
	//pageObjets
	
	private static By 		spusername = By.xpath("//input[@name='username']");
	private static By 		sppassword = By.xpath("//input[@name='password']");
	private static By 		splogin = By.xpath("//input[@value='Sign In']");
	private static By 		spsearch =  By.xpath("//td[@class='search-input']//pre[@class=' ace_editor ace-spl-light']");
	private static By 		spsearch1 = By.xpath("//td[@class='search-input']//pre/textarea[@class = 'ace_text-input']");
	private static By 		spsearchrange = By.xpath("//tr/td[@class='search-timerange']");
	private static By 		spsearchmode =   By.xpath("//*[@class='accordion-group active']//*[text()='Relative']//following::a[text()='                        Month to date                ']");
	private static By 		spclicksearch =	 By.xpath("//*[@class='search-button']");
	private static By 		spshowlines1 =	By.xpath("(//div/a[text()='Show all 14 lines'])[1]");
	private static By 		Clickagan =	By.xpath("//div[@class='modalize-table-bottom']");
	private static By 		spshowlines2 =	By.xpath("//div/a[text()='Show all 14 lines']");
	private static By 		uiLabelNoResult = By.xpath("//div[text()='No result found.']");
			
			
			
	
	public static boolean splunkLoginFlag;

	public void login() throws IOException {
		
		
		BasePage base = new BasePage(driver);
		
		//base.switchToWindow(2);

		splunkLoginFlag = false;
		
		try {
			String userName = PropertiesFileHandler.readProperty("inspireURL_User");
			String password = PropertiesFileHandler.readProperty("inspireURL_Pswd");
			
			System.out.println("Credentials = " + userName+"/" + password);
			
			Thread.sleep(7000);

			click(spusername);
			setText(spusername, userName);
			click(sppassword);
			setText(sppassword, password);
			
			Thread.sleep(8000);
			
			click(splogin); 
			Thread.sleep(5000);
			
			System.out.println("lg 1");
			
			
			
			waitForElements(spsearchrange);
			
			System.out.println("lg 2");

			click(spsearchrange);
			waitForElement(spsearchmode);
			Thread.sleep(2000);
			
			click(spsearchmode);
						
			System.out.println("lg 3");
			
			splunkLoginFlag = true;
			
			//TestUtil.captureScreenshot();
			ExtentTestManager.getTest().log(LogStatus.PASS, "Successfully login into Splunk Application");
			BasePage.takeScreenshot("LoginPage", "InspireScaler");
			

		} catch (Exception e) {

			ExtentTestManager.getTest().log(LogStatus.FAIL, "Error with logging into the Splunk Application");			
			System.out.println("Error with logging into the Splunk Application" + e.toString());

			BasePage.takeScreenshot("LoginPageError", "InspireScaler");

		}

	}

	public void searchTheJobDetails(String strtrackingID, String strJobID, String ltype) throws IOException {

		try {
			System.out.println("*************\nSearching in the Splunk Application... \n*************");
			
			
				
			driver.navigate().refresh();
			System.out.println("sp 0");
			Thread.sleep(5000);
			
			click(spsearch);
			System.out.println("sp 1");
			
			//clearText(spsearch);
		//	Thread.sleep(5000);
			
			clearTextb(spsearch1);
			System.out.println("sp 2");
			
			//driver.navigate().refresh();
			
			Thread.sleep(5000);
			System.out.println("sp 3");
			
			setTextq(spsearch1, strtrackingID);
			System.out.println("sp 4");
			
			
			clicks(spclicksearch);
			//waitForElement("spshowlines1");
			
		//	click("spshowlines1");
			//click("Clickagan");
			//click("spshowlines2");
			Thread.sleep(5000);
			
			boolean inspireFlag = false;

			try {
				waitForElements(spshowlines1);
				inspireFlag = true;
			} catch (Exception e) {

				e.printStackTrace();

				if (isElementEnableds(uiLabelNoResult)) {
					
					ExtentTestManager.getTest().log(LogStatus.FAIL,
							"Splunk Application has no records for the Tracking ID : " + strtrackingID);
					BasePage.takeScreenshot(strtrackingID, "Splunk");
					System.out.println("splunk Application has no records for the Tracking ID : " + strtrackingID);
					
					//driver.close();
					switchToWindow(0);
				}
			}

			if (inspireFlag == true) {
				
				System.out.println("ltype :" + ltype);
				
				if (ltype.equalsIgnoreCase("real")) {
				
				click(spshowlines1);
				System.out.println("realtime : sp 7");
				
				JavascriptExecutor js = (JavascriptExecutor) driver;
				 js.executeScript("window.scrollBy(0,3000)");
				
				 ExtentTestManager.getTest().log(LogStatus.PASS,"Splunk Application  : realtime Record found for  : '" + strtrackingID );
					BasePage.takeScreenshot(strtrackingID, "Splunk");
					//String screenshotPatsh = System.getProperty("user.dir") + "\\Screenshot\\";
					//System.out.println(screenshotPatsh);
			       // Screenshot s=new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver);
			       // ImageIO.write(s.getImage(),"jpeg",new File(screenshotPatsh));	
				 
								}
				
				
				else {
					
					click(spshowlines1);
					System.out.println("batch : sp 7");
				
				
					click(Clickagan);
					System.out.println("sp 10");
					
					System.out.println("sp 8");
					click(spshowlines2);
					
					Thread.sleep(5000);
					//JavascriptExecutor js = (JavascriptExecutor) driver;
					// js.executeScript("window.scrollBy(0,3000)");
					
					System.out.println("sp 9");
				
						System.out.println("Splunk displayed the details");
						
						ExtentTestManager.getTest().log(LogStatus.PASS,"Splunk Application  : Record found for  : '" + strtrackingID );
						BasePage.takeScreenshot(strtrackingID, "Splunk");
						//String screenshotPatsh = System.getProperty("user.dir") + "\\Screenshot\\";
						//System.out.println(screenshotPatsh);
				       // Screenshot s=new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver);
				       // ImageIO.write(s.getImage(),"jpeg",new File(screenshotPatsh));	
						
						
					
						
				}	
						

					} else {
						
						//Screenshot screenshot=new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver); 
						//ImageIO.write(screenshot.getImage(),"PNG",new File("path of the file"));
						
				        // capture screenshot and store the image
						

						System.out.println("splunk status of : " + strtrackingID);
						
						ExtentTestManager.getTest().log(LogStatus.FAIL,"Splunk Application  : No Record found for  : '" + strtrackingID );
						BasePage.takeScreenshot(strtrackingID, "Splunk");
					}
					
				
					//Thread.sleep(1000);
				//	click("prof");
				//	Thread.sleep(1000);
				//	click("sigout");
				//	Thread.sleep(1000);
					
					//driver.close();
					switchToWindow(0);
					

				
				
			
		} catch (Exception e) {
			ExtentTestManager.getTest().log(LogStatus.FAIL, "Error with working in the Splunk Application");
			System.out.println("Error with working in the Splunk Application" + e.toString());

			BasePage.takeScreenshot(strtrackingID, "InspireScalerError");

		}

	}
	
	
	
}
