package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import Reports.ExtentTestManager;
import core.BasePage;
import core.BaseTest;
import utilities.PropertiesFileHandler;

public class PegaApplication extends BasePage {
	
	public PegaApplication(WebDriver driver) {
		super(driver);
	}
	ExtentTest test;
	//By btnOK = By.xpath("//*[name()='text'][text()='ParseTrackingXML']/following-sibling::*[name()='text'][text()='OK']");
	 
	/** PageObjects  *********************************************************************************************************/
	 
	
	//private static By loginbutton = By.xpath("//*[@id='tilesHolder']/div[1]/div/div");
	private static By inputv = By.xpath("//input[@type = 'email']");  
	private static By submit = By.xpath("//input[@type = 'submit']"); 
    private static By uiTabCorrReqTrack = By.xpath("//span[text()='Corr Req Track']");
    private static By uiTabCorrReqTrack_new = By.xpath("//div/span[text()='Corr Req Track']");
   // private static By uiTabRecords = By.xpath("//div[@id='HARNESS_CONTENT']//label[text()='Records']");
   // private static By uiTabRecords_new = By.xpath("//div[@id='HARNESS_CONTENT']//span[text()='Records']");
    private static By uiTabRecords = By.xpath("//div[@id='HARNESS_CONTENT']//*[text()='Records']");
    private static By uiTabRecords_new = By.xpath("//div[@id='HARNESS_CONTENT']//*[text()='Records']");
    private static By uiTxtTrackingID = By.xpath("//div[@id='CT']//input[@id='pySearchTerm']");
    //private static By uiTxtTrackingID_new = By.xpath("//input[@placeholder='Search...']");
    private static By uiTxtTrackingID_new = By.xpath("//div[@class='content-inner ']//input[@placeholder='Search...']");
    private static By uiIconSearch = By.xpath("//i[@class='pi pi-search']");
    
    private static By uiLavelCorrIDEdit = By.xpath(" //table[@pl_prop_class='HF-Data-CorrReq-Track']//tr[@class='editMode oddRow cellCont']/td[1]/div");
    private static By uiLabelCorrID = By.xpath("//table[@pl_prop_class='HF-Data-CorrReq-Track']//tr[@class='oddRow cellCont']/td[1]/div");
    //private static By uiLabelCorrStatus = By.xpath("//table[@pl_prop_class='HF-Data-CorrReq-Track']//tr[@class='editMode oddRow cellCont']//td[5]/div//input");   
    private static By uiLabelCorrStatus = By.xpath("//table[@pl_prop_class='HF-Data-CorrReq-Track']//tr[@class='editMode oddRow cellCont']//td[@data-attribute-name='CorrStatus']//input");
    private static By uiLabelCorrSource = By.xpath("//table[@pl_prop_class='HF-Data-CorrReq-Track']//tr[@class='editMode oddRow cellCont']//td[@data-attribute-name='CorrSource']//input");
    ////table[@pl_prop_class='HF-Data-CorrReq-Track']//tr[@class='oddRow cellCont']//td[@data-attribute-name='CorrStatus']
    private static By uicloseAlert = By.xpath("//div[text()='Close']");
    private static By uiLabelNoItems = By.xpath("//table[@pl_prop_class='HF-Data-CorrReq-Track']//*[text()='No items']");
    String strURL ="";
   
   /** Method 1 
 * @throws InterruptedException ********************************************************************************************************/
    
    
    
    
    public void login() throws InterruptedException {
    	
    	
    	setText(inputv, "tamanullah@healthfirst.org");
    	click(submit);
    	Thread.sleep(5000);
    	
    }
    
	
	public void searchTheJobDetails(String strCorrID) {
			
				
		try {
			
			System.out.println("*************\nSearching in the Pega applciation... \n*************");
			
			
			if (environment.equals("RT"))

			{
			
			 strURL = PropertiesFileHandler.readProperty("pegaURL_RT");
			
			}
			
			
			else if (environment.equals("ST")) {
				
			 strURL = PropertiesFileHandler.readProperty("pegaURL_ST");	
				
			}
			
			else  {
				
				System.out.println("ERROR :   --->  Application Environment is not configured properly");
			}
			
			
			
			if((strURL.contains("pegaclaimsrt.healthfirst.org")) || (strURL.contains("pegaclaimsst.healthfirst.org"))) {
				
				Thread.sleep(4000);
				
				waitForElement(uiTabCorrReqTrack_new);
				click(uiTabCorrReqTrack_new);

				fnSwitchFrame(uiTabRecords_new);

				waitForElement(uiTabRecords_new);

				click(uiTabRecords_new);
				
				Thread.sleep(3000);
				waitForElement(uiTxtTrackingID_new);

				Thread.sleep(3000);
				clearText(uiTxtTrackingID_new);
				
				Thread.sleep(3000);
				setText(uiTxtTrackingID_new, strCorrID);
				
			}else if((strURL.contains("hforg-stg1-internal.pegacloud.io")) || (strURL.contains("hforg-dt1-internal.pegacloud.io")) ) {
				
				waitForElement(uiTabCorrReqTrack);
				try {
					
					Thread.sleep(3000);
					clickByJS(uicloseAlert);
					
					Thread.sleep(3000);
					
				} catch (Exception e) {
					
					e.printStackTrace();
				}
				click(uiTabCorrReqTrack);
				
				fnSwitchFrame(uiTabRecords);

				waitForElement(uiTabRecords);

				click(uiTabRecords);

				waitForElement(uiTxtTrackingID);

				Thread.sleep(3000);
				clearText(uiTxtTrackingID);
				
				Thread.sleep(3000);
				setText(uiTxtTrackingID, strCorrID);
				
			}
			
			Thread.sleep(3000);
			click(uiIconSearch);
			
			Thread.sleep(3000);
			
			boolean pegaFlag = false;
			
			try {
				waitForElement(uiLabelCorrID);
				pegaFlag =true;
				
			} catch (Exception e) {
				
				e.printStackTrace();
				if(isElementEnabled(uiLabelNoItems)) {
					
					ExtentTestManager.getTest().log(LogStatus.INFO,
							"Pega Application has no records for the Tracking ID : " + strCorrID);
					BasePage.takeScreenshot(strCorrID, "PegaApplicationError");
					
					System.out.println("Pega Application has no records for the Tracking ID : " + strCorrID);
				}
				
			}
			
			if (pegaFlag == true) {

				click(uiLabelCorrID);

				waitForElement(uiLavelCorrIDEdit);

				if (driver.findElement(uiLavelCorrIDEdit).getText().equals(strCorrID)) {

					System.out.println("Corr Unique ID : " + strCorrID + " is searched sucessfully");
					
					Thread.sleep(3000);

					String uiJobStatus = driver.findElement(uiLabelCorrStatus).getAttribute("value");
					
					String uiJobSource = driver.findElement(uiLabelCorrSource).getAttribute("value");
					
					System.out.println("*******************Job status is "+ uiJobStatus);

					BasePage.takeScreenshot(strCorrID, "Pega_Screen");

					if (uiJobStatus.equals("Success")) {

						System.out.println("Job status is 'Success'");
						ExtentTestManager.getTest().log(LogStatus.INFO,
								"Pega Application  [TrackingID status of : '" + strCorrID + "' is Success " + " and triggered source system is " +uiJobSource);
					} else {
						System.out.println("Job status is : " + uiJobStatus);
						ExtentTestManager.getTest().log(LogStatus.INFO, "Pega Application  [TrackingID status of : '"
								+ strCorrID + "' is : " + uiJobStatus +    " and triggered source system is " +uiJobSource);
					}
				} else {

					ExtentTestManager.getTest().log(LogStatus.FAIL,
							"Pega Application  [TrackingID : '" + strCorrID + "' is not found on Web ]");
					BasePage.takeScreenshot(strCorrID, "PegaApplicationError");
				}
				driver.switchTo().defaultContent();

			}
		} catch (Exception e) {
			
			ExtentTestManager.getTest().log(LogStatus.FAIL, "Error with logging into the Pega Application");
			System.out.println("Error with logging into the Pega Application" + e.toString());
			
			BasePage.takeScreenshot(strCorrID, "PegaApplicationError");
			
		} 
		
		
	}	
	
	
}