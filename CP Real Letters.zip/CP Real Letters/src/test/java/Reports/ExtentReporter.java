package Reports;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import core.BaseTest;
import core.DriverFactory;
import pages.SearchFile;

public class ExtentReporter implements ITestListener {

	private static ExtentReports extent;
	public static ExtentTest test;
	public static String time = getDate();
	public static String ReportName = "";
	public static String ReportFolder = "";
	public static String latestFolder = "";

	public String report;
	public static Logger logger = Logger.getLogger(BaseTest.class);

	@SuppressWarnings("unused")
	private static String getTestMethodName(ITestResult iTestResult) {
		return iTestResult.getMethod().getConstructorOrMethod().getName();
	}
	public static String getDate() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String name = dateFormat.format(date).toString().replaceFirst(" ", "_").replaceAll("/", "_").replaceAll(":",
				"_");
		return name;
	}
	public void onTestStart(ITestResult result) {
		
		/*ReportFolder = "Q:\\Enterprise Correspondence\\Automation\\Automation PDF Validation\\S - Letter\\Downstream\\reports\\" + "report"
				+ "_" + time ;*/
		ReportFolder = System.getProperty("user.dir") + "/reports"  + "/" + "report"
				+ "_" + time ;
		latestFolder = System.getProperty("user.dir") + "/reports/Latest";
		
		try {
			FileUtils.cleanDirectory(new File (latestFolder));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		logger.info("Starting test: "+DriverFactory.getInstance().getDriver() +" : "+result.getMethod().getMethodName());
	}

	public void onTestSuccess(ITestResult result) {
		/*ExtentTestManager.getTest().log(LogStatus.PASS, result.getMethod().getMethodName());*/
	}


	public void onTestFailure(ITestResult result) {
		String scrnshot = result.getMethod().getMethodName();
		try {
			WebDriver webDriver = new DriverFactory().getInstance().getDriver();
			String base64Screenshot = "data:image/png;base64," + ((TakesScreenshot)webDriver ).
					getScreenshotAs(OutputType.BASE64);
			ExtentTestManager.getTest().log(LogStatus.FAIL,
					ExtentTestManager.getTest().addBase64ScreenShot(base64Screenshot));
			ExtentTestManager.getTest().log(LogStatus.FAIL,result.getThrowable());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public void onTestSkipped(ITestResult result) {
		ExtentTestManager.getTest().log(LogStatus.SKIP, result.getMethod().getMethodName());
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		String scrnshot = result.getMethod().getMethodName();
		try {
			WebDriver webDriver = new DriverFactory().getInstance().getDriver();
			String base64Screenshot = "data:image/png;base64," + ((TakesScreenshot)webDriver ).
					getScreenshotAs(OutputType.BASE64);
			ExtentTestManager.getTest().log(LogStatus.FAIL,
					ExtentTestManager.getTest().addBase64ScreenShot(base64Screenshot));
			ExtentTestManager.getTest().log(LogStatus.FAIL,result.getThrowable());
			ExtentTestManager.getTest().log(LogStatus.FAIL, result.getMethod().getMethodName());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void onStart(ITestContext context) {
		try {

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void onFinish(ITestContext context) {
		//ExtentTestManager.endTest();
		getReporter().flush();
		SearchFile.copyDirectory(ExtentReporter.ReportFolder,ExtentReporter.latestFolder);
	}

	//**
	// * @param stepName
	// * @param details
	// **
	public static void extentLogger(String stepName, String details) {
		ExtentTestManager.getTest().log(LogStatus.INFO, stepName, details);
	}


	public synchronized static ExtentReports getInstance(){
		if(extent == null){
			extent = new ExtentReports(System.getProperty("user.dir")+"/Extent-Report/ExtentReport.html", true);
			extent.addSystemInfo("Group Name", "CoderClub").addSystemInfo("Environment","QA")
			.addSystemInfo("Team Name", "GroupGreen");
		}
		return extent;
	}
	public synchronized static ExtentReports getReporter() {
		if (extent == null) {
			//Set HTML reporting file location;
			
			/*ReportName = ReportFolder+"\\report_" + time + ".html";	
			
			System.out.println(ReportName);*/
			
			ReportName = System.getProperty("user.dir") + "/reports"  + "/" + "report"
					+ "_" + time + "/" + "report" + "_" + time + ".html";
			
			System.out.println("ReportName:" + ReportName);
			extent = new ExtentReports(ReportName, true);
		}
		return extent;
	}
}
