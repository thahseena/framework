
package Reports;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.relevantcodes.extentreports.LogStatus;

public class ApExcelReader {

	public static String ExcelReportName = "";
	public static ArrayList<String> ID_List = new ArrayList<String>();

	public static ArrayList<ArrayList<Object>> list = new ArrayList<ArrayList<Object>>();
	static LinkedHashMap<String,Object[]> map = new LinkedHashMap<String,Object[]>();
	
	@SuppressWarnings({ "resource" })
	
		public static ArrayList<String>  readFromExcel(String inputFile, String sheetName, String ColName, String ColName1) throws Exception {

		System.out.println("*************\nReading the Excel Data...\n*************");
		
		System.out.println(inputFile);

		InputStream ExcelFileToRead = new FileInputStream(inputFile);
		XSSFWorkbook workBook = new XSSFWorkbook(ExcelFileToRead);
		XSSFSheet sheet = workBook.getSheet(sheetName);

		int TotalRows = sheet.getLastRowNum();
		
		XSSFRow header = sheet.getRow(0);

		for (int row = 2; row <= TotalRows; row++) {

			try {
				
				String cellvalue = getCellValue(sheet.getRow(row).getCell(getColumnNumber(header, ColName))).trim();
				
						
				if (!cellvalue.isEmpty()) {

					ID_List.add(cellvalue);
					
				}

			} catch (NullPointerException ex) {
				
				System.out.println(ex.toString());
			}
		}

		System.out.println("Api and DB data taken --> " + ID_List.toString());

		return ID_List;
	}
	
	public static ArrayList<ArrayList<Object>> extractAsList (String inputFile, String sheetName){
		  
		  //ArrayList<ArrayList<Object>> list = new ArrayList<ArrayList<Object>>();
		  int maxDataCount =0;
		  try{
		       FileInputStream file = new FileInputStream(inputFile);
		      
		      // Create Workbook instance holding reference to .xlsx file
		      XSSFWorkbook workbook = new XSSFWorkbook(file);

		      // Get first/desired sheet from the workbook
		     // XSSFSheet sheet = workbook.getSheetAt(2);
		      XSSFSheet sheet = workbook.getSheet(sheetName);

		      // Iterate through each rows one by one
		      Iterator<Row> rowIterator = sheet.iterator();
		      while (rowIterator.hasNext()) {
		    
		          Row row = rowIterator.next();
		       
		          //Skip the first row beacause it will be header
		          if (row.getRowNum() == 0) {
		     
		              maxDataCount = row.getLastCellNum();
		              continue;
		     }
		    
		    /**
		     * if row is empty then break the loop,do not go further
		    
		    if(sheet.isRowEmpty(row,maxDataCount)){
		     //Exit the processing
		     break;
		    }
		     */
		    ArrayList<Object> singleRows = new ArrayList<Object>();
		    
		    // For each row, iterate through all the columns
		    for(int cn=0; cn<maxDataCount; cn++) {

		        Cell cell = row.getCell(cn, Row.CREATE_NULL_AS_BLANK);
		     
		        switch (cell.getCellType()) {
		         
		            case Cell.CELL_TYPE_NUMERIC:
		        
		                                         if(DateUtil.isCellDateFormatted(cell)){
		                                             singleRows.add( new SimpleDateFormat("dd-MM-yyyy").format(cell.getDateCellValue()) );
		                                         }else
		                                             singleRows.add(cell.getNumericCellValue());
		                                         break;
		        
		            case Cell.CELL_TYPE_STRING:
		                                         singleRows.add(cell.getStringCellValue());
		                                         break;
		      
		            case Cell.CELL_TYPE_BLANK : singleRows.add(null);break;
		      
		            default : singleRows.add(cell.getStringCellValue());
		        }

		     }
		     list.add(singleRows);
		   }
		   file.close();
		   workbook.close();   
		  } catch (Exception e) {  e.printStackTrace();}
		  
		  return list;
		  
		 
		 }

		 public boolean isRowEmpty(Row row,int lastcellno) {
		     for (int c = row.getFirstCellNum(); c < lastcellno; c++) {
		         Cell cell = row.getCell(c,Row.CREATE_NULL_AS_BLANK);
		         if (cell != null && cell.getCellType() != Cell.CELL_TYPE_BLANK)
		             return false;
		     }
		     return true;
		 }
		
	

	public static Integer getColumnNumber(XSSFRow row, String colName) throws Exception {

		int patchColumn = -1;
		for (int cn = 0; cn < row.getLastCellNum(); cn++) {

			XSSFCell c = row.getCell(cn);
			try {
				String text = c.getStringCellValue();

				if (colName.equals(text)) {
					patchColumn = cn;
					break;
				}
			} catch (Exception e) {

			}
		}
		if (patchColumn == -1) {
			throw new Exception("None of the cells in the header row contain '" + colName + "'");
		}
		return patchColumn;

	}

	public static void createExcelReport() {

		try {
			
			File directory = new File(ExtentReporter.ReportFolder);
			if(!directory.exists()) {
				directory.mkdir();
			}
			
			
			ExcelReportName = ExtentReporter.ReportFolder + "\\Excel_TestReport_" + ExtentReporter.time + ".xlsx";
			File outputFile = new File(ExcelReportName);
           //FileInputStream inputStream = new FileInputStream(outputFile);

			XSSFWorkbook workbook = null;

			if (!outputFile.exists()) {

				workbook = new XSSFWorkbook();
				workbook.createSheet("Test_data_status");
				workbook.createSheet("Inspire_DB_Data");
				workbook.createSheet("CID_DB_StatusLog");
				workbook.createSheet("CID_DB_EventData");
				workbook.createSheet("CID_DB_OutboundData");
				workbook.createSheet("CID_DB_BatchData");

			}
			
			
					
			
			FileOutputStream fileOut = new FileOutputStream(outputFile);

			System.out.println(ExcelReportName);
			workbook.write(fileOut);
			workbook.close();
			
			XSSFSheet sheet = workbook.getSheet("Test_data_status");
			
			String nme = sheet.getSheetName();
			
			if (nme.equalsIgnoreCase( "Test_data_status"))
				
			 {
				System.out.println("adding the header");
				map.put("1", new Object[] {"Tracking_ID", "Status"});
				ApExcelReader.resultup("Test_data_status",  map);
				
				System.out.println("header of the status printed" );
			}

		
		
			
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	public static void storeIntoExcel(String sheetNAME, String LineItem, LinkedHashMap<String, String> map) {

		try {
			InputStream ExcelFileToRead = new FileInputStream(ExcelReportName);
			XSSFWorkbook workBook = new XSSFWorkbook(ExcelFileToRead);
			XSSFSheet sheet = workBook.getSheet(sheetNAME);

			int LastRow = sheet.getLastRowNum();

			if (LastRow < 2) {

				XSSFRow header = sheet.createRow(0);

				header.createCell(0).setCellValue("LineItem");

				XSSFRow row1 = sheet.createRow(1);

				row1.createCell(0).setCellValue(LineItem);

				int counter = 0;
				for (Entry<String, String> keys : map.entrySet()) {

					counter++;

					header.createCell(counter).setCellValue(keys.getKey().trim());

					row1.createCell(counter).setCellValue(keys.getValue().trim());

					sheet.autoSizeColumn(counter);
				}
			} else {

				XSSFRow row = sheet.createRow(LastRow + 1);

				row.createCell(0).setCellValue(LineItem);

				int counter = 0;
				for (Entry<String, String> keys : map.entrySet()) {

					counter++;

					row.createCell(counter).setCellValue(keys.getValue());

					sheet.autoSizeColumn(counter);
				}
			}

			FileOutputStream fileOut = new FileOutputStream(ExcelReportName);

			System.out.println(ExcelReportName);
			workBook.write(fileOut);
			workBook.close();
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}
	
	private static String getCellValue(XSSFCell cell) {
		
		String value="";
		
		switch (cell.getCellType()) {

		/*case Cell.CELL_TYPE_STRING:*/
		case Cell.CELL_TYPE_STRING:
			
			System.out.println(cell.getRichStringCellValue().getString());
			value = cell.getRichStringCellValue().getString();
			break;

		case Cell.CELL_TYPE_NUMERIC:

			if (DateUtil.isCellDateFormatted(cell)) {

				System.out.println(cell.getDateCellValue());
				value = cell.getDateCellValue().toString();
						
			} else {

				System.out.println((int)cell.getNumericCellValue());
				value = String.valueOf((int)cell.getNumericCellValue());
			}
			break;

		case Cell.CELL_TYPE_BOOLEAN:

			System.out.println(cell.getBooleanCellValue());
			value = String.valueOf(cell.getBooleanCellValue());
			break;

		case Cell.CELL_TYPE_FORMULA:

			value = String.valueOf(cell.getCellFormula());
			System.out.println(cell.getCellFormula());
			break;

		default:

			System.out.println();
		}

	    System.out.print("\t");
		return value;
	}
	
public static void resultup(String sheetNAME,  LinkedHashMap<String, Object[]> map) {
		
		try {
			InputStream ExcelFileToRead = new FileInputStream(ExcelReportName);
			XSSFWorkbook workBook = new XSSFWorkbook(ExcelFileToRead);
			XSSFSheet sheet = workBook.getSheet(sheetNAME);
			

			int LastRow = sheet.getLastRowNum();

			if (LastRow < 2) {
				
				System.out.println("no header");
				XSSFRow header = sheet.createRow(LastRow);
				XSSFRow row1 = sheet.createRow(LastRow+1);
				int counter = 0;
				for (Entry<String, Object[]> keys : map.entrySet()) {
					
					String Key = keys.getKey();
					Object [] obj1 = keys.getValue();
					
			
								
					
					for (Object obj : obj1) {
					
			            Cell cell = row1.createCell(counter++);
			           		           
			            if(obj instanceof Date) 
			                cell.setCellValue((Date)obj);
			            else if(obj instanceof Boolean)
			                cell.setCellValue((Boolean)obj);
			            else if(obj instanceof String)
			                cell.setCellValue((String)obj);
			            else if(obj instanceof Double)
			                cell.setCellValue((Double)obj); 

					sheet.autoSizeColumn(counter);
				}
			} }
			else {
				
				System.out.println("with  header");

				XSSFRow row1 = sheet.createRow(LastRow +1 );
				int counter = 0;
					for (Entry<String, Object[]> keys : map.entrySet()) {
					
					String Key = keys.getKey();
					Object [] obj1 = keys.getValue();
					for (Object obj : obj1) {
					
			            Cell cell = row1.createCell(counter++);
			           		           
			            if(obj instanceof Date) 
			                cell.setCellValue((Date)obj);
			            else if(obj instanceof Boolean)
			                cell.setCellValue((Boolean)obj);
			            else if(obj instanceof String)
			                cell.setCellValue((String)obj);
			            else if(obj instanceof Double)
			                cell.setCellValue((Double)obj); 

					sheet.autoSizeColumn(counter);
				}
			}
			}
			FileOutputStream fileOut = new FileOutputStream(ExcelReportName);

			System.out.println("values written" + ExcelReportName);
			//test.log(LogStatus.PASS, "Inspire DB record exported successfully");
			workBook.write(fileOut);
			workBook.close();
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

		

	}



}
