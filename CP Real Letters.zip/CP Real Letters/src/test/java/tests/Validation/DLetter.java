package tests.Validation;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import Api.Jsoncnvt;
import Api.Postman;
import Reports.ApExcelReader;
import Reports.ExtentTestManager;
import core.BasePage;
import core.BaseTest;
import core.DriverFactory;

import pages.CIDDatabase;
import pages.InspireDatabase;

import pages.InspireScaler;
import pages.PegaApplication;
import pages.SearchFile;
//import pages.splunk;
import utilities.ExcelReader;
import utilities.PropertiesFileHandler;

@Listeners(Reports.ExtentReporter.class)
public class DLetter extends BaseTest {
	
	String path = System.getProperty("user.dir") +PropertiesFileHandler.readProperty("testdata");
	private int finalr;
	private String strtrackingID;
	
	private static final String LineItem = null;
	WebDriver webDriver ;
	String strjsonModel = null;
		//public static String environment = "RT";
	static LinkedHashMap<String,Object[]> map = new LinkedHashMap<String,Object[]>();
	private static final Object API = null;
	public static String environment = PropertiesFileHandler.readProperty("Env");
	public static String userstory = PropertiesFileHandler.readProperty("id");
	public static ArrayList<ArrayList<Object>> list ;
	public static String ltype = PropertiesFileHandler.readProperty("type");


	@BeforeClass(alwaysRun = true)
	//@Parameters({ "environment" })

	public void prepareTest(/*String environment*/) throws Exception {
		
		setEnv(environment);
		test = ExtentTestManager.startTest("User story " + userstory, userstory );
		System.out.println("***********************************1");	
	}

	@Test(groups = { "Regression"})
	public void createPDF() throws Exception {
		
		
		
		ArrayList<ArrayList<Object>> list = ApExcelReader.extractAsList(BaseTest.projectPath + PropertiesFileHandler.readProperty("testdata"), "Automation");
		
 		
		int iter = 0;
		
		for(ArrayList<Object> singleRow : list){
			
			String ty =  (String )singleRow.get(0);
			String tc =  (String )singleRow.get(1);
			String lk =  (String )singleRow.get(2);
			String aci =  (String )singleRow.get(3);
			String acs =  (String )singleRow.get(4);
			String auth =  (String )singleRow.get(5);
			String tci =  (String )singleRow.get(6);
			String tcs =  (String )singleRow.get(7);
			String tid	= (String )singleRow.get(8);
			String aaci =  (String )singleRow.get(9);
			String aacs =  (String )singleRow.get(10);
			String aauth =  (String )singleRow.get(11);
			String apici	= (String )singleRow.get(12);
			String apics =  (String )singleRow.get(13);
			String api =  (String )singleRow.get(14);
			String payload =  (String )singleRow.get(15);
			String trackingidp =  (String )singleRow.get(16);
			String cquery =  (String )singleRow.get(17);
			String pquery =  (String )singleRow.get(18);
			String dtrackng =  (String )singleRow.get(19);
			String snumb = (String )singleRow.get(20);
			
			
		    
		  iter++;
		  
		  test = ExtentTestManager.startTest(tc + lk," " );
		  
		  
		  if ((ty.equalsIgnoreCase("Down")) ) {
			  
			  ExtentTestManager.getTest().log(LogStatus.INFO, "Downstream Only Validation initiated");
				
				strtrackingID = dtrackng;
				
				System.out.println("strtrackingID:" + strtrackingID);
				
				Thread.sleep(3000);
				//Dwnstream dwn = new Dwnstream();
				
				//dwn.prepareTest();
				
				setEnv(environment);
				
				System.out.println(environment);
				
				System.out.println("Started");
				

				DriverFactory df = new DriverFactory();

				//test = ExtentTestManager.startTest("Downstream Automation", "End-To-End Testing");
				webDriver = df.driversetUp();

				Actions action = new Actions(webDriver);
				action.sendKeys(Keys.chord(Keys.CONTROL, "T")).pause(1000).build().perform();
				
				
				
				
				 
				 
					
				
				
				//((JavascriptExecutor) webDriver).executeScript("window.open('');");
				//base.switchToWindow(1);
			//	webDriver.get(PropertiesFileHandler.readProperty("splunkurl"));
			//	Thread.sleep(1000);
				
				 
				    
			//	    System.out.println("webDriver" + webDriver);
				    
				
			//	base.switchToWindow(1);

			//	splunk splunk = new splunk(webDriver);
			//	splunk.login();
				
				
			
				System.out.println("n ext trackingid****************************************:" + strtrackingID);
				
				//base.switchToWindow(0);
				InspireScaler scaler = new InspireScaler(webDriver);
				scaler.login();
				
				
				
				System.out.println(strtrackingID);
				
				String val = strtrackingID;
				
				//ExtentTestManager.startTest( "Realtime Letters Downstream validation for : ", "Tracking ID : "+ strtrackingID);

			//	ExtentTestManager.log(LogStatus.INFO, "ITERATION : " + iter + "\n Tracking ID : " + strtrackingID);
				ExtentTestManager.getTest().log(LogStatus.INFO, "Downstream : " + "\n Tracking ID : " + val);
				System.out.println("\n-------------------Downstream : " + iter + " -------------------------------\n");
				
				
				//SearchFile find = new SearchFile();
				//find.isFileFound(strtrackingID);

				InspireDatabase inspireDB = new InspireDatabase(webDriver);
				String [] jobID = inspireDB.execute_Inspire_Query(strtrackingID);

				if (scaler.inspireLoginFlag == true) {

					if(!jobID[0].isEmpty()) {
					scaler.searchTheJobDetails(strtrackingID, jobID[0]);
					
					}else {
						
						ExtentTestManager.getTest().log(LogStatus.FAIL,
								"Inspire Application can't be accessed since Inspire DB returned empty JobID");
						
						System.out.println("Inspire Application can't be accessed since Inspire DB returned empty JobID");
					}
					
				} else {
					ExtentTestManager.getTest().log(LogStatus.FAIL,
							"Inspire Application can't be accessed since login failed");
					System.out.println("Inspire Application can't be accessed since login failed");
				}
				
				

				
				((JavascriptExecutor) webDriver).executeScript("window.open('');");
				BasePage base = new BasePage(webDriver);
				base.switchToWindow(1);
				
				
				if((lk.equalsIgnoreCase("ENB-HFC-SMG-APP-STS")) || (lk.equalsIgnoreCase("ENB-HFC-SMG-FLW"))){

				
					webDriver.get(PropertiesFileHandler.readProperty("enbURL_" + environment));
					Thread.sleep(1000);
					
					System.out.println("ENB  "+PropertiesFileHandler.readProperty("enbURL_" + environment));
				
				
				}
				
				else {
					
					webDriver.get(PropertiesFileHandler.readProperty("pegaURL_" + environment));
					Thread.sleep(1000);
					System.out.println("realtime  "+PropertiesFileHandler.readProperty("enbURL_" + environment));
					
				}

				PegaApplication pega = new PegaApplication(webDriver);
				
				if ((environment.equalsIgnoreCase("RT"))&& ((lk.equalsIgnoreCase("ENB-HFC-SMG-APP-STS")) || (lk.equalsIgnoreCase("ENB-HFC-SMG-FLW")))) {
					
					System.out.println("logi*********************************n;");
					pega.login();
				}
				
				pega.searchTheJobDetails(strtrackingID);
				
				
				CIDDatabase cidDB = new CIDDatabase();
				//CIDDatabase cidDB = new CIDDatabase(webDriver);
				cidDB.execute_CID_Query("StatusLog", strtrackingID);
				cidDB.execute_CID_Query("EventData", strtrackingID);
				cidDB.execute_CID_Query("OutboundData", strtrackingID);
				cidDB.execute_CID_Query("Xref query", lk);
				//CIDDatabase.execute_CID_selQuery( "cidxref_RT", pquery, lk,tc);
				//cidDB.execute_CID_Query("BatchData", strtrackingID);

				
				
				
				
				
			//	base.switchToWindow(1);

				//splunk splunk = new splunk(webDriver);
				//splunk.login();
				//splunk.searchTheJobDetails(strtrackingID, jobID[0],ltype);

			//	base.switchToWindow(0);
				//BasePage.writeInEmailBody(iter+"\t\t"+strtrackingID+"\t\t"+child.getRunStatus());
				
				String LOB = jobID [1];
				SearchFile find = new SearchFile();
				find.isFileFound(strtrackingID , LOB);
			
			
		 String trckid =  strtrackingID;
			map.put(" ", new Object[] {ty,tc,trckid, "Success"});
			//ExcelReader.resultup("Test_data_status",  map);
			//ExcelReader.resultup(BaseTest.projectPath + PropertiesFileHandler.readProperty("testdesign"),"apiresponse",  map);
				
			ExtentTestManager.getTest().log(LogStatus.PASS, " Validation is completed for Test case  :" +tc + " and " +lk +" . and Tracking id  : " + trckid );
			
			webDriver.quit();
			  
			  
		  }
		  
		  else if ((ty.equalsIgnoreCase("positive")) || (ty.equalsIgnoreCase("exception"))||(ty.equalsIgnoreCase("regression"))) {
		  
		 
		    System.out.println("*************************************values fetched from sheet********************");
		    
		   // ExtentTestManager.startTest( "Validation intitiated for Testcase : " +tc, tc + lk);	
		    ExtentTestManager.getTest().log(LogStatus.INFO, "Validation intitiated for Testcase : " +tc);
		    
		    Postman gen = new Postman();
			String auths1 = gen.token(aci, acs, auth);
		    ExtentTestManager.getTest().log(LogStatus.PASS, "Access Token generated for Tracking ID successfully");
		    String trackingid = gen.trackingid(tci, tcs, tid, auths1, trackingidp,snumb);
		    
		    ExtentTestManager.getTest().log(LogStatus.PASS, "Tracking id generated successfully for the Letter :" +lk+ " Tracking id is : " + trackingid );
		    
		   // map.put(" ", new Object[] {trackingid});
			//ExcelReader.resultup("Test_data_status",  map);
			//ExcelReader.resultups(BaseTest.projectPath + PropertiesFileHandler.readProperty("testdesign"),"Letterkey",  map);
		    
			System.out.println("*************************************tracking id generated********************");
		   // String auths2 = gen.token(aaci, aacs, aauth);
		    
		    ExtentTestManager.getTest().log(LogStatus.PASS, "Access Token generated for triggering the letter");
		    
		    gen.apiPostRequest(ty,apici, apics, api,payload,lk,trackingid,auths1);
		    
		    //below is needed only when running the letter only and descoping downstream validation
		    
		    map.put(" ", new Object[] {ty,tc,trackingid, "Success"});
			//ExcelReader.resultup("Test_data_status",  map);
			//ExcelReader.resultup(BaseTest.projectPath + PropertiesFileHandler.readProperty("testdesign"),"apiresponse",  map);
		    
		    
		    //**********************************************Downstream starts***************************************
		    
		    Thread.sleep(10000);
		    
		   
		    if (Postman.lettertriger == true) {
		    	
		    	 ExtentTestManager.getTest().log(LogStatus.INFO, "Downstream Validation initiated");
				
				strtrackingID = trackingid;
				
				System.out.println("strtrackingID:" + strtrackingID);
				
				Thread.sleep(3000);
				//Dwnstream dwn = new Dwnstream();
				
				//dwn.prepareTest();
				
				setEnv(environment);
				
				System.out.println(environment);
				
				System.out.println("Started");
				

				DriverFactory df = new DriverFactory();

				//test = ExtentTestManager.startTest("Downstream Automation", "End-To-End Testing");
				webDriver = df.driversetUp();

				Actions action = new Actions(webDriver);
				action.sendKeys(Keys.chord(Keys.CONTROL, "T")).pause(1000).build().perform();
				//((JavascriptExecutor) webDriver).executeScript("window.open('');");
				BasePage base = new BasePage(webDriver);
				/*
				base.switchToWindow(1);
				
				if((lk.equalsIgnoreCase("ENB-HFC-SMG-APP-STS")) || (lk.equalsIgnoreCase("ENB-HFC-SMG-FLW"))){

				
					webDriver.get(PropertiesFileHandler.readProperty("enbURL_" + environment));
					Thread.sleep(1000);
					
					System.out.println("ENB  "+PropertiesFileHandler.readProperty("enbURL_" + environment));
				
				
				}
				
				else {
					
					webDriver.get(PropertiesFileHandler.readProperty("pegaURL_" + environment));
					Thread.sleep(1000);
					System.out.println("realtime  "+PropertiesFileHandler.readProperty("enbURL_" + environment));
					
				}
					
			*/		
				
			//	((JavascriptExecutor) webDriver).executeScript("window.open('');");
			//	base.switchToWindow(1);
			//	webDriver.get(PropertiesFileHandler.readProperty("splunkurl"));
			//	Thread.sleep(1000);
				
				 
				    
				    System.out.println("webDriver" + webDriver);
				    
				
				// base.switchToWindow(1);

			//	splunk splunk = new splunk(webDriver);
			//	splunk.login();
				
				
			
				System.out.println("n ext trackingid****************************************:" + strtrackingID);
				
				//base.switchToWindow(0);
				InspireScaler scaler = new InspireScaler(webDriver);
				scaler.login();
				
				
				
				System.out.println(strtrackingID);
				
				String val = strtrackingID;
				
				//ExtentTestManager.startTest( "Realtime Letters Downstream validation for : ", "Tracking ID : "+ strtrackingID);

			//	ExtentTestManager.log(LogStatus.INFO, "ITERATION : " + iter + "\n Tracking ID : " + strtrackingID);
				ExtentTestManager.getTest().log(LogStatus.INFO, "Downstream : " + "\n Tracking ID : " + val);
				System.out.println("\n-------------------Downstream : " + iter + " -------------------------------\n");
				
				
				//SearchFile find = new SearchFile();
				//find.isFileFound(strtrackingID);

				InspireDatabase inspireDB = new InspireDatabase(webDriver);
				String [] jobID = inspireDB.execute_Inspire_Query(strtrackingID);

				if (scaler.inspireLoginFlag == true) {

					if(!jobID[0].isEmpty()) {
					scaler.searchTheJobDetails(strtrackingID, jobID[0]);
					
					}else {
						
						ExtentTestManager.getTest().log(LogStatus.FAIL,
								"Inspire Application can't be accessed since Inspire DB returned empty JobID");
						
						System.out.println("Inspire Application can't be accessed since Inspire DB returned empty JobID");
					}
					
				} else {
					ExtentTestManager.getTest().log(LogStatus.FAIL,
							"Inspire Application can't be accessed since login failed");
					System.out.println("Inspire Application can't be accessed since login failed");
				}

				CIDDatabase cidDB = new CIDDatabase();
				//CIDDatabase cidDB = new CIDDatabase(webDriver);
				cidDB.execute_CID_Query("StatusLog", strtrackingID);
				cidDB.execute_CID_Query("EventData", strtrackingID);
				cidDB.execute_CID_Query("OutboundData", strtrackingID);
				cidDB.execute_CID_Query("Xref query", lk);
				//CIDDatabase.execute_CID_selQuery( "cidxref_RT", pquery, lk,tc);
				//cidDB.execute_CID_Query("BatchData", strtrackingID);
/*
				base.switchToWindow(1);

				PegaApplication pega = new PegaApplication(webDriver);
				
				if ((environment.equalsIgnoreCase("RT"))&& ((lk.equalsIgnoreCase("ENB-HFC-SMG-APP-STS")) || (lk.equalsIgnoreCase("ENB-HFC-SMG-FLW")))) {
					
					System.out.println("logi*********************************n;");
					pega.login();
				}
				
				pega.searchTheJobDetails(strtrackingID);
				
				*/
				ExtentTestManager.getTest().log(LogStatus.INFO, " Since its ECM, Fulfilment status is verified in mule log received from DEV  :" +tc + " and " +lk +" . and Tracking id  : " + trackingid );
				
			//	base.switchToWindow(1);

				//splunk splunk = new splunk(webDriver);
				//splunk.login();
			//	splunk.searchTheJobDetails(strtrackingID, jobID[0],ltype);

			//	base.switchToWindow(0);
				//BasePage.writeInEmailBody(iter+"\t\t"+strtrackingID+"\t\t"+child.getRunStatus());
				
				String LOB = jobID [1];
				SearchFile find = new SearchFile();
				find.isFileFound(strtrackingID , LOB);
			
			
		 String trckid =  strtrackingID;
			map.put(" ", new Object[] {ty,tc,trckid, "Success"});
			//ExcelReader.resultup("Test_data_status",  map);
			//ExcelReader.resultup(BaseTest.projectPath + PropertiesFileHandler.readProperty("testdesign"),"apiresponse",  map);
				
			ExtentTestManager.getTest().log(LogStatus.PASS, " Validation is completed for Test case  :" +tc + " and " +lk +" . and Tracking id  : " + trackingid );
			
			webDriver.quit();
		    }
			
	       }else {
	    	   
	    	   ExtentTestManager.getTest().log(LogStatus.FAIL, "No Tracking IDs found in the Input Sheet");
	    	   map.put(" ", new Object[] {"", "No Tracking IDs found in the Input Sheet"});
	   		//ExcelReader.resultup("Test_data_status",  map);
	   		//ExcelReader.eresultup(BaseTest.projectPath + PropertiesFileHandler.readProperty("testdesign"),"apiresponse",  map);
				System.out.println("Type is not found in the Input Sheet");
				
				webDriver.quit();	
				
			}
				
				 
			
		
		//gen.copyInputExcelToSharePATH();
		
	}
	}
	

	@AfterMethod(alwaysRun = true)
	public void tearDown() {
		
		if (testingEnv.equalsIgnoreCase(BaseTest.appEnv)) {
			logger.info("Test Completed" + DriverFactory.getInstance().getDriver());
		} else if (testingEnv.equalsIgnoreCase("local")) {
			logger.info("***Launching App in Local Environment***");
		}
	}


}
