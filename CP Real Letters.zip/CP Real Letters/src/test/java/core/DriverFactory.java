package core;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;


import utilities.PropertiesFileHandler;

// Driver Factory class to create instance of driver for each individual execution on device
public class DriverFactory {
	
	public static String environment = PropertiesFileHandler.readProperty("Env");

	public WebDriver driversetUp() throws InterruptedException {

		//System.setProperty("webdriver.chrome.driver", MainClass.DriverFile);
				
		String driverPath = System.getProperty("user.dir")+"\\src\\main\\resources\\Drivers\\";
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");
		
		ChromeOptions options = new ChromeOptions();
		//options.addArguments("headless");
		
		WebDriver driver = new ChromeDriver(options);
		
		driver.manage().window().maximize();
		
		driver.get(PropertiesFileHandler.readProperty("inspireURL_"+ environment).toString().trim());
		
		return driver;
	}

	private static DriverFactory instance = new DriverFactory(); 

	public static DriverFactory getInstance()
	{
		return instance;
	} 

	ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>(); 

	public WebDriver getDriver()
	{
		return driver.get();
	} 


}
